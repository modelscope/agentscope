# -*- coding: utf-8 -*-
"""
.. _web-browser-control:

Web Browser Control
====================

This section is redirected to the
`conversation_with_web_browser_agent/README.md
<https://github.com/modelscope/agentscope/tree/v0/examples/conversation_with_web_browser_agent>`_.
"""
