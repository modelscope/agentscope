var Mu = Object.defineProperty;
var zu = (u, a, i) => a in u ? Mu(u, a, { enumerable: !0, configurable: !0, writable: !0, value: i }) : u[a] = i;
var Ue = (u, a, i) => (zu(u, typeof a != "symbol" ? a + "" : a, i), i), Nu = (u, a, i) => {
  if (!a.has(u))
    throw TypeError("Cannot " + i);
};
var da = (u, a, i) => {
  if (a.has(u))
    throw TypeError("Cannot add the same private member more than once");
  a instanceof WeakSet ? a.add(u) : a.set(u, i);
};
var an = (u, a, i) => (Nu(u, a, "access private method"), i);
const Ru = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ul = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Ru.reduce(
  (u, { color: a, primary: i, secondary: l }) => ({
    ...u,
    [a]: {
      primary: ul[a][i],
      secondary: ul[a][l]
    }
  }),
  {}
);
function Iu(u) {
  let a, i = u[0], l = 1;
  for (; l < u.length; ) {
    const m = u[l], c = u[l + 1];
    if (l += 2, (m === "optionalAccess" || m === "optionalCall") && i == null)
      return;
    m === "access" || m === "optionalAccess" ? (a = i, i = c(i)) : (m === "call" || m === "optionalCall") && (i = c((...p) => i.call(a, ...p)), a = void 0);
  }
  return i;
}
function Lu(u) {
  u.addEventListener("click", a);
  async function a(i) {
    const l = i.composedPath(), [m] = l.filter(
      (c) => Iu([c, "optionalAccess", (p) => p.tagName]) === "BUTTON" && c.classList.contains("copy_code_button")
    );
    if (m) {
      let c = function(D) {
        D.style.opacity = "1", setTimeout(() => {
          D.style.opacity = "0";
        }, 2e3);
      };
      i.stopImmediatePropagation();
      const p = m.parentElement.innerText.trim(), v = Array.from(
        m.children
      )[1];
      await Ou(p) && c(v);
    }
  }
  return {
    destroy() {
      u.removeEventListener("click", a);
    }
  };
}
async function Ou(u) {
  let a = !1;
  if ("clipboard" in navigator)
    await navigator.clipboard.writeText(u), a = !0;
  else {
    const i = document.createElement("textarea");
    i.value = u, i.style.position = "absolute", i.style.left = "-999999px", document.body.prepend(i), i.select();
    try {
      document.execCommand("copy"), a = !0;
    } catch (l) {
      console.error(l), a = !1;
    } finally {
      i.remove();
    }
  }
  return a;
}
var cl = Object.prototype.hasOwnProperty;
function Ea(u, a) {
  var i, l;
  if (u === a)
    return !0;
  if (u && a && (i = u.constructor) === a.constructor) {
    if (i === Date)
      return u.getTime() === a.getTime();
    if (i === RegExp)
      return u.toString() === a.toString();
    if (i === Array) {
      if ((l = u.length) === a.length)
        for (; l-- && Ea(u[l], a[l]); )
          ;
      return l === -1;
    }
    if (!i || typeof u == "object") {
      l = 0;
      for (i in u)
        if (cl.call(u, i) && ++l && !cl.call(a, i) || !(i in a) || !Ea(u[i], a[i]))
          return !1;
      return Object.keys(a).length === l;
    }
  }
  return u !== u && a !== a;
}
/*! @license DOMPurify 3.0.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.0.6/LICENSE */
const {
  entries: Ds,
  setPrototypeOf: hl,
  isFrozen: qu,
  getPrototypeOf: Pu,
  getOwnPropertyDescriptor: As
} = Object;
let {
  freeze: ot,
  seal: Lt,
  create: _s
} = Object, {
  apply: Ca,
  construct: Ta
} = typeof Reflect < "u" && Reflect;
ot || (ot = function(a) {
  return a;
});
Lt || (Lt = function(a) {
  return a;
});
Ca || (Ca = function(a, i, l) {
  return a.apply(i, l);
});
Ta || (Ta = function(a, i) {
  return new a(...i);
});
const ln = Bt(Array.prototype.forEach), fl = Bt(Array.prototype.pop), kr = Bt(Array.prototype.push), pn = Bt(String.prototype.toLowerCase), pa = Bt(String.prototype.toString), Hu = Bt(String.prototype.match), xr = Bt(String.prototype.replace), Uu = Bt(String.prototype.indexOf), Gu = Bt(String.prototype.trim), pt = Bt(RegExp.prototype.test), Dr = Vu(TypeError);
function Bt(u) {
  return function(a) {
    for (var i = arguments.length, l = new Array(i > 1 ? i - 1 : 0), m = 1; m < i; m++)
      l[m - 1] = arguments[m];
    return Ca(u, a, l);
  };
}
function Vu(u) {
  return function() {
    for (var a = arguments.length, i = new Array(a), l = 0; l < a; l++)
      i[l] = arguments[l];
    return Ta(u, i);
  };
}
function De(u, a) {
  let i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : pn;
  hl && hl(u, null);
  let l = a.length;
  for (; l--; ) {
    let m = a[l];
    if (typeof m == "string") {
      const c = i(m);
      c !== m && (qu(a) || (a[l] = c), m = c);
    }
    u[m] = !0;
  }
  return u;
}
function tr(u) {
  const a = _s(null);
  for (const [i, l] of Ds(u))
    As(u, i) !== void 0 && (a[i] = l);
  return a;
}
function sn(u, a) {
  for (; u !== null; ) {
    const l = As(u, a);
    if (l) {
      if (l.get)
        return Bt(l.get);
      if (typeof l.value == "function")
        return Bt(l.value);
    }
    u = Pu(u);
  }
  function i(l) {
    return console.warn("fallback value for", l), null;
  }
  return i;
}
const ml = ot(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), ga = ot(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), va = ot(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Wu = ot(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), ba = ot(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Yu = ot(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), dl = ot(["#text"]), pl = ot(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "xmlns", "slot"]), ya = ot(["accent-height", "accumulate", "additive", "alignment-baseline", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), gl = ot(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), on = ot(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Xu = Lt(/\{\{[\w\W]*|[\w\W]*\}\}/gm), ju = Lt(/<%[\w\W]*|[\w\W]*%>/gm), Zu = Lt(/\${[\w\W]*}/gm), Ku = Lt(/^data-[\-\w.\u00B7-\uFFFF]/), Qu = Lt(/^aria-[\-\w]+$/), Ss = Lt(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Ju = Lt(/^(?:\w+script|data):/i), $u = Lt(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Fs = Lt(/^html$/i);
var vl = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  MUSTACHE_EXPR: Xu,
  ERB_EXPR: ju,
  TMPLIT_EXPR: Zu,
  DATA_ATTR: Ku,
  ARIA_ATTR: Qu,
  IS_ALLOWED_URI: Ss,
  IS_SCRIPT_OR_DATA: Ju,
  ATTR_WHITESPACE: $u,
  DOCTYPE_NAME: Fs
});
const e1 = function() {
  return typeof window > "u" ? null : window;
}, t1 = function(a, i) {
  if (typeof a != "object" || typeof a.createPolicy != "function")
    return null;
  let l = null;
  const m = "data-tt-policy-suffix";
  i && i.hasAttribute(m) && (l = i.getAttribute(m));
  const c = "dompurify" + (l ? "#" + l : "");
  try {
    return a.createPolicy(c, {
      createHTML(p) {
        return p;
      },
      createScriptURL(p) {
        return p;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + c + " could not be created."), null;
  }
};
function Es() {
  let u = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : e1();
  const a = (fe) => Es(fe);
  if (a.version = "3.0.6", a.removed = [], !u || !u.document || u.document.nodeType !== 9)
    return a.isSupported = !1, a;
  let {
    document: i
  } = u;
  const l = i, m = l.currentScript, {
    DocumentFragment: c,
    HTMLTemplateElement: p,
    Node: v,
    Element: y,
    NodeFilter: D,
    NamedNodeMap: C = u.NamedNodeMap || u.MozNamedAttrMap,
    HTMLFormElement: P,
    DOMParser: H,
    trustedTypes: W
  } = u, se = y.prototype, oe = sn(se, "cloneNode"), ae = sn(se, "nextSibling"), L = sn(se, "childNodes"), B = sn(se, "parentNode");
  if (typeof p == "function") {
    const fe = i.createElement("template");
    fe.content && fe.content.ownerDocument && (i = fe.content.ownerDocument);
  }
  let S, R = "";
  const {
    implementation: I,
    createNodeIterator: M,
    createDocumentFragment: X,
    getElementsByTagName: $
  } = i, {
    importNode: j
  } = l;
  let he = {};
  a.isSupported = typeof Ds == "function" && typeof B == "function" && I && I.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: ie,
    ERB_EXPR: de,
    TMPLIT_EXPR: be,
    DATA_ATTR: Te,
    ARIA_ATTR: Xe,
    IS_SCRIPT_OR_DATA: ue,
    ATTR_WHITESPACE: Ke
  } = vl;
  let {
    IS_ALLOWED_URI: _e
  } = vl, Ae = null;
  const Z = De({}, [...ml, ...ga, ...va, ...ba, ...dl]);
  let K = null;
  const Qe = De({}, [...pl, ...ya, ...gl, ...on]);
  let re = Object.seal(_s(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Je = null, wt = null, ut = !0, Ot = !0, a0 = !1, B0 = !0, kt = !1, ct = !1, M0 = !1, Qt = !1, i0 = !1, G0 = !1, z0 = !1, Br = !0, l0 = !1;
  const xt = "user-content-";
  let s0 = !0, o0 = !1, u0 = {}, qt = null;
  const V0 = De({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Mr = null;
  const zr = De({}, ["audio", "video", "img", "source", "image", "track"]);
  let W0 = null;
  const ur = De({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), N0 = "http://www.w3.org/1998/Math/MathML", Y0 = "http://www.w3.org/2000/svg", mt = "http://www.w3.org/1999/xhtml";
  let c0 = mt, X0 = !1, Ie = null;
  const J = De({}, [N0, Y0, mt], pa);
  let nt = null;
  const Nr = ["application/xhtml+xml", "text/html"], Rr = "text/html";
  let je = null, Dt = null;
  const cr = i.createElement("form"), Ir = function(F) {
    return F instanceof RegExp || F instanceof Function;
  }, hr = function() {
    let F = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Dt && Dt === F)) {
      if ((!F || typeof F != "object") && (F = {}), F = tr(F), nt = // eslint-disable-next-line unicorn/prefer-includes
      Nr.indexOf(F.PARSER_MEDIA_TYPE) === -1 ? nt = Rr : nt = F.PARSER_MEDIA_TYPE, je = nt === "application/xhtml+xml" ? pa : pn, Ae = "ALLOWED_TAGS" in F ? De({}, F.ALLOWED_TAGS, je) : Z, K = "ALLOWED_ATTR" in F ? De({}, F.ALLOWED_ATTR, je) : Qe, Ie = "ALLOWED_NAMESPACES" in F ? De({}, F.ALLOWED_NAMESPACES, pa) : J, W0 = "ADD_URI_SAFE_ATTR" in F ? De(
        tr(ur),
        // eslint-disable-line indent
        F.ADD_URI_SAFE_ATTR,
        // eslint-disable-line indent
        je
        // eslint-disable-line indent
      ) : ur, Mr = "ADD_DATA_URI_TAGS" in F ? De(
        tr(zr),
        // eslint-disable-line indent
        F.ADD_DATA_URI_TAGS,
        // eslint-disable-line indent
        je
        // eslint-disable-line indent
      ) : zr, qt = "FORBID_CONTENTS" in F ? De({}, F.FORBID_CONTENTS, je) : V0, Je = "FORBID_TAGS" in F ? De({}, F.FORBID_TAGS, je) : {}, wt = "FORBID_ATTR" in F ? De({}, F.FORBID_ATTR, je) : {}, u0 = "USE_PROFILES" in F ? F.USE_PROFILES : !1, ut = F.ALLOW_ARIA_ATTR !== !1, Ot = F.ALLOW_DATA_ATTR !== !1, a0 = F.ALLOW_UNKNOWN_PROTOCOLS || !1, B0 = F.ALLOW_SELF_CLOSE_IN_ATTR !== !1, kt = F.SAFE_FOR_TEMPLATES || !1, ct = F.WHOLE_DOCUMENT || !1, i0 = F.RETURN_DOM || !1, G0 = F.RETURN_DOM_FRAGMENT || !1, z0 = F.RETURN_TRUSTED_TYPE || !1, Qt = F.FORCE_BODY || !1, Br = F.SANITIZE_DOM !== !1, l0 = F.SANITIZE_NAMED_PROPS || !1, s0 = F.KEEP_CONTENT !== !1, o0 = F.IN_PLACE || !1, _e = F.ALLOWED_URI_REGEXP || Ss, c0 = F.NAMESPACE || mt, re = F.CUSTOM_ELEMENT_HANDLING || {}, F.CUSTOM_ELEMENT_HANDLING && Ir(F.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (re.tagNameCheck = F.CUSTOM_ELEMENT_HANDLING.tagNameCheck), F.CUSTOM_ELEMENT_HANDLING && Ir(F.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (re.attributeNameCheck = F.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), F.CUSTOM_ELEMENT_HANDLING && typeof F.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (re.allowCustomizedBuiltInElements = F.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), kt && (Ot = !1), G0 && (i0 = !0), u0 && (Ae = De({}, [...dl]), K = [], u0.html === !0 && (De(Ae, ml), De(K, pl)), u0.svg === !0 && (De(Ae, ga), De(K, ya), De(K, on)), u0.svgFilters === !0 && (De(Ae, va), De(K, ya), De(K, on)), u0.mathMl === !0 && (De(Ae, ba), De(K, gl), De(K, on))), F.ADD_TAGS && (Ae === Z && (Ae = tr(Ae)), De(Ae, F.ADD_TAGS, je)), F.ADD_ATTR && (K === Qe && (K = tr(K)), De(K, F.ADD_ATTR, je)), F.ADD_URI_SAFE_ATTR && De(W0, F.ADD_URI_SAFE_ATTR, je), F.FORBID_CONTENTS && (qt === V0 && (qt = tr(qt)), De(qt, F.FORBID_CONTENTS, je)), s0 && (Ae["#text"] = !0), ct && De(Ae, ["html", "head", "body"]), Ae.table && (De(Ae, ["tbody"]), delete Je.tbody), F.TRUSTED_TYPES_POLICY) {
        if (typeof F.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Dr('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof F.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Dr('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        S = F.TRUSTED_TYPES_POLICY, R = S.createHTML("");
      } else
        S === void 0 && (S = t1(W, m)), S !== null && typeof R == "string" && (R = S.createHTML(""));
      ot && ot(F), Dt = F;
    }
  }, it = De({}, ["mi", "mo", "mn", "ms", "mtext"]), At = De({}, ["foreignobject", "desc", "title", "annotation-xml"]), Pt = De({}, ["title", "style", "font", "a", "script"]), h0 = De({}, ga);
  De(h0, va), De(h0, Wu);
  const j0 = De({}, ba);
  De(j0, Yu);
  const Cn = function(F) {
    let V = B(F);
    (!V || !V.tagName) && (V = {
      namespaceURI: c0,
      tagName: "template"
    });
    const te = pn(F.tagName), Be = pn(V.tagName);
    return Ie[F.namespaceURI] ? F.namespaceURI === Y0 ? V.namespaceURI === mt ? te === "svg" : V.namespaceURI === N0 ? te === "svg" && (Be === "annotation-xml" || it[Be]) : !!h0[te] : F.namespaceURI === N0 ? V.namespaceURI === mt ? te === "math" : V.namespaceURI === Y0 ? te === "math" && At[Be] : !!j0[te] : F.namespaceURI === mt ? V.namespaceURI === Y0 && !At[Be] || V.namespaceURI === N0 && !it[Be] ? !1 : !j0[te] && (Pt[te] || !h0[te]) : !!(nt === "application/xhtml+xml" && Ie[F.namespaceURI]) : !1;
  }, Jt = function(F) {
    kr(a.removed, {
      element: F
    });
    try {
      F.parentNode.removeChild(F);
    } catch {
      F.remove();
    }
  }, fr = function(F, V) {
    try {
      kr(a.removed, {
        attribute: V.getAttributeNode(F),
        from: V
      });
    } catch {
      kr(a.removed, {
        attribute: null,
        from: V
      });
    }
    if (V.removeAttribute(F), F === "is" && !K[F])
      if (i0 || G0)
        try {
          Jt(V);
        } catch {
        }
      else
        try {
          V.setAttribute(F, "");
        } catch {
        }
  }, R0 = function(F) {
    let V = null, te = null;
    if (Qt)
      F = "<remove></remove>" + F;
    else {
      const Pe = Hu(F, /^[\r\n\t ]+/);
      te = Pe && Pe[0];
    }
    nt === "application/xhtml+xml" && c0 === mt && (F = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + F + "</body></html>");
    const Be = S ? S.createHTML(F) : F;
    if (c0 === mt)
      try {
        V = new H().parseFromString(Be, nt);
      } catch {
      }
    if (!V || !V.documentElement) {
      V = I.createDocument(c0, "template", null);
      try {
        V.documentElement.innerHTML = X0 ? R : Be;
      } catch {
      }
    }
    const A = V.body || V.documentElement;
    return F && te && A.insertBefore(i.createTextNode(te), A.childNodes[0] || null), c0 === mt ? $.call(V, ct ? "html" : "body")[0] : ct ? V.documentElement : A;
  }, qe = function(F) {
    return M.call(
      F.ownerDocument || F,
      F,
      // eslint-disable-next-line no-bitwise
      D.SHOW_ELEMENT | D.SHOW_COMMENT | D.SHOW_TEXT,
      null
    );
  }, o = function(F) {
    return F instanceof P && (typeof F.nodeName != "string" || typeof F.textContent != "string" || typeof F.removeChild != "function" || !(F.attributes instanceof C) || typeof F.removeAttribute != "function" || typeof F.setAttribute != "function" || typeof F.namespaceURI != "string" || typeof F.insertBefore != "function" || typeof F.hasChildNodes != "function");
  }, d = function(F) {
    return typeof v == "function" && F instanceof v;
  }, G = function(F, V, te) {
    he[F] && ln(he[F], (Be) => {
      Be.call(a, V, te, Dt);
    });
  }, b = function(F) {
    let V = null;
    if (G("beforeSanitizeElements", F, null), o(F))
      return Jt(F), !0;
    const te = je(F.nodeName);
    if (G("uponSanitizeElement", F, {
      tagName: te,
      allowedTags: Ae
    }), F.hasChildNodes() && !d(F.firstElementChild) && pt(/<[/\w]/g, F.innerHTML) && pt(/<[/\w]/g, F.textContent))
      return Jt(F), !0;
    if (!Ae[te] || Je[te]) {
      if (!Je[te] && Le(te) && (re.tagNameCheck instanceof RegExp && pt(re.tagNameCheck, te) || re.tagNameCheck instanceof Function && re.tagNameCheck(te)))
        return !1;
      if (s0 && !qt[te]) {
        const Be = B(F) || F.parentNode, A = L(F) || F.childNodes;
        if (A && Be) {
          const Pe = A.length;
          for (let T = Pe - 1; T >= 0; --T)
            Be.insertBefore(oe(A[T], !0), ae(F));
        }
      }
      return Jt(F), !0;
    }
    return F instanceof y && !Cn(F) || (te === "noscript" || te === "noembed" || te === "noframes") && pt(/<\/no(script|embed|frames)/i, F.innerHTML) ? (Jt(F), !0) : (kt && F.nodeType === 3 && (V = F.textContent, ln([ie, de, be], (Be) => {
      V = xr(V, Be, " ");
    }), F.textContent !== V && (kr(a.removed, {
      element: F.cloneNode()
    }), F.textContent = V)), G("afterSanitizeElements", F, null), !1);
  }, _ = function(F, V, te) {
    if (Br && (V === "id" || V === "name") && (te in i || te in cr))
      return !1;
    if (!(Ot && !wt[V] && pt(Te, V))) {
      if (!(ut && pt(Xe, V))) {
        if (!K[V] || wt[V]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(Le(F) && (re.tagNameCheck instanceof RegExp && pt(re.tagNameCheck, F) || re.tagNameCheck instanceof Function && re.tagNameCheck(F)) && (re.attributeNameCheck instanceof RegExp && pt(re.attributeNameCheck, V) || re.attributeNameCheck instanceof Function && re.attributeNameCheck(V)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            V === "is" && re.allowCustomizedBuiltInElements && (re.tagNameCheck instanceof RegExp && pt(re.tagNameCheck, te) || re.tagNameCheck instanceof Function && re.tagNameCheck(te)))
          )
            return !1;
        } else if (!W0[V]) {
          if (!pt(_e, xr(te, Ke, ""))) {
            if (!((V === "src" || V === "xlink:href" || V === "href") && F !== "script" && Uu(te, "data:") === 0 && Mr[F])) {
              if (!(a0 && !pt(ue, xr(te, Ke, "")))) {
                if (te)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Le = function(F) {
    return F.indexOf("-") > 0;
  }, le = function(F) {
    G("beforeSanitizeAttributes", F, null);
    const {
      attributes: V
    } = F;
    if (!V)
      return;
    const te = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: K
    };
    let Be = V.length;
    for (; Be--; ) {
      const A = V[Be], {
        name: Pe,
        namespaceURI: T,
        value: Ht
      } = A, f0 = je(Pe);
      let et = Pe === "value" ? Ht : Gu(Ht);
      if (te.attrName = f0, te.attrValue = et, te.keepAttr = !0, te.forceKeepAttr = void 0, G("uponSanitizeAttribute", F, te), et = te.attrValue, te.forceKeepAttr || (fr(Pe, F), !te.keepAttr))
        continue;
      if (!B0 && pt(/\/>/i, et)) {
        fr(Pe, F);
        continue;
      }
      kt && ln([ie, de, be], (dr) => {
        et = xr(et, dr, " ");
      });
      const mr = je(F.nodeName);
      if (_(mr, f0, et)) {
        if (l0 && (f0 === "id" || f0 === "name") && (fr(Pe, F), et = xt + et), S && typeof W == "object" && typeof W.getAttributeType == "function" && !T)
          switch (W.getAttributeType(mr, f0)) {
            case "TrustedHTML": {
              et = S.createHTML(et);
              break;
            }
            case "TrustedScriptURL": {
              et = S.createScriptURL(et);
              break;
            }
          }
        try {
          T ? F.setAttributeNS(T, Pe, et) : F.setAttribute(Pe, et), fl(a.removed);
        } catch {
        }
      }
    }
    G("afterSanitizeAttributes", F, null);
  }, tt = function fe(F) {
    let V = null;
    const te = qe(F);
    for (G("beforeSanitizeShadowDOM", F, null); V = te.nextNode(); )
      G("uponSanitizeShadowNode", V, null), !b(V) && (V.content instanceof c && fe(V.content), le(V));
    G("afterSanitizeShadowDOM", F, null);
  };
  return a.sanitize = function(fe) {
    let F = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, V = null, te = null, Be = null, A = null;
    if (X0 = !fe, X0 && (fe = "<!-->"), typeof fe != "string" && !d(fe))
      if (typeof fe.toString == "function") {
        if (fe = fe.toString(), typeof fe != "string")
          throw Dr("dirty is not a string, aborting");
      } else
        throw Dr("toString is not a function");
    if (!a.isSupported)
      return fe;
    if (M0 || hr(F), a.removed = [], typeof fe == "string" && (o0 = !1), o0) {
      if (fe.nodeName) {
        const Ht = je(fe.nodeName);
        if (!Ae[Ht] || Je[Ht])
          throw Dr("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (fe instanceof v)
      V = R0("<!---->"), te = V.ownerDocument.importNode(fe, !0), te.nodeType === 1 && te.nodeName === "BODY" || te.nodeName === "HTML" ? V = te : V.appendChild(te);
    else {
      if (!i0 && !kt && !ct && // eslint-disable-next-line unicorn/prefer-includes
      fe.indexOf("<") === -1)
        return S && z0 ? S.createHTML(fe) : fe;
      if (V = R0(fe), !V)
        return i0 ? null : z0 ? R : "";
    }
    V && Qt && Jt(V.firstChild);
    const Pe = qe(o0 ? fe : V);
    for (; Be = Pe.nextNode(); )
      b(Be) || (Be.content instanceof c && tt(Be.content), le(Be));
    if (o0)
      return fe;
    if (i0) {
      if (G0)
        for (A = X.call(V.ownerDocument); V.firstChild; )
          A.appendChild(V.firstChild);
      else
        A = V;
      return (K.shadowroot || K.shadowrootmode) && (A = j.call(l, A, !0)), A;
    }
    let T = ct ? V.outerHTML : V.innerHTML;
    return ct && Ae["!doctype"] && V.ownerDocument && V.ownerDocument.doctype && V.ownerDocument.doctype.name && pt(Fs, V.ownerDocument.doctype.name) && (T = "<!DOCTYPE " + V.ownerDocument.doctype.name + `>
` + T), kt && ln([ie, de, be], (Ht) => {
      T = xr(T, Ht, " ");
    }), S && z0 ? S.createHTML(T) : T;
  }, a.setConfig = function() {
    let fe = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    hr(fe), M0 = !0;
  }, a.clearConfig = function() {
    Dt = null, M0 = !1;
  }, a.isValidAttribute = function(fe, F, V) {
    Dt || hr({});
    const te = je(fe), Be = je(F);
    return _(te, Be, V);
  }, a.addHook = function(fe, F) {
    typeof F == "function" && (he[fe] = he[fe] || [], kr(he[fe], F));
  }, a.removeHook = function(fe) {
    if (he[fe])
      return fl(he[fe]);
  }, a.removeHooks = function(fe) {
    he[fe] && (he[fe] = []);
  }, a.removeAllHooks = function() {
    he = {};
  }, a;
}
var bl = Es(), vn = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Cs(u) {
  return u && u.__esModule && Object.prototype.hasOwnProperty.call(u, "default") ? u.default : u;
}
var Ts = { exports: {} }, wa = { exports: {} }, yl;
function r1() {
  return yl || (yl = 1, function(u, a) {
    (function(l, m) {
      u.exports = m();
    })(typeof self < "u" ? self : vn, function() {
      return (
        /******/
        function() {
          var i = {};
          (function() {
            i.d = function(h, e) {
              for (var t in e)
                i.o(e, t) && !i.o(h, t) && Object.defineProperty(h, t, { enumerable: !0, get: e[t] });
            };
          })(), function() {
            i.o = function(h, e) {
              return Object.prototype.hasOwnProperty.call(h, e);
            };
          }();
          var l = {};
          i.d(l, {
            default: function() {
              return (
                /* binding */
                Eu
              );
            }
          });
          var m = (
            // Error start position based on passed-in Token or ParseNode.
            // Length of affected text based on passed-in Token or ParseNode.
            // The underlying error message without any context added.
            function h(e, t) {
              this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
              var r = "KaTeX parse error: " + e, n, s, f = t && t.loc;
              if (f && f.start <= f.end) {
                var g = f.lexer.input;
                n = f.start, s = f.end, n === g.length ? r += " at end of input: " : r += " at position " + (n + 1) + ": ";
                var w = g.slice(n, s).replace(/[^]/g, "$&̲"), x;
                n > 15 ? x = "…" + g.slice(n - 15, n) : x = g.slice(0, n);
                var E;
                s + 15 < g.length ? E = g.slice(s, s + 15) + "…" : E = g.slice(s), r += x + w + E;
              }
              var z = new Error(r);
              return z.name = "ParseError", z.__proto__ = h.prototype, z.position = n, n != null && s != null && (z.length = s - n), z.rawMessage = e, z;
            }
          );
          m.prototype.__proto__ = Error.prototype;
          var c = m, p = function(e, t) {
            return e.indexOf(t) !== -1;
          }, v = function(e, t) {
            return e === void 0 ? t : e;
          }, y = /([A-Z])/g, D = function(e) {
            return e.replace(y, "-$1").toLowerCase();
          }, C = {
            "&": "&amp;",
            ">": "&gt;",
            "<": "&lt;",
            '"': "&quot;",
            "'": "&#x27;"
          }, P = /[&><"']/g;
          function H(h) {
            return String(h).replace(P, function(e) {
              return C[e];
            });
          }
          var W = function h(e) {
            return e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? h(e.body[0]) : e : e.type === "font" ? h(e.body) : e;
          }, se = function(e) {
            var t = W(e);
            return t.type === "mathord" || t.type === "textord" || t.type === "atom";
          }, oe = function(e) {
            if (!e)
              throw new Error("Expected non-null, but got " + String(e));
            return e;
          }, ae = function(e) {
            var t = /^\s*([^\\/#]*?)(?::|&#0*58|&#x0*3a)/i.exec(e);
            return t != null ? t[1] : "_relative";
          }, L = {
            contains: p,
            deflt: v,
            escape: H,
            hyphenate: D,
            getBaseElem: W,
            isCharacterBox: se,
            protocolFromUrl: ae
          }, B = {
            displayMode: {
              type: "boolean",
              description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
              cli: "-d, --display-mode"
            },
            output: {
              type: {
                enum: ["htmlAndMathml", "html", "mathml"]
              },
              description: "Determines the markup language of the output.",
              cli: "-F, --format <type>"
            },
            leqno: {
              type: "boolean",
              description: "Render display math in leqno style (left-justified tags)."
            },
            fleqn: {
              type: "boolean",
              description: "Render display math flush left."
            },
            throwOnError: {
              type: "boolean",
              default: !0,
              cli: "-t, --no-throw-on-error",
              cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
            },
            errorColor: {
              type: "string",
              default: "#cc0000",
              cli: "-c, --error-color <color>",
              cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
              cliProcessor: function(e) {
                return "#" + e;
              }
            },
            macros: {
              type: "object",
              cli: "-m, --macro <def>",
              cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
              cliDefault: [],
              cliProcessor: function(e, t) {
                return t.push(e), t;
              }
            },
            minRuleThickness: {
              type: "number",
              description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
              processor: function(e) {
                return Math.max(0, e);
              },
              cli: "--min-rule-thickness <size>",
              cliProcessor: parseFloat
            },
            colorIsTextColor: {
              type: "boolean",
              description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
              cli: "-b, --color-is-text-color"
            },
            strict: {
              type: [{
                enum: ["warn", "ignore", "error"]
              }, "boolean", "function"],
              description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
              cli: "-S, --strict",
              cliDefault: !1
            },
            trust: {
              type: ["boolean", "function"],
              description: "Trust the input, enabling all HTML features such as \\url.",
              cli: "-T, --trust"
            },
            maxSize: {
              type: "number",
              default: 1 / 0,
              description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
              processor: function(e) {
                return Math.max(0, e);
              },
              cli: "-s, --max-size <n>",
              cliProcessor: parseInt
            },
            maxExpand: {
              type: "number",
              default: 1e3,
              description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
              processor: function(e) {
                return Math.max(0, e);
              },
              cli: "-e, --max-expand <n>",
              cliProcessor: function(e) {
                return e === "Infinity" ? 1 / 0 : parseInt(e);
              }
            },
            globalGroup: {
              type: "boolean",
              cli: !1
            }
          };
          function S(h) {
            if (h.default)
              return h.default;
            var e = h.type, t = Array.isArray(e) ? e[0] : e;
            if (typeof t != "string")
              return t.enum[0];
            switch (t) {
              case "boolean":
                return !1;
              case "string":
                return "";
              case "number":
                return 0;
              case "object":
                return {};
            }
          }
          var R = /* @__PURE__ */ function() {
            function h(t) {
              this.displayMode = void 0, this.output = void 0, this.leqno = void 0, this.fleqn = void 0, this.throwOnError = void 0, this.errorColor = void 0, this.macros = void 0, this.minRuleThickness = void 0, this.colorIsTextColor = void 0, this.strict = void 0, this.trust = void 0, this.maxSize = void 0, this.maxExpand = void 0, this.globalGroup = void 0, t = t || {};
              for (var r in B)
                if (B.hasOwnProperty(r)) {
                  var n = B[r];
                  this[r] = t[r] !== void 0 ? n.processor ? n.processor(t[r]) : t[r] : S(n);
                }
            }
            var e = h.prototype;
            return e.reportNonstrict = function(r, n, s) {
              var f = this.strict;
              if (typeof f == "function" && (f = f(r, n, s)), !(!f || f === "ignore")) {
                if (f === !0 || f === "error")
                  throw new c("LaTeX-incompatible input and strict mode is set to 'error': " + (n + " [" + r + "]"), s);
                f === "warn" ? typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (n + " [" + r + "]")) : typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + f + "': " + n + " [" + r + "]"));
              }
            }, e.useStrictBehavior = function(r, n, s) {
              var f = this.strict;
              if (typeof f == "function")
                try {
                  f = f(r, n, s);
                } catch {
                  f = "error";
                }
              return !f || f === "ignore" ? !1 : f === !0 || f === "error" ? !0 : f === "warn" ? (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (n + " [" + r + "]")), !1) : (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + f + "': " + n + " [" + r + "]")), !1);
            }, e.isTrusted = function(r) {
              r.url && !r.protocol && (r.protocol = L.protocolFromUrl(r.url));
              var n = typeof this.trust == "function" ? this.trust(r) : this.trust;
              return !!n;
            }, h;
          }(), I = /* @__PURE__ */ function() {
            function h(t, r, n) {
              this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = t, this.size = r, this.cramped = n;
            }
            var e = h.prototype;
            return e.sup = function() {
              return Te[Xe[this.id]];
            }, e.sub = function() {
              return Te[ue[this.id]];
            }, e.fracNum = function() {
              return Te[Ke[this.id]];
            }, e.fracDen = function() {
              return Te[_e[this.id]];
            }, e.cramp = function() {
              return Te[Ae[this.id]];
            }, e.text = function() {
              return Te[Z[this.id]];
            }, e.isTight = function() {
              return this.size >= 2;
            }, h;
          }(), M = 0, X = 1, $ = 2, j = 3, he = 4, ie = 5, de = 6, be = 7, Te = [new I(M, 0, !1), new I(X, 0, !0), new I($, 1, !1), new I(j, 1, !0), new I(he, 2, !1), new I(ie, 2, !0), new I(de, 3, !1), new I(be, 3, !0)], Xe = [he, ie, he, ie, de, be, de, be], ue = [ie, ie, ie, ie, be, be, be, be], Ke = [$, j, he, ie, de, be, de, be], _e = [j, j, ie, ie, be, be, be, be], Ae = [X, X, j, j, ie, ie, be, be], Z = [M, X, $, j, $, j, $, j], K = {
            DISPLAY: Te[M],
            TEXT: Te[$],
            SCRIPT: Te[he],
            SCRIPTSCRIPT: Te[de]
          }, Qe = [{
            // Latin characters beyond the Latin-1 characters we have metrics for.
            // Needed for Czech, Hungarian and Turkish text, for example.
            name: "latin",
            blocks: [
              [256, 591],
              // Latin Extended-A and Latin Extended-B
              [768, 879]
              // Combining Diacritical marks
            ]
          }, {
            // The Cyrillic script used by Russian and related languages.
            // A Cyrillic subset used to be supported as explicitly defined
            // symbols in symbols.js
            name: "cyrillic",
            blocks: [[1024, 1279]]
          }, {
            // Armenian
            name: "armenian",
            blocks: [[1328, 1423]]
          }, {
            // The Brahmic scripts of South and Southeast Asia
            // Devanagari (0900–097F)
            // Bengali (0980–09FF)
            // Gurmukhi (0A00–0A7F)
            // Gujarati (0A80–0AFF)
            // Oriya (0B00–0B7F)
            // Tamil (0B80–0BFF)
            // Telugu (0C00–0C7F)
            // Kannada (0C80–0CFF)
            // Malayalam (0D00–0D7F)
            // Sinhala (0D80–0DFF)
            // Thai (0E00–0E7F)
            // Lao (0E80–0EFF)
            // Tibetan (0F00–0FFF)
            // Myanmar (1000–109F)
            name: "brahmic",
            blocks: [[2304, 4255]]
          }, {
            name: "georgian",
            blocks: [[4256, 4351]]
          }, {
            // Chinese and Japanese.
            // The "k" in cjk is for Korean, but we've separated Korean out
            name: "cjk",
            blocks: [
              [12288, 12543],
              // CJK symbols and punctuation, Hiragana, Katakana
              [19968, 40879],
              // CJK ideograms
              [65280, 65376]
              // Fullwidth punctuation
              // TODO: add halfwidth Katakana and Romanji glyphs
            ]
          }, {
            // Korean
            name: "hangul",
            blocks: [[44032, 55215]]
          }];
          function re(h) {
            for (var e = 0; e < Qe.length; e++)
              for (var t = Qe[e], r = 0; r < t.blocks.length; r++) {
                var n = t.blocks[r];
                if (h >= n[0] && h <= n[1])
                  return t.name;
              }
            return null;
          }
          var Je = [];
          Qe.forEach(function(h) {
            return h.blocks.forEach(function(e) {
              return Je.push.apply(Je, e);
            });
          });
          function wt(h) {
            for (var e = 0; e < Je.length; e += 2)
              if (h >= Je[e] && h <= Je[e + 1])
                return !0;
            return !1;
          }
          var ut = 80, Ot = function(e, t) {
            return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
          }, a0 = function(e, t) {
            return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
          }, B0 = function(e, t) {
            return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
          }, kt = function(e, t) {
            return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
          }, ct = function(e, t) {
            return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
          }, M0 = function(e) {
            var t = e / 2;
            return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
          }, Qt = function(e, t, r) {
            var n = r - 54 - t - e;
            return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + n + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
          }, i0 = function(e, t, r) {
            t = 1e3 * t;
            var n = "";
            switch (e) {
              case "sqrtMain":
                n = Ot(t, ut);
                break;
              case "sqrtSize1":
                n = a0(t, ut);
                break;
              case "sqrtSize2":
                n = B0(t, ut);
                break;
              case "sqrtSize3":
                n = kt(t, ut);
                break;
              case "sqrtSize4":
                n = ct(t, ut);
                break;
              case "sqrtTall":
                n = Qt(t, ut, r);
            }
            return n;
          }, G0 = function(e, t) {
            switch (e) {
              case "⎜":
                return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
              case "∣":
                return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
              case "∥":
                return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
              case "⎟":
                return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
              case "⎢":
                return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
              case "⎥":
                return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
              case "⎪":
                return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
              case "⏐":
                return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
              case "‖":
                return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
              default:
                return "";
            }
          }, z0 = {
            // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
            doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
            // doublerightarrow is from glyph U+21D2 in font KaTeX Main
            doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
            // leftarrow is from glyph U+2190 in font KaTeX Main
            leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
            // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
            leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
            leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
            // overgroup is from the MnSymbol package (public domain)
            leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
            leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
            // Harpoons are from glyph U+21BD in font KaTeX Main
            leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
            leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
            leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
            leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
            // hook is from glyph U+21A9 in font KaTeX Main
            lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
            leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
            leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
            // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
            leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
            longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
            midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
            midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
            oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
            oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
            oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
            oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
            rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
            rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
            rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
            rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
            rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
            rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
            rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
            rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
            rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
            righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
            rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
            rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
            // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
            twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
            twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
            // tilde1 is a modified version of a glyph from the MnSymbol package
            tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
            // ditto tilde2, tilde3, & tilde4
            tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
            tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
            tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
            // vec is from glyph U+20D7 in font KaTeX Main
            vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
            // widehat1 is a modified version of a glyph from the MnSymbol package
            widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
            // ditto widehat2, widehat3, & widehat4
            widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
            widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
            widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
            // widecheck paths are all inverted versions of widehat
            widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
            widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
            widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
            widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
            // The next ten paths support reaction arrows from the mhchem package.
            // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
            // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
            baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
            // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
            rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
            // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
            // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
            baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
            rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
            shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
            shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
          }, Br = function(e, t) {
            switch (e) {
              case "lbrack":
                return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
              case "rbrack":
                return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
              case "vert":
                return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
              case "doublevert":
                return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
              case "lfloor":
                return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
              case "rfloor":
                return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
              case "lceil":
                return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
              case "rceil":
                return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
              case "lparen":
                return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
              case "rparen":
                return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
              default:
                throw new Error("Unknown stretchy delimiter.");
            }
          }, l0 = /* @__PURE__ */ function() {
            function h(t) {
              this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = t, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
            }
            var e = h.prototype;
            return e.hasClass = function(r) {
              return L.contains(this.classes, r);
            }, e.toNode = function() {
              for (var r = document.createDocumentFragment(), n = 0; n < this.children.length; n++)
                r.appendChild(this.children[n].toNode());
              return r;
            }, e.toMarkup = function() {
              for (var r = "", n = 0; n < this.children.length; n++)
                r += this.children[n].toMarkup();
              return r;
            }, e.toText = function() {
              var r = function(s) {
                return s.toText();
              };
              return this.children.map(r).join("");
            }, h;
          }(), xt = {
            "AMS-Regular": {
              32: [0, 0, 0, 0, 0.25],
              65: [0, 0.68889, 0, 0, 0.72222],
              66: [0, 0.68889, 0, 0, 0.66667],
              67: [0, 0.68889, 0, 0, 0.72222],
              68: [0, 0.68889, 0, 0, 0.72222],
              69: [0, 0.68889, 0, 0, 0.66667],
              70: [0, 0.68889, 0, 0, 0.61111],
              71: [0, 0.68889, 0, 0, 0.77778],
              72: [0, 0.68889, 0, 0, 0.77778],
              73: [0, 0.68889, 0, 0, 0.38889],
              74: [0.16667, 0.68889, 0, 0, 0.5],
              75: [0, 0.68889, 0, 0, 0.77778],
              76: [0, 0.68889, 0, 0, 0.66667],
              77: [0, 0.68889, 0, 0, 0.94445],
              78: [0, 0.68889, 0, 0, 0.72222],
              79: [0.16667, 0.68889, 0, 0, 0.77778],
              80: [0, 0.68889, 0, 0, 0.61111],
              81: [0.16667, 0.68889, 0, 0, 0.77778],
              82: [0, 0.68889, 0, 0, 0.72222],
              83: [0, 0.68889, 0, 0, 0.55556],
              84: [0, 0.68889, 0, 0, 0.66667],
              85: [0, 0.68889, 0, 0, 0.72222],
              86: [0, 0.68889, 0, 0, 0.72222],
              87: [0, 0.68889, 0, 0, 1],
              88: [0, 0.68889, 0, 0, 0.72222],
              89: [0, 0.68889, 0, 0, 0.72222],
              90: [0, 0.68889, 0, 0, 0.66667],
              107: [0, 0.68889, 0, 0, 0.55556],
              160: [0, 0, 0, 0, 0.25],
              165: [0, 0.675, 0.025, 0, 0.75],
              174: [0.15559, 0.69224, 0, 0, 0.94666],
              240: [0, 0.68889, 0, 0, 0.55556],
              295: [0, 0.68889, 0, 0, 0.54028],
              710: [0, 0.825, 0, 0, 2.33334],
              732: [0, 0.9, 0, 0, 2.33334],
              770: [0, 0.825, 0, 0, 2.33334],
              771: [0, 0.9, 0, 0, 2.33334],
              989: [0.08167, 0.58167, 0, 0, 0.77778],
              1008: [0, 0.43056, 0.04028, 0, 0.66667],
              8245: [0, 0.54986, 0, 0, 0.275],
              8463: [0, 0.68889, 0, 0, 0.54028],
              8487: [0, 0.68889, 0, 0, 0.72222],
              8498: [0, 0.68889, 0, 0, 0.55556],
              8502: [0, 0.68889, 0, 0, 0.66667],
              8503: [0, 0.68889, 0, 0, 0.44445],
              8504: [0, 0.68889, 0, 0, 0.66667],
              8513: [0, 0.68889, 0, 0, 0.63889],
              8592: [-0.03598, 0.46402, 0, 0, 0.5],
              8594: [-0.03598, 0.46402, 0, 0, 0.5],
              8602: [-0.13313, 0.36687, 0, 0, 1],
              8603: [-0.13313, 0.36687, 0, 0, 1],
              8606: [0.01354, 0.52239, 0, 0, 1],
              8608: [0.01354, 0.52239, 0, 0, 1],
              8610: [0.01354, 0.52239, 0, 0, 1.11111],
              8611: [0.01354, 0.52239, 0, 0, 1.11111],
              8619: [0, 0.54986, 0, 0, 1],
              8620: [0, 0.54986, 0, 0, 1],
              8621: [-0.13313, 0.37788, 0, 0, 1.38889],
              8622: [-0.13313, 0.36687, 0, 0, 1],
              8624: [0, 0.69224, 0, 0, 0.5],
              8625: [0, 0.69224, 0, 0, 0.5],
              8630: [0, 0.43056, 0, 0, 1],
              8631: [0, 0.43056, 0, 0, 1],
              8634: [0.08198, 0.58198, 0, 0, 0.77778],
              8635: [0.08198, 0.58198, 0, 0, 0.77778],
              8638: [0.19444, 0.69224, 0, 0, 0.41667],
              8639: [0.19444, 0.69224, 0, 0, 0.41667],
              8642: [0.19444, 0.69224, 0, 0, 0.41667],
              8643: [0.19444, 0.69224, 0, 0, 0.41667],
              8644: [0.1808, 0.675, 0, 0, 1],
              8646: [0.1808, 0.675, 0, 0, 1],
              8647: [0.1808, 0.675, 0, 0, 1],
              8648: [0.19444, 0.69224, 0, 0, 0.83334],
              8649: [0.1808, 0.675, 0, 0, 1],
              8650: [0.19444, 0.69224, 0, 0, 0.83334],
              8651: [0.01354, 0.52239, 0, 0, 1],
              8652: [0.01354, 0.52239, 0, 0, 1],
              8653: [-0.13313, 0.36687, 0, 0, 1],
              8654: [-0.13313, 0.36687, 0, 0, 1],
              8655: [-0.13313, 0.36687, 0, 0, 1],
              8666: [0.13667, 0.63667, 0, 0, 1],
              8667: [0.13667, 0.63667, 0, 0, 1],
              8669: [-0.13313, 0.37788, 0, 0, 1],
              8672: [-0.064, 0.437, 0, 0, 1.334],
              8674: [-0.064, 0.437, 0, 0, 1.334],
              8705: [0, 0.825, 0, 0, 0.5],
              8708: [0, 0.68889, 0, 0, 0.55556],
              8709: [0.08167, 0.58167, 0, 0, 0.77778],
              8717: [0, 0.43056, 0, 0, 0.42917],
              8722: [-0.03598, 0.46402, 0, 0, 0.5],
              8724: [0.08198, 0.69224, 0, 0, 0.77778],
              8726: [0.08167, 0.58167, 0, 0, 0.77778],
              8733: [0, 0.69224, 0, 0, 0.77778],
              8736: [0, 0.69224, 0, 0, 0.72222],
              8737: [0, 0.69224, 0, 0, 0.72222],
              8738: [0.03517, 0.52239, 0, 0, 0.72222],
              8739: [0.08167, 0.58167, 0, 0, 0.22222],
              8740: [0.25142, 0.74111, 0, 0, 0.27778],
              8741: [0.08167, 0.58167, 0, 0, 0.38889],
              8742: [0.25142, 0.74111, 0, 0, 0.5],
              8756: [0, 0.69224, 0, 0, 0.66667],
              8757: [0, 0.69224, 0, 0, 0.66667],
              8764: [-0.13313, 0.36687, 0, 0, 0.77778],
              8765: [-0.13313, 0.37788, 0, 0, 0.77778],
              8769: [-0.13313, 0.36687, 0, 0, 0.77778],
              8770: [-0.03625, 0.46375, 0, 0, 0.77778],
              8774: [0.30274, 0.79383, 0, 0, 0.77778],
              8776: [-0.01688, 0.48312, 0, 0, 0.77778],
              8778: [0.08167, 0.58167, 0, 0, 0.77778],
              8782: [0.06062, 0.54986, 0, 0, 0.77778],
              8783: [0.06062, 0.54986, 0, 0, 0.77778],
              8785: [0.08198, 0.58198, 0, 0, 0.77778],
              8786: [0.08198, 0.58198, 0, 0, 0.77778],
              8787: [0.08198, 0.58198, 0, 0, 0.77778],
              8790: [0, 0.69224, 0, 0, 0.77778],
              8791: [0.22958, 0.72958, 0, 0, 0.77778],
              8796: [0.08198, 0.91667, 0, 0, 0.77778],
              8806: [0.25583, 0.75583, 0, 0, 0.77778],
              8807: [0.25583, 0.75583, 0, 0, 0.77778],
              8808: [0.25142, 0.75726, 0, 0, 0.77778],
              8809: [0.25142, 0.75726, 0, 0, 0.77778],
              8812: [0.25583, 0.75583, 0, 0, 0.5],
              8814: [0.20576, 0.70576, 0, 0, 0.77778],
              8815: [0.20576, 0.70576, 0, 0, 0.77778],
              8816: [0.30274, 0.79383, 0, 0, 0.77778],
              8817: [0.30274, 0.79383, 0, 0, 0.77778],
              8818: [0.22958, 0.72958, 0, 0, 0.77778],
              8819: [0.22958, 0.72958, 0, 0, 0.77778],
              8822: [0.1808, 0.675, 0, 0, 0.77778],
              8823: [0.1808, 0.675, 0, 0, 0.77778],
              8828: [0.13667, 0.63667, 0, 0, 0.77778],
              8829: [0.13667, 0.63667, 0, 0, 0.77778],
              8830: [0.22958, 0.72958, 0, 0, 0.77778],
              8831: [0.22958, 0.72958, 0, 0, 0.77778],
              8832: [0.20576, 0.70576, 0, 0, 0.77778],
              8833: [0.20576, 0.70576, 0, 0, 0.77778],
              8840: [0.30274, 0.79383, 0, 0, 0.77778],
              8841: [0.30274, 0.79383, 0, 0, 0.77778],
              8842: [0.13597, 0.63597, 0, 0, 0.77778],
              8843: [0.13597, 0.63597, 0, 0, 0.77778],
              8847: [0.03517, 0.54986, 0, 0, 0.77778],
              8848: [0.03517, 0.54986, 0, 0, 0.77778],
              8858: [0.08198, 0.58198, 0, 0, 0.77778],
              8859: [0.08198, 0.58198, 0, 0, 0.77778],
              8861: [0.08198, 0.58198, 0, 0, 0.77778],
              8862: [0, 0.675, 0, 0, 0.77778],
              8863: [0, 0.675, 0, 0, 0.77778],
              8864: [0, 0.675, 0, 0, 0.77778],
              8865: [0, 0.675, 0, 0, 0.77778],
              8872: [0, 0.69224, 0, 0, 0.61111],
              8873: [0, 0.69224, 0, 0, 0.72222],
              8874: [0, 0.69224, 0, 0, 0.88889],
              8876: [0, 0.68889, 0, 0, 0.61111],
              8877: [0, 0.68889, 0, 0, 0.61111],
              8878: [0, 0.68889, 0, 0, 0.72222],
              8879: [0, 0.68889, 0, 0, 0.72222],
              8882: [0.03517, 0.54986, 0, 0, 0.77778],
              8883: [0.03517, 0.54986, 0, 0, 0.77778],
              8884: [0.13667, 0.63667, 0, 0, 0.77778],
              8885: [0.13667, 0.63667, 0, 0, 0.77778],
              8888: [0, 0.54986, 0, 0, 1.11111],
              8890: [0.19444, 0.43056, 0, 0, 0.55556],
              8891: [0.19444, 0.69224, 0, 0, 0.61111],
              8892: [0.19444, 0.69224, 0, 0, 0.61111],
              8901: [0, 0.54986, 0, 0, 0.27778],
              8903: [0.08167, 0.58167, 0, 0, 0.77778],
              8905: [0.08167, 0.58167, 0, 0, 0.77778],
              8906: [0.08167, 0.58167, 0, 0, 0.77778],
              8907: [0, 0.69224, 0, 0, 0.77778],
              8908: [0, 0.69224, 0, 0, 0.77778],
              8909: [-0.03598, 0.46402, 0, 0, 0.77778],
              8910: [0, 0.54986, 0, 0, 0.76042],
              8911: [0, 0.54986, 0, 0, 0.76042],
              8912: [0.03517, 0.54986, 0, 0, 0.77778],
              8913: [0.03517, 0.54986, 0, 0, 0.77778],
              8914: [0, 0.54986, 0, 0, 0.66667],
              8915: [0, 0.54986, 0, 0, 0.66667],
              8916: [0, 0.69224, 0, 0, 0.66667],
              8918: [0.0391, 0.5391, 0, 0, 0.77778],
              8919: [0.0391, 0.5391, 0, 0, 0.77778],
              8920: [0.03517, 0.54986, 0, 0, 1.33334],
              8921: [0.03517, 0.54986, 0, 0, 1.33334],
              8922: [0.38569, 0.88569, 0, 0, 0.77778],
              8923: [0.38569, 0.88569, 0, 0, 0.77778],
              8926: [0.13667, 0.63667, 0, 0, 0.77778],
              8927: [0.13667, 0.63667, 0, 0, 0.77778],
              8928: [0.30274, 0.79383, 0, 0, 0.77778],
              8929: [0.30274, 0.79383, 0, 0, 0.77778],
              8934: [0.23222, 0.74111, 0, 0, 0.77778],
              8935: [0.23222, 0.74111, 0, 0, 0.77778],
              8936: [0.23222, 0.74111, 0, 0, 0.77778],
              8937: [0.23222, 0.74111, 0, 0, 0.77778],
              8938: [0.20576, 0.70576, 0, 0, 0.77778],
              8939: [0.20576, 0.70576, 0, 0, 0.77778],
              8940: [0.30274, 0.79383, 0, 0, 0.77778],
              8941: [0.30274, 0.79383, 0, 0, 0.77778],
              8994: [0.19444, 0.69224, 0, 0, 0.77778],
              8995: [0.19444, 0.69224, 0, 0, 0.77778],
              9416: [0.15559, 0.69224, 0, 0, 0.90222],
              9484: [0, 0.69224, 0, 0, 0.5],
              9488: [0, 0.69224, 0, 0, 0.5],
              9492: [0, 0.37788, 0, 0, 0.5],
              9496: [0, 0.37788, 0, 0, 0.5],
              9585: [0.19444, 0.68889, 0, 0, 0.88889],
              9586: [0.19444, 0.74111, 0, 0, 0.88889],
              9632: [0, 0.675, 0, 0, 0.77778],
              9633: [0, 0.675, 0, 0, 0.77778],
              9650: [0, 0.54986, 0, 0, 0.72222],
              9651: [0, 0.54986, 0, 0, 0.72222],
              9654: [0.03517, 0.54986, 0, 0, 0.77778],
              9660: [0, 0.54986, 0, 0, 0.72222],
              9661: [0, 0.54986, 0, 0, 0.72222],
              9664: [0.03517, 0.54986, 0, 0, 0.77778],
              9674: [0.11111, 0.69224, 0, 0, 0.66667],
              9733: [0.19444, 0.69224, 0, 0, 0.94445],
              10003: [0, 0.69224, 0, 0, 0.83334],
              10016: [0, 0.69224, 0, 0, 0.83334],
              10731: [0.11111, 0.69224, 0, 0, 0.66667],
              10846: [0.19444, 0.75583, 0, 0, 0.61111],
              10877: [0.13667, 0.63667, 0, 0, 0.77778],
              10878: [0.13667, 0.63667, 0, 0, 0.77778],
              10885: [0.25583, 0.75583, 0, 0, 0.77778],
              10886: [0.25583, 0.75583, 0, 0, 0.77778],
              10887: [0.13597, 0.63597, 0, 0, 0.77778],
              10888: [0.13597, 0.63597, 0, 0, 0.77778],
              10889: [0.26167, 0.75726, 0, 0, 0.77778],
              10890: [0.26167, 0.75726, 0, 0, 0.77778],
              10891: [0.48256, 0.98256, 0, 0, 0.77778],
              10892: [0.48256, 0.98256, 0, 0, 0.77778],
              10901: [0.13667, 0.63667, 0, 0, 0.77778],
              10902: [0.13667, 0.63667, 0, 0, 0.77778],
              10933: [0.25142, 0.75726, 0, 0, 0.77778],
              10934: [0.25142, 0.75726, 0, 0, 0.77778],
              10935: [0.26167, 0.75726, 0, 0, 0.77778],
              10936: [0.26167, 0.75726, 0, 0, 0.77778],
              10937: [0.26167, 0.75726, 0, 0, 0.77778],
              10938: [0.26167, 0.75726, 0, 0, 0.77778],
              10949: [0.25583, 0.75583, 0, 0, 0.77778],
              10950: [0.25583, 0.75583, 0, 0, 0.77778],
              10955: [0.28481, 0.79383, 0, 0, 0.77778],
              10956: [0.28481, 0.79383, 0, 0, 0.77778],
              57350: [0.08167, 0.58167, 0, 0, 0.22222],
              57351: [0.08167, 0.58167, 0, 0, 0.38889],
              57352: [0.08167, 0.58167, 0, 0, 0.77778],
              57353: [0, 0.43056, 0.04028, 0, 0.66667],
              57356: [0.25142, 0.75726, 0, 0, 0.77778],
              57357: [0.25142, 0.75726, 0, 0, 0.77778],
              57358: [0.41951, 0.91951, 0, 0, 0.77778],
              57359: [0.30274, 0.79383, 0, 0, 0.77778],
              57360: [0.30274, 0.79383, 0, 0, 0.77778],
              57361: [0.41951, 0.91951, 0, 0, 0.77778],
              57366: [0.25142, 0.75726, 0, 0, 0.77778],
              57367: [0.25142, 0.75726, 0, 0, 0.77778],
              57368: [0.25142, 0.75726, 0, 0, 0.77778],
              57369: [0.25142, 0.75726, 0, 0, 0.77778],
              57370: [0.13597, 0.63597, 0, 0, 0.77778],
              57371: [0.13597, 0.63597, 0, 0, 0.77778]
            },
            "Caligraphic-Regular": {
              32: [0, 0, 0, 0, 0.25],
              65: [0, 0.68333, 0, 0.19445, 0.79847],
              66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
              67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
              68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
              69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
              70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
              71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
              72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
              73: [0, 0.68333, 0.07382, 0, 0.54452],
              74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
              75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
              76: [0, 0.68333, 0, 0.13889, 0.68972],
              77: [0, 0.68333, 0, 0.13889, 1.2009],
              78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
              79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
              80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
              81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
              82: [0, 0.68333, 0, 0.08334, 0.8475],
              83: [0, 0.68333, 0.075, 0.13889, 0.60556],
              84: [0, 0.68333, 0.25417, 0, 0.54464],
              85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
              86: [0, 0.68333, 0.08222, 0, 0.61278],
              87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
              88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
              89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
              90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
              160: [0, 0, 0, 0, 0.25]
            },
            "Fraktur-Regular": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69141, 0, 0, 0.29574],
              34: [0, 0.69141, 0, 0, 0.21471],
              38: [0, 0.69141, 0, 0, 0.73786],
              39: [0, 0.69141, 0, 0, 0.21201],
              40: [0.24982, 0.74947, 0, 0, 0.38865],
              41: [0.24982, 0.74947, 0, 0, 0.38865],
              42: [0, 0.62119, 0, 0, 0.27764],
              43: [0.08319, 0.58283, 0, 0, 0.75623],
              44: [0, 0.10803, 0, 0, 0.27764],
              45: [0.08319, 0.58283, 0, 0, 0.75623],
              46: [0, 0.10803, 0, 0, 0.27764],
              47: [0.24982, 0.74947, 0, 0, 0.50181],
              48: [0, 0.47534, 0, 0, 0.50181],
              49: [0, 0.47534, 0, 0, 0.50181],
              50: [0, 0.47534, 0, 0, 0.50181],
              51: [0.18906, 0.47534, 0, 0, 0.50181],
              52: [0.18906, 0.47534, 0, 0, 0.50181],
              53: [0.18906, 0.47534, 0, 0, 0.50181],
              54: [0, 0.69141, 0, 0, 0.50181],
              55: [0.18906, 0.47534, 0, 0, 0.50181],
              56: [0, 0.69141, 0, 0, 0.50181],
              57: [0.18906, 0.47534, 0, 0, 0.50181],
              58: [0, 0.47534, 0, 0, 0.21606],
              59: [0.12604, 0.47534, 0, 0, 0.21606],
              61: [-0.13099, 0.36866, 0, 0, 0.75623],
              63: [0, 0.69141, 0, 0, 0.36245],
              65: [0, 0.69141, 0, 0, 0.7176],
              66: [0, 0.69141, 0, 0, 0.88397],
              67: [0, 0.69141, 0, 0, 0.61254],
              68: [0, 0.69141, 0, 0, 0.83158],
              69: [0, 0.69141, 0, 0, 0.66278],
              70: [0.12604, 0.69141, 0, 0, 0.61119],
              71: [0, 0.69141, 0, 0, 0.78539],
              72: [0.06302, 0.69141, 0, 0, 0.7203],
              73: [0, 0.69141, 0, 0, 0.55448],
              74: [0.12604, 0.69141, 0, 0, 0.55231],
              75: [0, 0.69141, 0, 0, 0.66845],
              76: [0, 0.69141, 0, 0, 0.66602],
              77: [0, 0.69141, 0, 0, 1.04953],
              78: [0, 0.69141, 0, 0, 0.83212],
              79: [0, 0.69141, 0, 0, 0.82699],
              80: [0.18906, 0.69141, 0, 0, 0.82753],
              81: [0.03781, 0.69141, 0, 0, 0.82699],
              82: [0, 0.69141, 0, 0, 0.82807],
              83: [0, 0.69141, 0, 0, 0.82861],
              84: [0, 0.69141, 0, 0, 0.66899],
              85: [0, 0.69141, 0, 0, 0.64576],
              86: [0, 0.69141, 0, 0, 0.83131],
              87: [0, 0.69141, 0, 0, 1.04602],
              88: [0, 0.69141, 0, 0, 0.71922],
              89: [0.18906, 0.69141, 0, 0, 0.83293],
              90: [0.12604, 0.69141, 0, 0, 0.60201],
              91: [0.24982, 0.74947, 0, 0, 0.27764],
              93: [0.24982, 0.74947, 0, 0, 0.27764],
              94: [0, 0.69141, 0, 0, 0.49965],
              97: [0, 0.47534, 0, 0, 0.50046],
              98: [0, 0.69141, 0, 0, 0.51315],
              99: [0, 0.47534, 0, 0, 0.38946],
              100: [0, 0.62119, 0, 0, 0.49857],
              101: [0, 0.47534, 0, 0, 0.40053],
              102: [0.18906, 0.69141, 0, 0, 0.32626],
              103: [0.18906, 0.47534, 0, 0, 0.5037],
              104: [0.18906, 0.69141, 0, 0, 0.52126],
              105: [0, 0.69141, 0, 0, 0.27899],
              106: [0, 0.69141, 0, 0, 0.28088],
              107: [0, 0.69141, 0, 0, 0.38946],
              108: [0, 0.69141, 0, 0, 0.27953],
              109: [0, 0.47534, 0, 0, 0.76676],
              110: [0, 0.47534, 0, 0, 0.52666],
              111: [0, 0.47534, 0, 0, 0.48885],
              112: [0.18906, 0.52396, 0, 0, 0.50046],
              113: [0.18906, 0.47534, 0, 0, 0.48912],
              114: [0, 0.47534, 0, 0, 0.38919],
              115: [0, 0.47534, 0, 0, 0.44266],
              116: [0, 0.62119, 0, 0, 0.33301],
              117: [0, 0.47534, 0, 0, 0.5172],
              118: [0, 0.52396, 0, 0, 0.5118],
              119: [0, 0.52396, 0, 0, 0.77351],
              120: [0.18906, 0.47534, 0, 0, 0.38865],
              121: [0.18906, 0.47534, 0, 0, 0.49884],
              122: [0.18906, 0.47534, 0, 0, 0.39054],
              160: [0, 0, 0, 0, 0.25],
              8216: [0, 0.69141, 0, 0, 0.21471],
              8217: [0, 0.69141, 0, 0, 0.21471],
              58112: [0, 0.62119, 0, 0, 0.49749],
              58113: [0, 0.62119, 0, 0, 0.4983],
              58114: [0.18906, 0.69141, 0, 0, 0.33328],
              58115: [0.18906, 0.69141, 0, 0, 0.32923],
              58116: [0.18906, 0.47534, 0, 0, 0.50343],
              58117: [0, 0.69141, 0, 0, 0.33301],
              58118: [0, 0.62119, 0, 0, 0.33409],
              58119: [0, 0.47534, 0, 0, 0.50073]
            },
            "Main-Bold": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0, 0, 0.35],
              34: [0, 0.69444, 0, 0, 0.60278],
              35: [0.19444, 0.69444, 0, 0, 0.95833],
              36: [0.05556, 0.75, 0, 0, 0.575],
              37: [0.05556, 0.75, 0, 0, 0.95833],
              38: [0, 0.69444, 0, 0, 0.89444],
              39: [0, 0.69444, 0, 0, 0.31944],
              40: [0.25, 0.75, 0, 0, 0.44722],
              41: [0.25, 0.75, 0, 0, 0.44722],
              42: [0, 0.75, 0, 0, 0.575],
              43: [0.13333, 0.63333, 0, 0, 0.89444],
              44: [0.19444, 0.15556, 0, 0, 0.31944],
              45: [0, 0.44444, 0, 0, 0.38333],
              46: [0, 0.15556, 0, 0, 0.31944],
              47: [0.25, 0.75, 0, 0, 0.575],
              48: [0, 0.64444, 0, 0, 0.575],
              49: [0, 0.64444, 0, 0, 0.575],
              50: [0, 0.64444, 0, 0, 0.575],
              51: [0, 0.64444, 0, 0, 0.575],
              52: [0, 0.64444, 0, 0, 0.575],
              53: [0, 0.64444, 0, 0, 0.575],
              54: [0, 0.64444, 0, 0, 0.575],
              55: [0, 0.64444, 0, 0, 0.575],
              56: [0, 0.64444, 0, 0, 0.575],
              57: [0, 0.64444, 0, 0, 0.575],
              58: [0, 0.44444, 0, 0, 0.31944],
              59: [0.19444, 0.44444, 0, 0, 0.31944],
              60: [0.08556, 0.58556, 0, 0, 0.89444],
              61: [-0.10889, 0.39111, 0, 0, 0.89444],
              62: [0.08556, 0.58556, 0, 0, 0.89444],
              63: [0, 0.69444, 0, 0, 0.54305],
              64: [0, 0.69444, 0, 0, 0.89444],
              65: [0, 0.68611, 0, 0, 0.86944],
              66: [0, 0.68611, 0, 0, 0.81805],
              67: [0, 0.68611, 0, 0, 0.83055],
              68: [0, 0.68611, 0, 0, 0.88194],
              69: [0, 0.68611, 0, 0, 0.75555],
              70: [0, 0.68611, 0, 0, 0.72361],
              71: [0, 0.68611, 0, 0, 0.90416],
              72: [0, 0.68611, 0, 0, 0.9],
              73: [0, 0.68611, 0, 0, 0.43611],
              74: [0, 0.68611, 0, 0, 0.59444],
              75: [0, 0.68611, 0, 0, 0.90138],
              76: [0, 0.68611, 0, 0, 0.69166],
              77: [0, 0.68611, 0, 0, 1.09166],
              78: [0, 0.68611, 0, 0, 0.9],
              79: [0, 0.68611, 0, 0, 0.86388],
              80: [0, 0.68611, 0, 0, 0.78611],
              81: [0.19444, 0.68611, 0, 0, 0.86388],
              82: [0, 0.68611, 0, 0, 0.8625],
              83: [0, 0.68611, 0, 0, 0.63889],
              84: [0, 0.68611, 0, 0, 0.8],
              85: [0, 0.68611, 0, 0, 0.88472],
              86: [0, 0.68611, 0.01597, 0, 0.86944],
              87: [0, 0.68611, 0.01597, 0, 1.18888],
              88: [0, 0.68611, 0, 0, 0.86944],
              89: [0, 0.68611, 0.02875, 0, 0.86944],
              90: [0, 0.68611, 0, 0, 0.70277],
              91: [0.25, 0.75, 0, 0, 0.31944],
              92: [0.25, 0.75, 0, 0, 0.575],
              93: [0.25, 0.75, 0, 0, 0.31944],
              94: [0, 0.69444, 0, 0, 0.575],
              95: [0.31, 0.13444, 0.03194, 0, 0.575],
              97: [0, 0.44444, 0, 0, 0.55902],
              98: [0, 0.69444, 0, 0, 0.63889],
              99: [0, 0.44444, 0, 0, 0.51111],
              100: [0, 0.69444, 0, 0, 0.63889],
              101: [0, 0.44444, 0, 0, 0.52708],
              102: [0, 0.69444, 0.10903, 0, 0.35139],
              103: [0.19444, 0.44444, 0.01597, 0, 0.575],
              104: [0, 0.69444, 0, 0, 0.63889],
              105: [0, 0.69444, 0, 0, 0.31944],
              106: [0.19444, 0.69444, 0, 0, 0.35139],
              107: [0, 0.69444, 0, 0, 0.60694],
              108: [0, 0.69444, 0, 0, 0.31944],
              109: [0, 0.44444, 0, 0, 0.95833],
              110: [0, 0.44444, 0, 0, 0.63889],
              111: [0, 0.44444, 0, 0, 0.575],
              112: [0.19444, 0.44444, 0, 0, 0.63889],
              113: [0.19444, 0.44444, 0, 0, 0.60694],
              114: [0, 0.44444, 0, 0, 0.47361],
              115: [0, 0.44444, 0, 0, 0.45361],
              116: [0, 0.63492, 0, 0, 0.44722],
              117: [0, 0.44444, 0, 0, 0.63889],
              118: [0, 0.44444, 0.01597, 0, 0.60694],
              119: [0, 0.44444, 0.01597, 0, 0.83055],
              120: [0, 0.44444, 0, 0, 0.60694],
              121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
              122: [0, 0.44444, 0, 0, 0.51111],
              123: [0.25, 0.75, 0, 0, 0.575],
              124: [0.25, 0.75, 0, 0, 0.31944],
              125: [0.25, 0.75, 0, 0, 0.575],
              126: [0.35, 0.34444, 0, 0, 0.575],
              160: [0, 0, 0, 0, 0.25],
              163: [0, 0.69444, 0, 0, 0.86853],
              168: [0, 0.69444, 0, 0, 0.575],
              172: [0, 0.44444, 0, 0, 0.76666],
              176: [0, 0.69444, 0, 0, 0.86944],
              177: [0.13333, 0.63333, 0, 0, 0.89444],
              184: [0.17014, 0, 0, 0, 0.51111],
              198: [0, 0.68611, 0, 0, 1.04166],
              215: [0.13333, 0.63333, 0, 0, 0.89444],
              216: [0.04861, 0.73472, 0, 0, 0.89444],
              223: [0, 0.69444, 0, 0, 0.59722],
              230: [0, 0.44444, 0, 0, 0.83055],
              247: [0.13333, 0.63333, 0, 0, 0.89444],
              248: [0.09722, 0.54167, 0, 0, 0.575],
              305: [0, 0.44444, 0, 0, 0.31944],
              338: [0, 0.68611, 0, 0, 1.16944],
              339: [0, 0.44444, 0, 0, 0.89444],
              567: [0.19444, 0.44444, 0, 0, 0.35139],
              710: [0, 0.69444, 0, 0, 0.575],
              711: [0, 0.63194, 0, 0, 0.575],
              713: [0, 0.59611, 0, 0, 0.575],
              714: [0, 0.69444, 0, 0, 0.575],
              715: [0, 0.69444, 0, 0, 0.575],
              728: [0, 0.69444, 0, 0, 0.575],
              729: [0, 0.69444, 0, 0, 0.31944],
              730: [0, 0.69444, 0, 0, 0.86944],
              732: [0, 0.69444, 0, 0, 0.575],
              733: [0, 0.69444, 0, 0, 0.575],
              915: [0, 0.68611, 0, 0, 0.69166],
              916: [0, 0.68611, 0, 0, 0.95833],
              920: [0, 0.68611, 0, 0, 0.89444],
              923: [0, 0.68611, 0, 0, 0.80555],
              926: [0, 0.68611, 0, 0, 0.76666],
              928: [0, 0.68611, 0, 0, 0.9],
              931: [0, 0.68611, 0, 0, 0.83055],
              933: [0, 0.68611, 0, 0, 0.89444],
              934: [0, 0.68611, 0, 0, 0.83055],
              936: [0, 0.68611, 0, 0, 0.89444],
              937: [0, 0.68611, 0, 0, 0.83055],
              8211: [0, 0.44444, 0.03194, 0, 0.575],
              8212: [0, 0.44444, 0.03194, 0, 1.14999],
              8216: [0, 0.69444, 0, 0, 0.31944],
              8217: [0, 0.69444, 0, 0, 0.31944],
              8220: [0, 0.69444, 0, 0, 0.60278],
              8221: [0, 0.69444, 0, 0, 0.60278],
              8224: [0.19444, 0.69444, 0, 0, 0.51111],
              8225: [0.19444, 0.69444, 0, 0, 0.51111],
              8242: [0, 0.55556, 0, 0, 0.34444],
              8407: [0, 0.72444, 0.15486, 0, 0.575],
              8463: [0, 0.69444, 0, 0, 0.66759],
              8465: [0, 0.69444, 0, 0, 0.83055],
              8467: [0, 0.69444, 0, 0, 0.47361],
              8472: [0.19444, 0.44444, 0, 0, 0.74027],
              8476: [0, 0.69444, 0, 0, 0.83055],
              8501: [0, 0.69444, 0, 0, 0.70277],
              8592: [-0.10889, 0.39111, 0, 0, 1.14999],
              8593: [0.19444, 0.69444, 0, 0, 0.575],
              8594: [-0.10889, 0.39111, 0, 0, 1.14999],
              8595: [0.19444, 0.69444, 0, 0, 0.575],
              8596: [-0.10889, 0.39111, 0, 0, 1.14999],
              8597: [0.25, 0.75, 0, 0, 0.575],
              8598: [0.19444, 0.69444, 0, 0, 1.14999],
              8599: [0.19444, 0.69444, 0, 0, 1.14999],
              8600: [0.19444, 0.69444, 0, 0, 1.14999],
              8601: [0.19444, 0.69444, 0, 0, 1.14999],
              8636: [-0.10889, 0.39111, 0, 0, 1.14999],
              8637: [-0.10889, 0.39111, 0, 0, 1.14999],
              8640: [-0.10889, 0.39111, 0, 0, 1.14999],
              8641: [-0.10889, 0.39111, 0, 0, 1.14999],
              8656: [-0.10889, 0.39111, 0, 0, 1.14999],
              8657: [0.19444, 0.69444, 0, 0, 0.70277],
              8658: [-0.10889, 0.39111, 0, 0, 1.14999],
              8659: [0.19444, 0.69444, 0, 0, 0.70277],
              8660: [-0.10889, 0.39111, 0, 0, 1.14999],
              8661: [0.25, 0.75, 0, 0, 0.70277],
              8704: [0, 0.69444, 0, 0, 0.63889],
              8706: [0, 0.69444, 0.06389, 0, 0.62847],
              8707: [0, 0.69444, 0, 0, 0.63889],
              8709: [0.05556, 0.75, 0, 0, 0.575],
              8711: [0, 0.68611, 0, 0, 0.95833],
              8712: [0.08556, 0.58556, 0, 0, 0.76666],
              8715: [0.08556, 0.58556, 0, 0, 0.76666],
              8722: [0.13333, 0.63333, 0, 0, 0.89444],
              8723: [0.13333, 0.63333, 0, 0, 0.89444],
              8725: [0.25, 0.75, 0, 0, 0.575],
              8726: [0.25, 0.75, 0, 0, 0.575],
              8727: [-0.02778, 0.47222, 0, 0, 0.575],
              8728: [-0.02639, 0.47361, 0, 0, 0.575],
              8729: [-0.02639, 0.47361, 0, 0, 0.575],
              8730: [0.18, 0.82, 0, 0, 0.95833],
              8733: [0, 0.44444, 0, 0, 0.89444],
              8734: [0, 0.44444, 0, 0, 1.14999],
              8736: [0, 0.69224, 0, 0, 0.72222],
              8739: [0.25, 0.75, 0, 0, 0.31944],
              8741: [0.25, 0.75, 0, 0, 0.575],
              8743: [0, 0.55556, 0, 0, 0.76666],
              8744: [0, 0.55556, 0, 0, 0.76666],
              8745: [0, 0.55556, 0, 0, 0.76666],
              8746: [0, 0.55556, 0, 0, 0.76666],
              8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
              8764: [-0.10889, 0.39111, 0, 0, 0.89444],
              8768: [0.19444, 0.69444, 0, 0, 0.31944],
              8771: [222e-5, 0.50222, 0, 0, 0.89444],
              8773: [0.027, 0.638, 0, 0, 0.894],
              8776: [0.02444, 0.52444, 0, 0, 0.89444],
              8781: [222e-5, 0.50222, 0, 0, 0.89444],
              8801: [222e-5, 0.50222, 0, 0, 0.89444],
              8804: [0.19667, 0.69667, 0, 0, 0.89444],
              8805: [0.19667, 0.69667, 0, 0, 0.89444],
              8810: [0.08556, 0.58556, 0, 0, 1.14999],
              8811: [0.08556, 0.58556, 0, 0, 1.14999],
              8826: [0.08556, 0.58556, 0, 0, 0.89444],
              8827: [0.08556, 0.58556, 0, 0, 0.89444],
              8834: [0.08556, 0.58556, 0, 0, 0.89444],
              8835: [0.08556, 0.58556, 0, 0, 0.89444],
              8838: [0.19667, 0.69667, 0, 0, 0.89444],
              8839: [0.19667, 0.69667, 0, 0, 0.89444],
              8846: [0, 0.55556, 0, 0, 0.76666],
              8849: [0.19667, 0.69667, 0, 0, 0.89444],
              8850: [0.19667, 0.69667, 0, 0, 0.89444],
              8851: [0, 0.55556, 0, 0, 0.76666],
              8852: [0, 0.55556, 0, 0, 0.76666],
              8853: [0.13333, 0.63333, 0, 0, 0.89444],
              8854: [0.13333, 0.63333, 0, 0, 0.89444],
              8855: [0.13333, 0.63333, 0, 0, 0.89444],
              8856: [0.13333, 0.63333, 0, 0, 0.89444],
              8857: [0.13333, 0.63333, 0, 0, 0.89444],
              8866: [0, 0.69444, 0, 0, 0.70277],
              8867: [0, 0.69444, 0, 0, 0.70277],
              8868: [0, 0.69444, 0, 0, 0.89444],
              8869: [0, 0.69444, 0, 0, 0.89444],
              8900: [-0.02639, 0.47361, 0, 0, 0.575],
              8901: [-0.02639, 0.47361, 0, 0, 0.31944],
              8902: [-0.02778, 0.47222, 0, 0, 0.575],
              8968: [0.25, 0.75, 0, 0, 0.51111],
              8969: [0.25, 0.75, 0, 0, 0.51111],
              8970: [0.25, 0.75, 0, 0, 0.51111],
              8971: [0.25, 0.75, 0, 0, 0.51111],
              8994: [-0.13889, 0.36111, 0, 0, 1.14999],
              8995: [-0.13889, 0.36111, 0, 0, 1.14999],
              9651: [0.19444, 0.69444, 0, 0, 1.02222],
              9657: [-0.02778, 0.47222, 0, 0, 0.575],
              9661: [0.19444, 0.69444, 0, 0, 1.02222],
              9667: [-0.02778, 0.47222, 0, 0, 0.575],
              9711: [0.19444, 0.69444, 0, 0, 1.14999],
              9824: [0.12963, 0.69444, 0, 0, 0.89444],
              9825: [0.12963, 0.69444, 0, 0, 0.89444],
              9826: [0.12963, 0.69444, 0, 0, 0.89444],
              9827: [0.12963, 0.69444, 0, 0, 0.89444],
              9837: [0, 0.75, 0, 0, 0.44722],
              9838: [0.19444, 0.69444, 0, 0, 0.44722],
              9839: [0.19444, 0.69444, 0, 0, 0.44722],
              10216: [0.25, 0.75, 0, 0, 0.44722],
              10217: [0.25, 0.75, 0, 0, 0.44722],
              10815: [0, 0.68611, 0, 0, 0.9],
              10927: [0.19667, 0.69667, 0, 0, 0.89444],
              10928: [0.19667, 0.69667, 0, 0, 0.89444],
              57376: [0.19444, 0.69444, 0, 0, 0]
            },
            "Main-BoldItalic": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0.11417, 0, 0.38611],
              34: [0, 0.69444, 0.07939, 0, 0.62055],
              35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
              37: [0.05556, 0.75, 0.12861, 0, 0.94444],
              38: [0, 0.69444, 0.08528, 0, 0.88555],
              39: [0, 0.69444, 0.12945, 0, 0.35555],
              40: [0.25, 0.75, 0.15806, 0, 0.47333],
              41: [0.25, 0.75, 0.03306, 0, 0.47333],
              42: [0, 0.75, 0.14333, 0, 0.59111],
              43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
              44: [0.19444, 0.14722, 0, 0, 0.35555],
              45: [0, 0.44444, 0.02611, 0, 0.41444],
              46: [0, 0.14722, 0, 0, 0.35555],
              47: [0.25, 0.75, 0.15806, 0, 0.59111],
              48: [0, 0.64444, 0.13167, 0, 0.59111],
              49: [0, 0.64444, 0.13167, 0, 0.59111],
              50: [0, 0.64444, 0.13167, 0, 0.59111],
              51: [0, 0.64444, 0.13167, 0, 0.59111],
              52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
              53: [0, 0.64444, 0.13167, 0, 0.59111],
              54: [0, 0.64444, 0.13167, 0, 0.59111],
              55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
              56: [0, 0.64444, 0.13167, 0, 0.59111],
              57: [0, 0.64444, 0.13167, 0, 0.59111],
              58: [0, 0.44444, 0.06695, 0, 0.35555],
              59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
              61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
              63: [0, 0.69444, 0.11472, 0, 0.59111],
              64: [0, 0.69444, 0.09208, 0, 0.88555],
              65: [0, 0.68611, 0, 0, 0.86555],
              66: [0, 0.68611, 0.0992, 0, 0.81666],
              67: [0, 0.68611, 0.14208, 0, 0.82666],
              68: [0, 0.68611, 0.09062, 0, 0.87555],
              69: [0, 0.68611, 0.11431, 0, 0.75666],
              70: [0, 0.68611, 0.12903, 0, 0.72722],
              71: [0, 0.68611, 0.07347, 0, 0.89527],
              72: [0, 0.68611, 0.17208, 0, 0.8961],
              73: [0, 0.68611, 0.15681, 0, 0.47166],
              74: [0, 0.68611, 0.145, 0, 0.61055],
              75: [0, 0.68611, 0.14208, 0, 0.89499],
              76: [0, 0.68611, 0, 0, 0.69777],
              77: [0, 0.68611, 0.17208, 0, 1.07277],
              78: [0, 0.68611, 0.17208, 0, 0.8961],
              79: [0, 0.68611, 0.09062, 0, 0.85499],
              80: [0, 0.68611, 0.0992, 0, 0.78721],
              81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
              82: [0, 0.68611, 0.02559, 0, 0.85944],
              83: [0, 0.68611, 0.11264, 0, 0.64999],
              84: [0, 0.68611, 0.12903, 0, 0.7961],
              85: [0, 0.68611, 0.17208, 0, 0.88083],
              86: [0, 0.68611, 0.18625, 0, 0.86555],
              87: [0, 0.68611, 0.18625, 0, 1.15999],
              88: [0, 0.68611, 0.15681, 0, 0.86555],
              89: [0, 0.68611, 0.19803, 0, 0.86555],
              90: [0, 0.68611, 0.14208, 0, 0.70888],
              91: [0.25, 0.75, 0.1875, 0, 0.35611],
              93: [0.25, 0.75, 0.09972, 0, 0.35611],
              94: [0, 0.69444, 0.06709, 0, 0.59111],
              95: [0.31, 0.13444, 0.09811, 0, 0.59111],
              97: [0, 0.44444, 0.09426, 0, 0.59111],
              98: [0, 0.69444, 0.07861, 0, 0.53222],
              99: [0, 0.44444, 0.05222, 0, 0.53222],
              100: [0, 0.69444, 0.10861, 0, 0.59111],
              101: [0, 0.44444, 0.085, 0, 0.53222],
              102: [0.19444, 0.69444, 0.21778, 0, 0.4],
              103: [0.19444, 0.44444, 0.105, 0, 0.53222],
              104: [0, 0.69444, 0.09426, 0, 0.59111],
              105: [0, 0.69326, 0.11387, 0, 0.35555],
              106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
              107: [0, 0.69444, 0.11111, 0, 0.53222],
              108: [0, 0.69444, 0.10861, 0, 0.29666],
              109: [0, 0.44444, 0.09426, 0, 0.94444],
              110: [0, 0.44444, 0.09426, 0, 0.64999],
              111: [0, 0.44444, 0.07861, 0, 0.59111],
              112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
              113: [0.19444, 0.44444, 0.105, 0, 0.53222],
              114: [0, 0.44444, 0.11111, 0, 0.50167],
              115: [0, 0.44444, 0.08167, 0, 0.48694],
              116: [0, 0.63492, 0.09639, 0, 0.385],
              117: [0, 0.44444, 0.09426, 0, 0.62055],
              118: [0, 0.44444, 0.11111, 0, 0.53222],
              119: [0, 0.44444, 0.11111, 0, 0.76777],
              120: [0, 0.44444, 0.12583, 0, 0.56055],
              121: [0.19444, 0.44444, 0.105, 0, 0.56166],
              122: [0, 0.44444, 0.13889, 0, 0.49055],
              126: [0.35, 0.34444, 0.11472, 0, 0.59111],
              160: [0, 0, 0, 0, 0.25],
              168: [0, 0.69444, 0.11473, 0, 0.59111],
              176: [0, 0.69444, 0, 0, 0.94888],
              184: [0.17014, 0, 0, 0, 0.53222],
              198: [0, 0.68611, 0.11431, 0, 1.02277],
              216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
              223: [0.19444, 0.69444, 0.09736, 0, 0.665],
              230: [0, 0.44444, 0.085, 0, 0.82666],
              248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
              305: [0, 0.44444, 0.09426, 0, 0.35555],
              338: [0, 0.68611, 0.11431, 0, 1.14054],
              339: [0, 0.44444, 0.085, 0, 0.82666],
              567: [0.19444, 0.44444, 0.04611, 0, 0.385],
              710: [0, 0.69444, 0.06709, 0, 0.59111],
              711: [0, 0.63194, 0.08271, 0, 0.59111],
              713: [0, 0.59444, 0.10444, 0, 0.59111],
              714: [0, 0.69444, 0.08528, 0, 0.59111],
              715: [0, 0.69444, 0, 0, 0.59111],
              728: [0, 0.69444, 0.10333, 0, 0.59111],
              729: [0, 0.69444, 0.12945, 0, 0.35555],
              730: [0, 0.69444, 0, 0, 0.94888],
              732: [0, 0.69444, 0.11472, 0, 0.59111],
              733: [0, 0.69444, 0.11472, 0, 0.59111],
              915: [0, 0.68611, 0.12903, 0, 0.69777],
              916: [0, 0.68611, 0, 0, 0.94444],
              920: [0, 0.68611, 0.09062, 0, 0.88555],
              923: [0, 0.68611, 0, 0, 0.80666],
              926: [0, 0.68611, 0.15092, 0, 0.76777],
              928: [0, 0.68611, 0.17208, 0, 0.8961],
              931: [0, 0.68611, 0.11431, 0, 0.82666],
              933: [0, 0.68611, 0.10778, 0, 0.88555],
              934: [0, 0.68611, 0.05632, 0, 0.82666],
              936: [0, 0.68611, 0.10778, 0, 0.88555],
              937: [0, 0.68611, 0.0992, 0, 0.82666],
              8211: [0, 0.44444, 0.09811, 0, 0.59111],
              8212: [0, 0.44444, 0.09811, 0, 1.18221],
              8216: [0, 0.69444, 0.12945, 0, 0.35555],
              8217: [0, 0.69444, 0.12945, 0, 0.35555],
              8220: [0, 0.69444, 0.16772, 0, 0.62055],
              8221: [0, 0.69444, 0.07939, 0, 0.62055]
            },
            "Main-Italic": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0.12417, 0, 0.30667],
              34: [0, 0.69444, 0.06961, 0, 0.51444],
              35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
              37: [0.05556, 0.75, 0.13639, 0, 0.81777],
              38: [0, 0.69444, 0.09694, 0, 0.76666],
              39: [0, 0.69444, 0.12417, 0, 0.30667],
              40: [0.25, 0.75, 0.16194, 0, 0.40889],
              41: [0.25, 0.75, 0.03694, 0, 0.40889],
              42: [0, 0.75, 0.14917, 0, 0.51111],
              43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
              44: [0.19444, 0.10556, 0, 0, 0.30667],
              45: [0, 0.43056, 0.02826, 0, 0.35778],
              46: [0, 0.10556, 0, 0, 0.30667],
              47: [0.25, 0.75, 0.16194, 0, 0.51111],
              48: [0, 0.64444, 0.13556, 0, 0.51111],
              49: [0, 0.64444, 0.13556, 0, 0.51111],
              50: [0, 0.64444, 0.13556, 0, 0.51111],
              51: [0, 0.64444, 0.13556, 0, 0.51111],
              52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
              53: [0, 0.64444, 0.13556, 0, 0.51111],
              54: [0, 0.64444, 0.13556, 0, 0.51111],
              55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
              56: [0, 0.64444, 0.13556, 0, 0.51111],
              57: [0, 0.64444, 0.13556, 0, 0.51111],
              58: [0, 0.43056, 0.0582, 0, 0.30667],
              59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
              61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
              63: [0, 0.69444, 0.1225, 0, 0.51111],
              64: [0, 0.69444, 0.09597, 0, 0.76666],
              65: [0, 0.68333, 0, 0, 0.74333],
              66: [0, 0.68333, 0.10257, 0, 0.70389],
              67: [0, 0.68333, 0.14528, 0, 0.71555],
              68: [0, 0.68333, 0.09403, 0, 0.755],
              69: [0, 0.68333, 0.12028, 0, 0.67833],
              70: [0, 0.68333, 0.13305, 0, 0.65277],
              71: [0, 0.68333, 0.08722, 0, 0.77361],
              72: [0, 0.68333, 0.16389, 0, 0.74333],
              73: [0, 0.68333, 0.15806, 0, 0.38555],
              74: [0, 0.68333, 0.14028, 0, 0.525],
              75: [0, 0.68333, 0.14528, 0, 0.76888],
              76: [0, 0.68333, 0, 0, 0.62722],
              77: [0, 0.68333, 0.16389, 0, 0.89666],
              78: [0, 0.68333, 0.16389, 0, 0.74333],
              79: [0, 0.68333, 0.09403, 0, 0.76666],
              80: [0, 0.68333, 0.10257, 0, 0.67833],
              81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
              82: [0, 0.68333, 0.03868, 0, 0.72944],
              83: [0, 0.68333, 0.11972, 0, 0.56222],
              84: [0, 0.68333, 0.13305, 0, 0.71555],
              85: [0, 0.68333, 0.16389, 0, 0.74333],
              86: [0, 0.68333, 0.18361, 0, 0.74333],
              87: [0, 0.68333, 0.18361, 0, 0.99888],
              88: [0, 0.68333, 0.15806, 0, 0.74333],
              89: [0, 0.68333, 0.19383, 0, 0.74333],
              90: [0, 0.68333, 0.14528, 0, 0.61333],
              91: [0.25, 0.75, 0.1875, 0, 0.30667],
              93: [0.25, 0.75, 0.10528, 0, 0.30667],
              94: [0, 0.69444, 0.06646, 0, 0.51111],
              95: [0.31, 0.12056, 0.09208, 0, 0.51111],
              97: [0, 0.43056, 0.07671, 0, 0.51111],
              98: [0, 0.69444, 0.06312, 0, 0.46],
              99: [0, 0.43056, 0.05653, 0, 0.46],
              100: [0, 0.69444, 0.10333, 0, 0.51111],
              101: [0, 0.43056, 0.07514, 0, 0.46],
              102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
              103: [0.19444, 0.43056, 0.08847, 0, 0.46],
              104: [0, 0.69444, 0.07671, 0, 0.51111],
              105: [0, 0.65536, 0.1019, 0, 0.30667],
              106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
              107: [0, 0.69444, 0.10764, 0, 0.46],
              108: [0, 0.69444, 0.10333, 0, 0.25555],
              109: [0, 0.43056, 0.07671, 0, 0.81777],
              110: [0, 0.43056, 0.07671, 0, 0.56222],
              111: [0, 0.43056, 0.06312, 0, 0.51111],
              112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
              113: [0.19444, 0.43056, 0.08847, 0, 0.46],
              114: [0, 0.43056, 0.10764, 0, 0.42166],
              115: [0, 0.43056, 0.08208, 0, 0.40889],
              116: [0, 0.61508, 0.09486, 0, 0.33222],
              117: [0, 0.43056, 0.07671, 0, 0.53666],
              118: [0, 0.43056, 0.10764, 0, 0.46],
              119: [0, 0.43056, 0.10764, 0, 0.66444],
              120: [0, 0.43056, 0.12042, 0, 0.46389],
              121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
              122: [0, 0.43056, 0.12292, 0, 0.40889],
              126: [0.35, 0.31786, 0.11585, 0, 0.51111],
              160: [0, 0, 0, 0, 0.25],
              168: [0, 0.66786, 0.10474, 0, 0.51111],
              176: [0, 0.69444, 0, 0, 0.83129],
              184: [0.17014, 0, 0, 0, 0.46],
              198: [0, 0.68333, 0.12028, 0, 0.88277],
              216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
              223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
              230: [0, 0.43056, 0.07514, 0, 0.71555],
              248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
              338: [0, 0.68333, 0.12028, 0, 0.98499],
              339: [0, 0.43056, 0.07514, 0, 0.71555],
              710: [0, 0.69444, 0.06646, 0, 0.51111],
              711: [0, 0.62847, 0.08295, 0, 0.51111],
              713: [0, 0.56167, 0.10333, 0, 0.51111],
              714: [0, 0.69444, 0.09694, 0, 0.51111],
              715: [0, 0.69444, 0, 0, 0.51111],
              728: [0, 0.69444, 0.10806, 0, 0.51111],
              729: [0, 0.66786, 0.11752, 0, 0.30667],
              730: [0, 0.69444, 0, 0, 0.83129],
              732: [0, 0.66786, 0.11585, 0, 0.51111],
              733: [0, 0.69444, 0.1225, 0, 0.51111],
              915: [0, 0.68333, 0.13305, 0, 0.62722],
              916: [0, 0.68333, 0, 0, 0.81777],
              920: [0, 0.68333, 0.09403, 0, 0.76666],
              923: [0, 0.68333, 0, 0, 0.69222],
              926: [0, 0.68333, 0.15294, 0, 0.66444],
              928: [0, 0.68333, 0.16389, 0, 0.74333],
              931: [0, 0.68333, 0.12028, 0, 0.71555],
              933: [0, 0.68333, 0.11111, 0, 0.76666],
              934: [0, 0.68333, 0.05986, 0, 0.71555],
              936: [0, 0.68333, 0.11111, 0, 0.76666],
              937: [0, 0.68333, 0.10257, 0, 0.71555],
              8211: [0, 0.43056, 0.09208, 0, 0.51111],
              8212: [0, 0.43056, 0.09208, 0, 1.02222],
              8216: [0, 0.69444, 0.12417, 0, 0.30667],
              8217: [0, 0.69444, 0.12417, 0, 0.30667],
              8220: [0, 0.69444, 0.1685, 0, 0.51444],
              8221: [0, 0.69444, 0.06961, 0, 0.51444],
              8463: [0, 0.68889, 0, 0, 0.54028]
            },
            "Main-Regular": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0, 0, 0.27778],
              34: [0, 0.69444, 0, 0, 0.5],
              35: [0.19444, 0.69444, 0, 0, 0.83334],
              36: [0.05556, 0.75, 0, 0, 0.5],
              37: [0.05556, 0.75, 0, 0, 0.83334],
              38: [0, 0.69444, 0, 0, 0.77778],
              39: [0, 0.69444, 0, 0, 0.27778],
              40: [0.25, 0.75, 0, 0, 0.38889],
              41: [0.25, 0.75, 0, 0, 0.38889],
              42: [0, 0.75, 0, 0, 0.5],
              43: [0.08333, 0.58333, 0, 0, 0.77778],
              44: [0.19444, 0.10556, 0, 0, 0.27778],
              45: [0, 0.43056, 0, 0, 0.33333],
              46: [0, 0.10556, 0, 0, 0.27778],
              47: [0.25, 0.75, 0, 0, 0.5],
              48: [0, 0.64444, 0, 0, 0.5],
              49: [0, 0.64444, 0, 0, 0.5],
              50: [0, 0.64444, 0, 0, 0.5],
              51: [0, 0.64444, 0, 0, 0.5],
              52: [0, 0.64444, 0, 0, 0.5],
              53: [0, 0.64444, 0, 0, 0.5],
              54: [0, 0.64444, 0, 0, 0.5],
              55: [0, 0.64444, 0, 0, 0.5],
              56: [0, 0.64444, 0, 0, 0.5],
              57: [0, 0.64444, 0, 0, 0.5],
              58: [0, 0.43056, 0, 0, 0.27778],
              59: [0.19444, 0.43056, 0, 0, 0.27778],
              60: [0.0391, 0.5391, 0, 0, 0.77778],
              61: [-0.13313, 0.36687, 0, 0, 0.77778],
              62: [0.0391, 0.5391, 0, 0, 0.77778],
              63: [0, 0.69444, 0, 0, 0.47222],
              64: [0, 0.69444, 0, 0, 0.77778],
              65: [0, 0.68333, 0, 0, 0.75],
              66: [0, 0.68333, 0, 0, 0.70834],
              67: [0, 0.68333, 0, 0, 0.72222],
              68: [0, 0.68333, 0, 0, 0.76389],
              69: [0, 0.68333, 0, 0, 0.68056],
              70: [0, 0.68333, 0, 0, 0.65278],
              71: [0, 0.68333, 0, 0, 0.78472],
              72: [0, 0.68333, 0, 0, 0.75],
              73: [0, 0.68333, 0, 0, 0.36111],
              74: [0, 0.68333, 0, 0, 0.51389],
              75: [0, 0.68333, 0, 0, 0.77778],
              76: [0, 0.68333, 0, 0, 0.625],
              77: [0, 0.68333, 0, 0, 0.91667],
              78: [0, 0.68333, 0, 0, 0.75],
              79: [0, 0.68333, 0, 0, 0.77778],
              80: [0, 0.68333, 0, 0, 0.68056],
              81: [0.19444, 0.68333, 0, 0, 0.77778],
              82: [0, 0.68333, 0, 0, 0.73611],
              83: [0, 0.68333, 0, 0, 0.55556],
              84: [0, 0.68333, 0, 0, 0.72222],
              85: [0, 0.68333, 0, 0, 0.75],
              86: [0, 0.68333, 0.01389, 0, 0.75],
              87: [0, 0.68333, 0.01389, 0, 1.02778],
              88: [0, 0.68333, 0, 0, 0.75],
              89: [0, 0.68333, 0.025, 0, 0.75],
              90: [0, 0.68333, 0, 0, 0.61111],
              91: [0.25, 0.75, 0, 0, 0.27778],
              92: [0.25, 0.75, 0, 0, 0.5],
              93: [0.25, 0.75, 0, 0, 0.27778],
              94: [0, 0.69444, 0, 0, 0.5],
              95: [0.31, 0.12056, 0.02778, 0, 0.5],
              97: [0, 0.43056, 0, 0, 0.5],
              98: [0, 0.69444, 0, 0, 0.55556],
              99: [0, 0.43056, 0, 0, 0.44445],
              100: [0, 0.69444, 0, 0, 0.55556],
              101: [0, 0.43056, 0, 0, 0.44445],
              102: [0, 0.69444, 0.07778, 0, 0.30556],
              103: [0.19444, 0.43056, 0.01389, 0, 0.5],
              104: [0, 0.69444, 0, 0, 0.55556],
              105: [0, 0.66786, 0, 0, 0.27778],
              106: [0.19444, 0.66786, 0, 0, 0.30556],
              107: [0, 0.69444, 0, 0, 0.52778],
              108: [0, 0.69444, 0, 0, 0.27778],
              109: [0, 0.43056, 0, 0, 0.83334],
              110: [0, 0.43056, 0, 0, 0.55556],
              111: [0, 0.43056, 0, 0, 0.5],
              112: [0.19444, 0.43056, 0, 0, 0.55556],
              113: [0.19444, 0.43056, 0, 0, 0.52778],
              114: [0, 0.43056, 0, 0, 0.39167],
              115: [0, 0.43056, 0, 0, 0.39445],
              116: [0, 0.61508, 0, 0, 0.38889],
              117: [0, 0.43056, 0, 0, 0.55556],
              118: [0, 0.43056, 0.01389, 0, 0.52778],
              119: [0, 0.43056, 0.01389, 0, 0.72222],
              120: [0, 0.43056, 0, 0, 0.52778],
              121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
              122: [0, 0.43056, 0, 0, 0.44445],
              123: [0.25, 0.75, 0, 0, 0.5],
              124: [0.25, 0.75, 0, 0, 0.27778],
              125: [0.25, 0.75, 0, 0, 0.5],
              126: [0.35, 0.31786, 0, 0, 0.5],
              160: [0, 0, 0, 0, 0.25],
              163: [0, 0.69444, 0, 0, 0.76909],
              167: [0.19444, 0.69444, 0, 0, 0.44445],
              168: [0, 0.66786, 0, 0, 0.5],
              172: [0, 0.43056, 0, 0, 0.66667],
              176: [0, 0.69444, 0, 0, 0.75],
              177: [0.08333, 0.58333, 0, 0, 0.77778],
              182: [0.19444, 0.69444, 0, 0, 0.61111],
              184: [0.17014, 0, 0, 0, 0.44445],
              198: [0, 0.68333, 0, 0, 0.90278],
              215: [0.08333, 0.58333, 0, 0, 0.77778],
              216: [0.04861, 0.73194, 0, 0, 0.77778],
              223: [0, 0.69444, 0, 0, 0.5],
              230: [0, 0.43056, 0, 0, 0.72222],
              247: [0.08333, 0.58333, 0, 0, 0.77778],
              248: [0.09722, 0.52778, 0, 0, 0.5],
              305: [0, 0.43056, 0, 0, 0.27778],
              338: [0, 0.68333, 0, 0, 1.01389],
              339: [0, 0.43056, 0, 0, 0.77778],
              567: [0.19444, 0.43056, 0, 0, 0.30556],
              710: [0, 0.69444, 0, 0, 0.5],
              711: [0, 0.62847, 0, 0, 0.5],
              713: [0, 0.56778, 0, 0, 0.5],
              714: [0, 0.69444, 0, 0, 0.5],
              715: [0, 0.69444, 0, 0, 0.5],
              728: [0, 0.69444, 0, 0, 0.5],
              729: [0, 0.66786, 0, 0, 0.27778],
              730: [0, 0.69444, 0, 0, 0.75],
              732: [0, 0.66786, 0, 0, 0.5],
              733: [0, 0.69444, 0, 0, 0.5],
              915: [0, 0.68333, 0, 0, 0.625],
              916: [0, 0.68333, 0, 0, 0.83334],
              920: [0, 0.68333, 0, 0, 0.77778],
              923: [0, 0.68333, 0, 0, 0.69445],
              926: [0, 0.68333, 0, 0, 0.66667],
              928: [0, 0.68333, 0, 0, 0.75],
              931: [0, 0.68333, 0, 0, 0.72222],
              933: [0, 0.68333, 0, 0, 0.77778],
              934: [0, 0.68333, 0, 0, 0.72222],
              936: [0, 0.68333, 0, 0, 0.77778],
              937: [0, 0.68333, 0, 0, 0.72222],
              8211: [0, 0.43056, 0.02778, 0, 0.5],
              8212: [0, 0.43056, 0.02778, 0, 1],
              8216: [0, 0.69444, 0, 0, 0.27778],
              8217: [0, 0.69444, 0, 0, 0.27778],
              8220: [0, 0.69444, 0, 0, 0.5],
              8221: [0, 0.69444, 0, 0, 0.5],
              8224: [0.19444, 0.69444, 0, 0, 0.44445],
              8225: [0.19444, 0.69444, 0, 0, 0.44445],
              8230: [0, 0.123, 0, 0, 1.172],
              8242: [0, 0.55556, 0, 0, 0.275],
              8407: [0, 0.71444, 0.15382, 0, 0.5],
              8463: [0, 0.68889, 0, 0, 0.54028],
              8465: [0, 0.69444, 0, 0, 0.72222],
              8467: [0, 0.69444, 0, 0.11111, 0.41667],
              8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
              8476: [0, 0.69444, 0, 0, 0.72222],
              8501: [0, 0.69444, 0, 0, 0.61111],
              8592: [-0.13313, 0.36687, 0, 0, 1],
              8593: [0.19444, 0.69444, 0, 0, 0.5],
              8594: [-0.13313, 0.36687, 0, 0, 1],
              8595: [0.19444, 0.69444, 0, 0, 0.5],
              8596: [-0.13313, 0.36687, 0, 0, 1],
              8597: [0.25, 0.75, 0, 0, 0.5],
              8598: [0.19444, 0.69444, 0, 0, 1],
              8599: [0.19444, 0.69444, 0, 0, 1],
              8600: [0.19444, 0.69444, 0, 0, 1],
              8601: [0.19444, 0.69444, 0, 0, 1],
              8614: [0.011, 0.511, 0, 0, 1],
              8617: [0.011, 0.511, 0, 0, 1.126],
              8618: [0.011, 0.511, 0, 0, 1.126],
              8636: [-0.13313, 0.36687, 0, 0, 1],
              8637: [-0.13313, 0.36687, 0, 0, 1],
              8640: [-0.13313, 0.36687, 0, 0, 1],
              8641: [-0.13313, 0.36687, 0, 0, 1],
              8652: [0.011, 0.671, 0, 0, 1],
              8656: [-0.13313, 0.36687, 0, 0, 1],
              8657: [0.19444, 0.69444, 0, 0, 0.61111],
              8658: [-0.13313, 0.36687, 0, 0, 1],
              8659: [0.19444, 0.69444, 0, 0, 0.61111],
              8660: [-0.13313, 0.36687, 0, 0, 1],
              8661: [0.25, 0.75, 0, 0, 0.61111],
              8704: [0, 0.69444, 0, 0, 0.55556],
              8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
              8707: [0, 0.69444, 0, 0, 0.55556],
              8709: [0.05556, 0.75, 0, 0, 0.5],
              8711: [0, 0.68333, 0, 0, 0.83334],
              8712: [0.0391, 0.5391, 0, 0, 0.66667],
              8715: [0.0391, 0.5391, 0, 0, 0.66667],
              8722: [0.08333, 0.58333, 0, 0, 0.77778],
              8723: [0.08333, 0.58333, 0, 0, 0.77778],
              8725: [0.25, 0.75, 0, 0, 0.5],
              8726: [0.25, 0.75, 0, 0, 0.5],
              8727: [-0.03472, 0.46528, 0, 0, 0.5],
              8728: [-0.05555, 0.44445, 0, 0, 0.5],
              8729: [-0.05555, 0.44445, 0, 0, 0.5],
              8730: [0.2, 0.8, 0, 0, 0.83334],
              8733: [0, 0.43056, 0, 0, 0.77778],
              8734: [0, 0.43056, 0, 0, 1],
              8736: [0, 0.69224, 0, 0, 0.72222],
              8739: [0.25, 0.75, 0, 0, 0.27778],
              8741: [0.25, 0.75, 0, 0, 0.5],
              8743: [0, 0.55556, 0, 0, 0.66667],
              8744: [0, 0.55556, 0, 0, 0.66667],
              8745: [0, 0.55556, 0, 0, 0.66667],
              8746: [0, 0.55556, 0, 0, 0.66667],
              8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
              8764: [-0.13313, 0.36687, 0, 0, 0.77778],
              8768: [0.19444, 0.69444, 0, 0, 0.27778],
              8771: [-0.03625, 0.46375, 0, 0, 0.77778],
              8773: [-0.022, 0.589, 0, 0, 0.778],
              8776: [-0.01688, 0.48312, 0, 0, 0.77778],
              8781: [-0.03625, 0.46375, 0, 0, 0.77778],
              8784: [-0.133, 0.673, 0, 0, 0.778],
              8801: [-0.03625, 0.46375, 0, 0, 0.77778],
              8804: [0.13597, 0.63597, 0, 0, 0.77778],
              8805: [0.13597, 0.63597, 0, 0, 0.77778],
              8810: [0.0391, 0.5391, 0, 0, 1],
              8811: [0.0391, 0.5391, 0, 0, 1],
              8826: [0.0391, 0.5391, 0, 0, 0.77778],
              8827: [0.0391, 0.5391, 0, 0, 0.77778],
              8834: [0.0391, 0.5391, 0, 0, 0.77778],
              8835: [0.0391, 0.5391, 0, 0, 0.77778],
              8838: [0.13597, 0.63597, 0, 0, 0.77778],
              8839: [0.13597, 0.63597, 0, 0, 0.77778],
              8846: [0, 0.55556, 0, 0, 0.66667],
              8849: [0.13597, 0.63597, 0, 0, 0.77778],
              8850: [0.13597, 0.63597, 0, 0, 0.77778],
              8851: [0, 0.55556, 0, 0, 0.66667],
              8852: [0, 0.55556, 0, 0, 0.66667],
              8853: [0.08333, 0.58333, 0, 0, 0.77778],
              8854: [0.08333, 0.58333, 0, 0, 0.77778],
              8855: [0.08333, 0.58333, 0, 0, 0.77778],
              8856: [0.08333, 0.58333, 0, 0, 0.77778],
              8857: [0.08333, 0.58333, 0, 0, 0.77778],
              8866: [0, 0.69444, 0, 0, 0.61111],
              8867: [0, 0.69444, 0, 0, 0.61111],
              8868: [0, 0.69444, 0, 0, 0.77778],
              8869: [0, 0.69444, 0, 0, 0.77778],
              8872: [0.249, 0.75, 0, 0, 0.867],
              8900: [-0.05555, 0.44445, 0, 0, 0.5],
              8901: [-0.05555, 0.44445, 0, 0, 0.27778],
              8902: [-0.03472, 0.46528, 0, 0, 0.5],
              8904: [5e-3, 0.505, 0, 0, 0.9],
              8942: [0.03, 0.903, 0, 0, 0.278],
              8943: [-0.19, 0.313, 0, 0, 1.172],
              8945: [-0.1, 0.823, 0, 0, 1.282],
              8968: [0.25, 0.75, 0, 0, 0.44445],
              8969: [0.25, 0.75, 0, 0, 0.44445],
              8970: [0.25, 0.75, 0, 0, 0.44445],
              8971: [0.25, 0.75, 0, 0, 0.44445],
              8994: [-0.14236, 0.35764, 0, 0, 1],
              8995: [-0.14236, 0.35764, 0, 0, 1],
              9136: [0.244, 0.744, 0, 0, 0.412],
              9137: [0.244, 0.745, 0, 0, 0.412],
              9651: [0.19444, 0.69444, 0, 0, 0.88889],
              9657: [-0.03472, 0.46528, 0, 0, 0.5],
              9661: [0.19444, 0.69444, 0, 0, 0.88889],
              9667: [-0.03472, 0.46528, 0, 0, 0.5],
              9711: [0.19444, 0.69444, 0, 0, 1],
              9824: [0.12963, 0.69444, 0, 0, 0.77778],
              9825: [0.12963, 0.69444, 0, 0, 0.77778],
              9826: [0.12963, 0.69444, 0, 0, 0.77778],
              9827: [0.12963, 0.69444, 0, 0, 0.77778],
              9837: [0, 0.75, 0, 0, 0.38889],
              9838: [0.19444, 0.69444, 0, 0, 0.38889],
              9839: [0.19444, 0.69444, 0, 0, 0.38889],
              10216: [0.25, 0.75, 0, 0, 0.38889],
              10217: [0.25, 0.75, 0, 0, 0.38889],
              10222: [0.244, 0.744, 0, 0, 0.412],
              10223: [0.244, 0.745, 0, 0, 0.412],
              10229: [0.011, 0.511, 0, 0, 1.609],
              10230: [0.011, 0.511, 0, 0, 1.638],
              10231: [0.011, 0.511, 0, 0, 1.859],
              10232: [0.024, 0.525, 0, 0, 1.609],
              10233: [0.024, 0.525, 0, 0, 1.638],
              10234: [0.024, 0.525, 0, 0, 1.858],
              10236: [0.011, 0.511, 0, 0, 1.638],
              10815: [0, 0.68333, 0, 0, 0.75],
              10927: [0.13597, 0.63597, 0, 0, 0.77778],
              10928: [0.13597, 0.63597, 0, 0, 0.77778],
              57376: [0.19444, 0.69444, 0, 0, 0]
            },
            "Math-BoldItalic": {
              32: [0, 0, 0, 0, 0.25],
              48: [0, 0.44444, 0, 0, 0.575],
              49: [0, 0.44444, 0, 0, 0.575],
              50: [0, 0.44444, 0, 0, 0.575],
              51: [0.19444, 0.44444, 0, 0, 0.575],
              52: [0.19444, 0.44444, 0, 0, 0.575],
              53: [0.19444, 0.44444, 0, 0, 0.575],
              54: [0, 0.64444, 0, 0, 0.575],
              55: [0.19444, 0.44444, 0, 0, 0.575],
              56: [0, 0.64444, 0, 0, 0.575],
              57: [0.19444, 0.44444, 0, 0, 0.575],
              65: [0, 0.68611, 0, 0, 0.86944],
              66: [0, 0.68611, 0.04835, 0, 0.8664],
              67: [0, 0.68611, 0.06979, 0, 0.81694],
              68: [0, 0.68611, 0.03194, 0, 0.93812],
              69: [0, 0.68611, 0.05451, 0, 0.81007],
              70: [0, 0.68611, 0.15972, 0, 0.68889],
              71: [0, 0.68611, 0, 0, 0.88673],
              72: [0, 0.68611, 0.08229, 0, 0.98229],
              73: [0, 0.68611, 0.07778, 0, 0.51111],
              74: [0, 0.68611, 0.10069, 0, 0.63125],
              75: [0, 0.68611, 0.06979, 0, 0.97118],
              76: [0, 0.68611, 0, 0, 0.75555],
              77: [0, 0.68611, 0.11424, 0, 1.14201],
              78: [0, 0.68611, 0.11424, 0, 0.95034],
              79: [0, 0.68611, 0.03194, 0, 0.83666],
              80: [0, 0.68611, 0.15972, 0, 0.72309],
              81: [0.19444, 0.68611, 0, 0, 0.86861],
              82: [0, 0.68611, 421e-5, 0, 0.87235],
              83: [0, 0.68611, 0.05382, 0, 0.69271],
              84: [0, 0.68611, 0.15972, 0, 0.63663],
              85: [0, 0.68611, 0.11424, 0, 0.80027],
              86: [0, 0.68611, 0.25555, 0, 0.67778],
              87: [0, 0.68611, 0.15972, 0, 1.09305],
              88: [0, 0.68611, 0.07778, 0, 0.94722],
              89: [0, 0.68611, 0.25555, 0, 0.67458],
              90: [0, 0.68611, 0.06979, 0, 0.77257],
              97: [0, 0.44444, 0, 0, 0.63287],
              98: [0, 0.69444, 0, 0, 0.52083],
              99: [0, 0.44444, 0, 0, 0.51342],
              100: [0, 0.69444, 0, 0, 0.60972],
              101: [0, 0.44444, 0, 0, 0.55361],
              102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
              103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
              104: [0, 0.69444, 0, 0, 0.66759],
              105: [0, 0.69326, 0, 0, 0.4048],
              106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
              107: [0, 0.69444, 0.01852, 0, 0.6037],
              108: [0, 0.69444, 88e-4, 0, 0.34815],
              109: [0, 0.44444, 0, 0, 1.0324],
              110: [0, 0.44444, 0, 0, 0.71296],
              111: [0, 0.44444, 0, 0, 0.58472],
              112: [0.19444, 0.44444, 0, 0, 0.60092],
              113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
              114: [0, 0.44444, 0.03194, 0, 0.5287],
              115: [0, 0.44444, 0, 0, 0.53125],
              116: [0, 0.63492, 0, 0, 0.41528],
              117: [0, 0.44444, 0, 0, 0.68102],
              118: [0, 0.44444, 0.03704, 0, 0.56666],
              119: [0, 0.44444, 0.02778, 0, 0.83148],
              120: [0, 0.44444, 0, 0, 0.65903],
              121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
              122: [0, 0.44444, 0.04213, 0, 0.55509],
              160: [0, 0, 0, 0, 0.25],
              915: [0, 0.68611, 0.15972, 0, 0.65694],
              916: [0, 0.68611, 0, 0, 0.95833],
              920: [0, 0.68611, 0.03194, 0, 0.86722],
              923: [0, 0.68611, 0, 0, 0.80555],
              926: [0, 0.68611, 0.07458, 0, 0.84125],
              928: [0, 0.68611, 0.08229, 0, 0.98229],
              931: [0, 0.68611, 0.05451, 0, 0.88507],
              933: [0, 0.68611, 0.15972, 0, 0.67083],
              934: [0, 0.68611, 0, 0, 0.76666],
              936: [0, 0.68611, 0.11653, 0, 0.71402],
              937: [0, 0.68611, 0.04835, 0, 0.8789],
              945: [0, 0.44444, 0, 0, 0.76064],
              946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
              947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
              948: [0, 0.69444, 0.03819, 0, 0.52222],
              949: [0, 0.44444, 0, 0, 0.52882],
              950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
              951: [0.19444, 0.44444, 0.03704, 0, 0.6],
              952: [0, 0.69444, 0.03194, 0, 0.5618],
              953: [0, 0.44444, 0, 0, 0.41204],
              954: [0, 0.44444, 0, 0, 0.66759],
              955: [0, 0.69444, 0, 0, 0.67083],
              956: [0.19444, 0.44444, 0, 0, 0.70787],
              957: [0, 0.44444, 0.06898, 0, 0.57685],
              958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
              959: [0, 0.44444, 0, 0, 0.58472],
              960: [0, 0.44444, 0.03704, 0, 0.68241],
              961: [0.19444, 0.44444, 0, 0, 0.6118],
              962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
              963: [0, 0.44444, 0.03704, 0, 0.68588],
              964: [0, 0.44444, 0.13472, 0, 0.52083],
              965: [0, 0.44444, 0.03704, 0, 0.63055],
              966: [0.19444, 0.44444, 0, 0, 0.74722],
              967: [0.19444, 0.44444, 0, 0, 0.71805],
              968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
              969: [0, 0.44444, 0.03704, 0, 0.71782],
              977: [0, 0.69444, 0, 0, 0.69155],
              981: [0.19444, 0.69444, 0, 0, 0.7125],
              982: [0, 0.44444, 0.03194, 0, 0.975],
              1009: [0.19444, 0.44444, 0, 0, 0.6118],
              1013: [0, 0.44444, 0, 0, 0.48333],
              57649: [0, 0.44444, 0, 0, 0.39352],
              57911: [0.19444, 0.44444, 0, 0, 0.43889]
            },
            "Math-Italic": {
              32: [0, 0, 0, 0, 0.25],
              48: [0, 0.43056, 0, 0, 0.5],
              49: [0, 0.43056, 0, 0, 0.5],
              50: [0, 0.43056, 0, 0, 0.5],
              51: [0.19444, 0.43056, 0, 0, 0.5],
              52: [0.19444, 0.43056, 0, 0, 0.5],
              53: [0.19444, 0.43056, 0, 0, 0.5],
              54: [0, 0.64444, 0, 0, 0.5],
              55: [0.19444, 0.43056, 0, 0, 0.5],
              56: [0, 0.64444, 0, 0, 0.5],
              57: [0.19444, 0.43056, 0, 0, 0.5],
              65: [0, 0.68333, 0, 0.13889, 0.75],
              66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
              67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
              68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
              69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
              70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
              71: [0, 0.68333, 0, 0.08334, 0.78625],
              72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
              73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
              74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
              75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
              76: [0, 0.68333, 0, 0.02778, 0.68056],
              77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
              78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
              79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
              80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
              81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
              82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
              83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
              84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
              85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
              86: [0, 0.68333, 0.22222, 0, 0.58333],
              87: [0, 0.68333, 0.13889, 0, 0.94445],
              88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
              89: [0, 0.68333, 0.22222, 0, 0.58056],
              90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
              97: [0, 0.43056, 0, 0, 0.52859],
              98: [0, 0.69444, 0, 0, 0.42917],
              99: [0, 0.43056, 0, 0.05556, 0.43276],
              100: [0, 0.69444, 0, 0.16667, 0.52049],
              101: [0, 0.43056, 0, 0.05556, 0.46563],
              102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
              103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
              104: [0, 0.69444, 0, 0, 0.57616],
              105: [0, 0.65952, 0, 0, 0.34451],
              106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
              107: [0, 0.69444, 0.03148, 0, 0.5206],
              108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
              109: [0, 0.43056, 0, 0, 0.87801],
              110: [0, 0.43056, 0, 0, 0.60023],
              111: [0, 0.43056, 0, 0.05556, 0.48472],
              112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
              113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
              114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
              115: [0, 0.43056, 0, 0.05556, 0.46875],
              116: [0, 0.61508, 0, 0.08334, 0.36111],
              117: [0, 0.43056, 0, 0.02778, 0.57246],
              118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
              119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
              120: [0, 0.43056, 0, 0.02778, 0.57153],
              121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
              122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
              160: [0, 0, 0, 0, 0.25],
              915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
              916: [0, 0.68333, 0, 0.16667, 0.83334],
              920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
              923: [0, 0.68333, 0, 0.16667, 0.69445],
              926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
              928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
              931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
              933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
              934: [0, 0.68333, 0, 0.08334, 0.66667],
              936: [0, 0.68333, 0.11, 0.05556, 0.61222],
              937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
              945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
              946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
              947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
              948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
              949: [0, 0.43056, 0, 0.08334, 0.46632],
              950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
              951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
              952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
              953: [0, 0.43056, 0, 0.05556, 0.35394],
              954: [0, 0.43056, 0, 0, 0.57616],
              955: [0, 0.69444, 0, 0, 0.58334],
              956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
              957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
              958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
              959: [0, 0.43056, 0, 0.05556, 0.48472],
              960: [0, 0.43056, 0.03588, 0, 0.57003],
              961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
              962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
              963: [0, 0.43056, 0.03588, 0, 0.57141],
              964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
              965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
              966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
              967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
              968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
              969: [0, 0.43056, 0.03588, 0, 0.62245],
              977: [0, 0.69444, 0, 0.08334, 0.59144],
              981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
              982: [0, 0.43056, 0.02778, 0, 0.82813],
              1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
              1013: [0, 0.43056, 0, 0.05556, 0.4059],
              57649: [0, 0.43056, 0, 0.02778, 0.32246],
              57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
            },
            "SansSerif-Bold": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0, 0, 0.36667],
              34: [0, 0.69444, 0, 0, 0.55834],
              35: [0.19444, 0.69444, 0, 0, 0.91667],
              36: [0.05556, 0.75, 0, 0, 0.55],
              37: [0.05556, 0.75, 0, 0, 1.02912],
              38: [0, 0.69444, 0, 0, 0.83056],
              39: [0, 0.69444, 0, 0, 0.30556],
              40: [0.25, 0.75, 0, 0, 0.42778],
              41: [0.25, 0.75, 0, 0, 0.42778],
              42: [0, 0.75, 0, 0, 0.55],
              43: [0.11667, 0.61667, 0, 0, 0.85556],
              44: [0.10556, 0.13056, 0, 0, 0.30556],
              45: [0, 0.45833, 0, 0, 0.36667],
              46: [0, 0.13056, 0, 0, 0.30556],
              47: [0.25, 0.75, 0, 0, 0.55],
              48: [0, 0.69444, 0, 0, 0.55],
              49: [0, 0.69444, 0, 0, 0.55],
              50: [0, 0.69444, 0, 0, 0.55],
              51: [0, 0.69444, 0, 0, 0.55],
              52: [0, 0.69444, 0, 0, 0.55],
              53: [0, 0.69444, 0, 0, 0.55],
              54: [0, 0.69444, 0, 0, 0.55],
              55: [0, 0.69444, 0, 0, 0.55],
              56: [0, 0.69444, 0, 0, 0.55],
              57: [0, 0.69444, 0, 0, 0.55],
              58: [0, 0.45833, 0, 0, 0.30556],
              59: [0.10556, 0.45833, 0, 0, 0.30556],
              61: [-0.09375, 0.40625, 0, 0, 0.85556],
              63: [0, 0.69444, 0, 0, 0.51945],
              64: [0, 0.69444, 0, 0, 0.73334],
              65: [0, 0.69444, 0, 0, 0.73334],
              66: [0, 0.69444, 0, 0, 0.73334],
              67: [0, 0.69444, 0, 0, 0.70278],
              68: [0, 0.69444, 0, 0, 0.79445],
              69: [0, 0.69444, 0, 0, 0.64167],
              70: [0, 0.69444, 0, 0, 0.61111],
              71: [0, 0.69444, 0, 0, 0.73334],
              72: [0, 0.69444, 0, 0, 0.79445],
              73: [0, 0.69444, 0, 0, 0.33056],
              74: [0, 0.69444, 0, 0, 0.51945],
              75: [0, 0.69444, 0, 0, 0.76389],
              76: [0, 0.69444, 0, 0, 0.58056],
              77: [0, 0.69444, 0, 0, 0.97778],
              78: [0, 0.69444, 0, 0, 0.79445],
              79: [0, 0.69444, 0, 0, 0.79445],
              80: [0, 0.69444, 0, 0, 0.70278],
              81: [0.10556, 0.69444, 0, 0, 0.79445],
              82: [0, 0.69444, 0, 0, 0.70278],
              83: [0, 0.69444, 0, 0, 0.61111],
              84: [0, 0.69444, 0, 0, 0.73334],
              85: [0, 0.69444, 0, 0, 0.76389],
              86: [0, 0.69444, 0.01528, 0, 0.73334],
              87: [0, 0.69444, 0.01528, 0, 1.03889],
              88: [0, 0.69444, 0, 0, 0.73334],
              89: [0, 0.69444, 0.0275, 0, 0.73334],
              90: [0, 0.69444, 0, 0, 0.67223],
              91: [0.25, 0.75, 0, 0, 0.34306],
              93: [0.25, 0.75, 0, 0, 0.34306],
              94: [0, 0.69444, 0, 0, 0.55],
              95: [0.35, 0.10833, 0.03056, 0, 0.55],
              97: [0, 0.45833, 0, 0, 0.525],
              98: [0, 0.69444, 0, 0, 0.56111],
              99: [0, 0.45833, 0, 0, 0.48889],
              100: [0, 0.69444, 0, 0, 0.56111],
              101: [0, 0.45833, 0, 0, 0.51111],
              102: [0, 0.69444, 0.07639, 0, 0.33611],
              103: [0.19444, 0.45833, 0.01528, 0, 0.55],
              104: [0, 0.69444, 0, 0, 0.56111],
              105: [0, 0.69444, 0, 0, 0.25556],
              106: [0.19444, 0.69444, 0, 0, 0.28611],
              107: [0, 0.69444, 0, 0, 0.53056],
              108: [0, 0.69444, 0, 0, 0.25556],
              109: [0, 0.45833, 0, 0, 0.86667],
              110: [0, 0.45833, 0, 0, 0.56111],
              111: [0, 0.45833, 0, 0, 0.55],
              112: [0.19444, 0.45833, 0, 0, 0.56111],
              113: [0.19444, 0.45833, 0, 0, 0.56111],
              114: [0, 0.45833, 0.01528, 0, 0.37222],
              115: [0, 0.45833, 0, 0, 0.42167],
              116: [0, 0.58929, 0, 0, 0.40417],
              117: [0, 0.45833, 0, 0, 0.56111],
              118: [0, 0.45833, 0.01528, 0, 0.5],
              119: [0, 0.45833, 0.01528, 0, 0.74445],
              120: [0, 0.45833, 0, 0, 0.5],
              121: [0.19444, 0.45833, 0.01528, 0, 0.5],
              122: [0, 0.45833, 0, 0, 0.47639],
              126: [0.35, 0.34444, 0, 0, 0.55],
              160: [0, 0, 0, 0, 0.25],
              168: [0, 0.69444, 0, 0, 0.55],
              176: [0, 0.69444, 0, 0, 0.73334],
              180: [0, 0.69444, 0, 0, 0.55],
              184: [0.17014, 0, 0, 0, 0.48889],
              305: [0, 0.45833, 0, 0, 0.25556],
              567: [0.19444, 0.45833, 0, 0, 0.28611],
              710: [0, 0.69444, 0, 0, 0.55],
              711: [0, 0.63542, 0, 0, 0.55],
              713: [0, 0.63778, 0, 0, 0.55],
              728: [0, 0.69444, 0, 0, 0.55],
              729: [0, 0.69444, 0, 0, 0.30556],
              730: [0, 0.69444, 0, 0, 0.73334],
              732: [0, 0.69444, 0, 0, 0.55],
              733: [0, 0.69444, 0, 0, 0.55],
              915: [0, 0.69444, 0, 0, 0.58056],
              916: [0, 0.69444, 0, 0, 0.91667],
              920: [0, 0.69444, 0, 0, 0.85556],
              923: [0, 0.69444, 0, 0, 0.67223],
              926: [0, 0.69444, 0, 0, 0.73334],
              928: [0, 0.69444, 0, 0, 0.79445],
              931: [0, 0.69444, 0, 0, 0.79445],
              933: [0, 0.69444, 0, 0, 0.85556],
              934: [0, 0.69444, 0, 0, 0.79445],
              936: [0, 0.69444, 0, 0, 0.85556],
              937: [0, 0.69444, 0, 0, 0.79445],
              8211: [0, 0.45833, 0.03056, 0, 0.55],
              8212: [0, 0.45833, 0.03056, 0, 1.10001],
              8216: [0, 0.69444, 0, 0, 0.30556],
              8217: [0, 0.69444, 0, 0, 0.30556],
              8220: [0, 0.69444, 0, 0, 0.55834],
              8221: [0, 0.69444, 0, 0, 0.55834]
            },
            "SansSerif-Italic": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0.05733, 0, 0.31945],
              34: [0, 0.69444, 316e-5, 0, 0.5],
              35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
              36: [0.05556, 0.75, 0.11156, 0, 0.5],
              37: [0.05556, 0.75, 0.03126, 0, 0.83334],
              38: [0, 0.69444, 0.03058, 0, 0.75834],
              39: [0, 0.69444, 0.07816, 0, 0.27778],
              40: [0.25, 0.75, 0.13164, 0, 0.38889],
              41: [0.25, 0.75, 0.02536, 0, 0.38889],
              42: [0, 0.75, 0.11775, 0, 0.5],
              43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
              44: [0.125, 0.08333, 0, 0, 0.27778],
              45: [0, 0.44444, 0.01946, 0, 0.33333],
              46: [0, 0.08333, 0, 0, 0.27778],
              47: [0.25, 0.75, 0.13164, 0, 0.5],
              48: [0, 0.65556, 0.11156, 0, 0.5],
              49: [0, 0.65556, 0.11156, 0, 0.5],
              50: [0, 0.65556, 0.11156, 0, 0.5],
              51: [0, 0.65556, 0.11156, 0, 0.5],
              52: [0, 0.65556, 0.11156, 0, 0.5],
              53: [0, 0.65556, 0.11156, 0, 0.5],
              54: [0, 0.65556, 0.11156, 0, 0.5],
              55: [0, 0.65556, 0.11156, 0, 0.5],
              56: [0, 0.65556, 0.11156, 0, 0.5],
              57: [0, 0.65556, 0.11156, 0, 0.5],
              58: [0, 0.44444, 0.02502, 0, 0.27778],
              59: [0.125, 0.44444, 0.02502, 0, 0.27778],
              61: [-0.13, 0.37, 0.05087, 0, 0.77778],
              63: [0, 0.69444, 0.11809, 0, 0.47222],
              64: [0, 0.69444, 0.07555, 0, 0.66667],
              65: [0, 0.69444, 0, 0, 0.66667],
              66: [0, 0.69444, 0.08293, 0, 0.66667],
              67: [0, 0.69444, 0.11983, 0, 0.63889],
              68: [0, 0.69444, 0.07555, 0, 0.72223],
              69: [0, 0.69444, 0.11983, 0, 0.59722],
              70: [0, 0.69444, 0.13372, 0, 0.56945],
              71: [0, 0.69444, 0.11983, 0, 0.66667],
              72: [0, 0.69444, 0.08094, 0, 0.70834],
              73: [0, 0.69444, 0.13372, 0, 0.27778],
              74: [0, 0.69444, 0.08094, 0, 0.47222],
              75: [0, 0.69444, 0.11983, 0, 0.69445],
              76: [0, 0.69444, 0, 0, 0.54167],
              77: [0, 0.69444, 0.08094, 0, 0.875],
              78: [0, 0.69444, 0.08094, 0, 0.70834],
              79: [0, 0.69444, 0.07555, 0, 0.73611],
              80: [0, 0.69444, 0.08293, 0, 0.63889],
              81: [0.125, 0.69444, 0.07555, 0, 0.73611],
              82: [0, 0.69444, 0.08293, 0, 0.64584],
              83: [0, 0.69444, 0.09205, 0, 0.55556],
              84: [0, 0.69444, 0.13372, 0, 0.68056],
              85: [0, 0.69444, 0.08094, 0, 0.6875],
              86: [0, 0.69444, 0.1615, 0, 0.66667],
              87: [0, 0.69444, 0.1615, 0, 0.94445],
              88: [0, 0.69444, 0.13372, 0, 0.66667],
              89: [0, 0.69444, 0.17261, 0, 0.66667],
              90: [0, 0.69444, 0.11983, 0, 0.61111],
              91: [0.25, 0.75, 0.15942, 0, 0.28889],
              93: [0.25, 0.75, 0.08719, 0, 0.28889],
              94: [0, 0.69444, 0.0799, 0, 0.5],
              95: [0.35, 0.09444, 0.08616, 0, 0.5],
              97: [0, 0.44444, 981e-5, 0, 0.48056],
              98: [0, 0.69444, 0.03057, 0, 0.51667],
              99: [0, 0.44444, 0.08336, 0, 0.44445],
              100: [0, 0.69444, 0.09483, 0, 0.51667],
              101: [0, 0.44444, 0.06778, 0, 0.44445],
              102: [0, 0.69444, 0.21705, 0, 0.30556],
              103: [0.19444, 0.44444, 0.10836, 0, 0.5],
              104: [0, 0.69444, 0.01778, 0, 0.51667],
              105: [0, 0.67937, 0.09718, 0, 0.23889],
              106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
              107: [0, 0.69444, 0.08336, 0, 0.48889],
              108: [0, 0.69444, 0.09483, 0, 0.23889],
              109: [0, 0.44444, 0.01778, 0, 0.79445],
              110: [0, 0.44444, 0.01778, 0, 0.51667],
              111: [0, 0.44444, 0.06613, 0, 0.5],
              112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
              113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
              114: [0, 0.44444, 0.10836, 0, 0.34167],
              115: [0, 0.44444, 0.0778, 0, 0.38333],
              116: [0, 0.57143, 0.07225, 0, 0.36111],
              117: [0, 0.44444, 0.04169, 0, 0.51667],
              118: [0, 0.44444, 0.10836, 0, 0.46111],
              119: [0, 0.44444, 0.10836, 0, 0.68334],
              120: [0, 0.44444, 0.09169, 0, 0.46111],
              121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
              122: [0, 0.44444, 0.08752, 0, 0.43472],
              126: [0.35, 0.32659, 0.08826, 0, 0.5],
              160: [0, 0, 0, 0, 0.25],
              168: [0, 0.67937, 0.06385, 0, 0.5],
              176: [0, 0.69444, 0, 0, 0.73752],
              184: [0.17014, 0, 0, 0, 0.44445],
              305: [0, 0.44444, 0.04169, 0, 0.23889],
              567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
              710: [0, 0.69444, 0.0799, 0, 0.5],
              711: [0, 0.63194, 0.08432, 0, 0.5],
              713: [0, 0.60889, 0.08776, 0, 0.5],
              714: [0, 0.69444, 0.09205, 0, 0.5],
              715: [0, 0.69444, 0, 0, 0.5],
              728: [0, 0.69444, 0.09483, 0, 0.5],
              729: [0, 0.67937, 0.07774, 0, 0.27778],
              730: [0, 0.69444, 0, 0, 0.73752],
              732: [0, 0.67659, 0.08826, 0, 0.5],
              733: [0, 0.69444, 0.09205, 0, 0.5],
              915: [0, 0.69444, 0.13372, 0, 0.54167],
              916: [0, 0.69444, 0, 0, 0.83334],
              920: [0, 0.69444, 0.07555, 0, 0.77778],
              923: [0, 0.69444, 0, 0, 0.61111],
              926: [0, 0.69444, 0.12816, 0, 0.66667],
              928: [0, 0.69444, 0.08094, 0, 0.70834],
              931: [0, 0.69444, 0.11983, 0, 0.72222],
              933: [0, 0.69444, 0.09031, 0, 0.77778],
              934: [0, 0.69444, 0.04603, 0, 0.72222],
              936: [0, 0.69444, 0.09031, 0, 0.77778],
              937: [0, 0.69444, 0.08293, 0, 0.72222],
              8211: [0, 0.44444, 0.08616, 0, 0.5],
              8212: [0, 0.44444, 0.08616, 0, 1],
              8216: [0, 0.69444, 0.07816, 0, 0.27778],
              8217: [0, 0.69444, 0.07816, 0, 0.27778],
              8220: [0, 0.69444, 0.14205, 0, 0.5],
              8221: [0, 0.69444, 316e-5, 0, 0.5]
            },
            "SansSerif-Regular": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0, 0, 0.31945],
              34: [0, 0.69444, 0, 0, 0.5],
              35: [0.19444, 0.69444, 0, 0, 0.83334],
              36: [0.05556, 0.75, 0, 0, 0.5],
              37: [0.05556, 0.75, 0, 0, 0.83334],
              38: [0, 0.69444, 0, 0, 0.75834],
              39: [0, 0.69444, 0, 0, 0.27778],
              40: [0.25, 0.75, 0, 0, 0.38889],
              41: [0.25, 0.75, 0, 0, 0.38889],
              42: [0, 0.75, 0, 0, 0.5],
              43: [0.08333, 0.58333, 0, 0, 0.77778],
              44: [0.125, 0.08333, 0, 0, 0.27778],
              45: [0, 0.44444, 0, 0, 0.33333],
              46: [0, 0.08333, 0, 0, 0.27778],
              47: [0.25, 0.75, 0, 0, 0.5],
              48: [0, 0.65556, 0, 0, 0.5],
              49: [0, 0.65556, 0, 0, 0.5],
              50: [0, 0.65556, 0, 0, 0.5],
              51: [0, 0.65556, 0, 0, 0.5],
              52: [0, 0.65556, 0, 0, 0.5],
              53: [0, 0.65556, 0, 0, 0.5],
              54: [0, 0.65556, 0, 0, 0.5],
              55: [0, 0.65556, 0, 0, 0.5],
              56: [0, 0.65556, 0, 0, 0.5],
              57: [0, 0.65556, 0, 0, 0.5],
              58: [0, 0.44444, 0, 0, 0.27778],
              59: [0.125, 0.44444, 0, 0, 0.27778],
              61: [-0.13, 0.37, 0, 0, 0.77778],
              63: [0, 0.69444, 0, 0, 0.47222],
              64: [0, 0.69444, 0, 0, 0.66667],
              65: [0, 0.69444, 0, 0, 0.66667],
              66: [0, 0.69444, 0, 0, 0.66667],
              67: [0, 0.69444, 0, 0, 0.63889],
              68: [0, 0.69444, 0, 0, 0.72223],
              69: [0, 0.69444, 0, 0, 0.59722],
              70: [0, 0.69444, 0, 0, 0.56945],
              71: [0, 0.69444, 0, 0, 0.66667],
              72: [0, 0.69444, 0, 0, 0.70834],
              73: [0, 0.69444, 0, 0, 0.27778],
              74: [0, 0.69444, 0, 0, 0.47222],
              75: [0, 0.69444, 0, 0, 0.69445],
              76: [0, 0.69444, 0, 0, 0.54167],
              77: [0, 0.69444, 0, 0, 0.875],
              78: [0, 0.69444, 0, 0, 0.70834],
              79: [0, 0.69444, 0, 0, 0.73611],
              80: [0, 0.69444, 0, 0, 0.63889],
              81: [0.125, 0.69444, 0, 0, 0.73611],
              82: [0, 0.69444, 0, 0, 0.64584],
              83: [0, 0.69444, 0, 0, 0.55556],
              84: [0, 0.69444, 0, 0, 0.68056],
              85: [0, 0.69444, 0, 0, 0.6875],
              86: [0, 0.69444, 0.01389, 0, 0.66667],
              87: [0, 0.69444, 0.01389, 0, 0.94445],
              88: [0, 0.69444, 0, 0, 0.66667],
              89: [0, 0.69444, 0.025, 0, 0.66667],
              90: [0, 0.69444, 0, 0, 0.61111],
              91: [0.25, 0.75, 0, 0, 0.28889],
              93: [0.25, 0.75, 0, 0, 0.28889],
              94: [0, 0.69444, 0, 0, 0.5],
              95: [0.35, 0.09444, 0.02778, 0, 0.5],
              97: [0, 0.44444, 0, 0, 0.48056],
              98: [0, 0.69444, 0, 0, 0.51667],
              99: [0, 0.44444, 0, 0, 0.44445],
              100: [0, 0.69444, 0, 0, 0.51667],
              101: [0, 0.44444, 0, 0, 0.44445],
              102: [0, 0.69444, 0.06944, 0, 0.30556],
              103: [0.19444, 0.44444, 0.01389, 0, 0.5],
              104: [0, 0.69444, 0, 0, 0.51667],
              105: [0, 0.67937, 0, 0, 0.23889],
              106: [0.19444, 0.67937, 0, 0, 0.26667],
              107: [0, 0.69444, 0, 0, 0.48889],
              108: [0, 0.69444, 0, 0, 0.23889],
              109: [0, 0.44444, 0, 0, 0.79445],
              110: [0, 0.44444, 0, 0, 0.51667],
              111: [0, 0.44444, 0, 0, 0.5],
              112: [0.19444, 0.44444, 0, 0, 0.51667],
              113: [0.19444, 0.44444, 0, 0, 0.51667],
              114: [0, 0.44444, 0.01389, 0, 0.34167],
              115: [0, 0.44444, 0, 0, 0.38333],
              116: [0, 0.57143, 0, 0, 0.36111],
              117: [0, 0.44444, 0, 0, 0.51667],
              118: [0, 0.44444, 0.01389, 0, 0.46111],
              119: [0, 0.44444, 0.01389, 0, 0.68334],
              120: [0, 0.44444, 0, 0, 0.46111],
              121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
              122: [0, 0.44444, 0, 0, 0.43472],
              126: [0.35, 0.32659, 0, 0, 0.5],
              160: [0, 0, 0, 0, 0.25],
              168: [0, 0.67937, 0, 0, 0.5],
              176: [0, 0.69444, 0, 0, 0.66667],
              184: [0.17014, 0, 0, 0, 0.44445],
              305: [0, 0.44444, 0, 0, 0.23889],
              567: [0.19444, 0.44444, 0, 0, 0.26667],
              710: [0, 0.69444, 0, 0, 0.5],
              711: [0, 0.63194, 0, 0, 0.5],
              713: [0, 0.60889, 0, 0, 0.5],
              714: [0, 0.69444, 0, 0, 0.5],
              715: [0, 0.69444, 0, 0, 0.5],
              728: [0, 0.69444, 0, 0, 0.5],
              729: [0, 0.67937, 0, 0, 0.27778],
              730: [0, 0.69444, 0, 0, 0.66667],
              732: [0, 0.67659, 0, 0, 0.5],
              733: [0, 0.69444, 0, 0, 0.5],
              915: [0, 0.69444, 0, 0, 0.54167],
              916: [0, 0.69444, 0, 0, 0.83334],
              920: [0, 0.69444, 0, 0, 0.77778],
              923: [0, 0.69444, 0, 0, 0.61111],
              926: [0, 0.69444, 0, 0, 0.66667],
              928: [0, 0.69444, 0, 0, 0.70834],
              931: [0, 0.69444, 0, 0, 0.72222],
              933: [0, 0.69444, 0, 0, 0.77778],
              934: [0, 0.69444, 0, 0, 0.72222],
              936: [0, 0.69444, 0, 0, 0.77778],
              937: [0, 0.69444, 0, 0, 0.72222],
              8211: [0, 0.44444, 0.02778, 0, 0.5],
              8212: [0, 0.44444, 0.02778, 0, 1],
              8216: [0, 0.69444, 0, 0, 0.27778],
              8217: [0, 0.69444, 0, 0, 0.27778],
              8220: [0, 0.69444, 0, 0, 0.5],
              8221: [0, 0.69444, 0, 0, 0.5]
            },
            "Script-Regular": {
              32: [0, 0, 0, 0, 0.25],
              65: [0, 0.7, 0.22925, 0, 0.80253],
              66: [0, 0.7, 0.04087, 0, 0.90757],
              67: [0, 0.7, 0.1689, 0, 0.66619],
              68: [0, 0.7, 0.09371, 0, 0.77443],
              69: [0, 0.7, 0.18583, 0, 0.56162],
              70: [0, 0.7, 0.13634, 0, 0.89544],
              71: [0, 0.7, 0.17322, 0, 0.60961],
              72: [0, 0.7, 0.29694, 0, 0.96919],
              73: [0, 0.7, 0.19189, 0, 0.80907],
              74: [0.27778, 0.7, 0.19189, 0, 1.05159],
              75: [0, 0.7, 0.31259, 0, 0.91364],
              76: [0, 0.7, 0.19189, 0, 0.87373],
              77: [0, 0.7, 0.15981, 0, 1.08031],
              78: [0, 0.7, 0.3525, 0, 0.9015],
              79: [0, 0.7, 0.08078, 0, 0.73787],
              80: [0, 0.7, 0.08078, 0, 1.01262],
              81: [0, 0.7, 0.03305, 0, 0.88282],
              82: [0, 0.7, 0.06259, 0, 0.85],
              83: [0, 0.7, 0.19189, 0, 0.86767],
              84: [0, 0.7, 0.29087, 0, 0.74697],
              85: [0, 0.7, 0.25815, 0, 0.79996],
              86: [0, 0.7, 0.27523, 0, 0.62204],
              87: [0, 0.7, 0.27523, 0, 0.80532],
              88: [0, 0.7, 0.26006, 0, 0.94445],
              89: [0, 0.7, 0.2939, 0, 0.70961],
              90: [0, 0.7, 0.24037, 0, 0.8212],
              160: [0, 0, 0, 0, 0.25]
            },
            "Size1-Regular": {
              32: [0, 0, 0, 0, 0.25],
              40: [0.35001, 0.85, 0, 0, 0.45834],
              41: [0.35001, 0.85, 0, 0, 0.45834],
              47: [0.35001, 0.85, 0, 0, 0.57778],
              91: [0.35001, 0.85, 0, 0, 0.41667],
              92: [0.35001, 0.85, 0, 0, 0.57778],
              93: [0.35001, 0.85, 0, 0, 0.41667],
              123: [0.35001, 0.85, 0, 0, 0.58334],
              125: [0.35001, 0.85, 0, 0, 0.58334],
              160: [0, 0, 0, 0, 0.25],
              710: [0, 0.72222, 0, 0, 0.55556],
              732: [0, 0.72222, 0, 0, 0.55556],
              770: [0, 0.72222, 0, 0, 0.55556],
              771: [0, 0.72222, 0, 0, 0.55556],
              8214: [-99e-5, 0.601, 0, 0, 0.77778],
              8593: [1e-5, 0.6, 0, 0, 0.66667],
              8595: [1e-5, 0.6, 0, 0, 0.66667],
              8657: [1e-5, 0.6, 0, 0, 0.77778],
              8659: [1e-5, 0.6, 0, 0, 0.77778],
              8719: [0.25001, 0.75, 0, 0, 0.94445],
              8720: [0.25001, 0.75, 0, 0, 0.94445],
              8721: [0.25001, 0.75, 0, 0, 1.05556],
              8730: [0.35001, 0.85, 0, 0, 1],
              8739: [-599e-5, 0.606, 0, 0, 0.33333],
              8741: [-599e-5, 0.606, 0, 0, 0.55556],
              8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
              8748: [0.306, 0.805, 0.19445, 0, 0.47222],
              8749: [0.306, 0.805, 0.19445, 0, 0.47222],
              8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
              8896: [0.25001, 0.75, 0, 0, 0.83334],
              8897: [0.25001, 0.75, 0, 0, 0.83334],
              8898: [0.25001, 0.75, 0, 0, 0.83334],
              8899: [0.25001, 0.75, 0, 0, 0.83334],
              8968: [0.35001, 0.85, 0, 0, 0.47222],
              8969: [0.35001, 0.85, 0, 0, 0.47222],
              8970: [0.35001, 0.85, 0, 0, 0.47222],
              8971: [0.35001, 0.85, 0, 0, 0.47222],
              9168: [-99e-5, 0.601, 0, 0, 0.66667],
              10216: [0.35001, 0.85, 0, 0, 0.47222],
              10217: [0.35001, 0.85, 0, 0, 0.47222],
              10752: [0.25001, 0.75, 0, 0, 1.11111],
              10753: [0.25001, 0.75, 0, 0, 1.11111],
              10754: [0.25001, 0.75, 0, 0, 1.11111],
              10756: [0.25001, 0.75, 0, 0, 0.83334],
              10758: [0.25001, 0.75, 0, 0, 0.83334]
            },
            "Size2-Regular": {
              32: [0, 0, 0, 0, 0.25],
              40: [0.65002, 1.15, 0, 0, 0.59722],
              41: [0.65002, 1.15, 0, 0, 0.59722],
              47: [0.65002, 1.15, 0, 0, 0.81111],
              91: [0.65002, 1.15, 0, 0, 0.47222],
              92: [0.65002, 1.15, 0, 0, 0.81111],
              93: [0.65002, 1.15, 0, 0, 0.47222],
              123: [0.65002, 1.15, 0, 0, 0.66667],
              125: [0.65002, 1.15, 0, 0, 0.66667],
              160: [0, 0, 0, 0, 0.25],
              710: [0, 0.75, 0, 0, 1],
              732: [0, 0.75, 0, 0, 1],
              770: [0, 0.75, 0, 0, 1],
              771: [0, 0.75, 0, 0, 1],
              8719: [0.55001, 1.05, 0, 0, 1.27778],
              8720: [0.55001, 1.05, 0, 0, 1.27778],
              8721: [0.55001, 1.05, 0, 0, 1.44445],
              8730: [0.65002, 1.15, 0, 0, 1],
              8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
              8748: [0.862, 1.36, 0.44445, 0, 0.55556],
              8749: [0.862, 1.36, 0.44445, 0, 0.55556],
              8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
              8896: [0.55001, 1.05, 0, 0, 1.11111],
              8897: [0.55001, 1.05, 0, 0, 1.11111],
              8898: [0.55001, 1.05, 0, 0, 1.11111],
              8899: [0.55001, 1.05, 0, 0, 1.11111],
              8968: [0.65002, 1.15, 0, 0, 0.52778],
              8969: [0.65002, 1.15, 0, 0, 0.52778],
              8970: [0.65002, 1.15, 0, 0, 0.52778],
              8971: [0.65002, 1.15, 0, 0, 0.52778],
              10216: [0.65002, 1.15, 0, 0, 0.61111],
              10217: [0.65002, 1.15, 0, 0, 0.61111],
              10752: [0.55001, 1.05, 0, 0, 1.51112],
              10753: [0.55001, 1.05, 0, 0, 1.51112],
              10754: [0.55001, 1.05, 0, 0, 1.51112],
              10756: [0.55001, 1.05, 0, 0, 1.11111],
              10758: [0.55001, 1.05, 0, 0, 1.11111]
            },
            "Size3-Regular": {
              32: [0, 0, 0, 0, 0.25],
              40: [0.95003, 1.45, 0, 0, 0.73611],
              41: [0.95003, 1.45, 0, 0, 0.73611],
              47: [0.95003, 1.45, 0, 0, 1.04445],
              91: [0.95003, 1.45, 0, 0, 0.52778],
              92: [0.95003, 1.45, 0, 0, 1.04445],
              93: [0.95003, 1.45, 0, 0, 0.52778],
              123: [0.95003, 1.45, 0, 0, 0.75],
              125: [0.95003, 1.45, 0, 0, 0.75],
              160: [0, 0, 0, 0, 0.25],
              710: [0, 0.75, 0, 0, 1.44445],
              732: [0, 0.75, 0, 0, 1.44445],
              770: [0, 0.75, 0, 0, 1.44445],
              771: [0, 0.75, 0, 0, 1.44445],
              8730: [0.95003, 1.45, 0, 0, 1],
              8968: [0.95003, 1.45, 0, 0, 0.58334],
              8969: [0.95003, 1.45, 0, 0, 0.58334],
              8970: [0.95003, 1.45, 0, 0, 0.58334],
              8971: [0.95003, 1.45, 0, 0, 0.58334],
              10216: [0.95003, 1.45, 0, 0, 0.75],
              10217: [0.95003, 1.45, 0, 0, 0.75]
            },
            "Size4-Regular": {
              32: [0, 0, 0, 0, 0.25],
              40: [1.25003, 1.75, 0, 0, 0.79167],
              41: [1.25003, 1.75, 0, 0, 0.79167],
              47: [1.25003, 1.75, 0, 0, 1.27778],
              91: [1.25003, 1.75, 0, 0, 0.58334],
              92: [1.25003, 1.75, 0, 0, 1.27778],
              93: [1.25003, 1.75, 0, 0, 0.58334],
              123: [1.25003, 1.75, 0, 0, 0.80556],
              125: [1.25003, 1.75, 0, 0, 0.80556],
              160: [0, 0, 0, 0, 0.25],
              710: [0, 0.825, 0, 0, 1.8889],
              732: [0, 0.825, 0, 0, 1.8889],
              770: [0, 0.825, 0, 0, 1.8889],
              771: [0, 0.825, 0, 0, 1.8889],
              8730: [1.25003, 1.75, 0, 0, 1],
              8968: [1.25003, 1.75, 0, 0, 0.63889],
              8969: [1.25003, 1.75, 0, 0, 0.63889],
              8970: [1.25003, 1.75, 0, 0, 0.63889],
              8971: [1.25003, 1.75, 0, 0, 0.63889],
              9115: [0.64502, 1.155, 0, 0, 0.875],
              9116: [1e-5, 0.6, 0, 0, 0.875],
              9117: [0.64502, 1.155, 0, 0, 0.875],
              9118: [0.64502, 1.155, 0, 0, 0.875],
              9119: [1e-5, 0.6, 0, 0, 0.875],
              9120: [0.64502, 1.155, 0, 0, 0.875],
              9121: [0.64502, 1.155, 0, 0, 0.66667],
              9122: [-99e-5, 0.601, 0, 0, 0.66667],
              9123: [0.64502, 1.155, 0, 0, 0.66667],
              9124: [0.64502, 1.155, 0, 0, 0.66667],
              9125: [-99e-5, 0.601, 0, 0, 0.66667],
              9126: [0.64502, 1.155, 0, 0, 0.66667],
              9127: [1e-5, 0.9, 0, 0, 0.88889],
              9128: [0.65002, 1.15, 0, 0, 0.88889],
              9129: [0.90001, 0, 0, 0, 0.88889],
              9130: [0, 0.3, 0, 0, 0.88889],
              9131: [1e-5, 0.9, 0, 0, 0.88889],
              9132: [0.65002, 1.15, 0, 0, 0.88889],
              9133: [0.90001, 0, 0, 0, 0.88889],
              9143: [0.88502, 0.915, 0, 0, 1.05556],
              10216: [1.25003, 1.75, 0, 0, 0.80556],
              10217: [1.25003, 1.75, 0, 0, 0.80556],
              57344: [-499e-5, 0.605, 0, 0, 1.05556],
              57345: [-499e-5, 0.605, 0, 0, 1.05556],
              57680: [0, 0.12, 0, 0, 0.45],
              57681: [0, 0.12, 0, 0, 0.45],
              57682: [0, 0.12, 0, 0, 0.45],
              57683: [0, 0.12, 0, 0, 0.45]
            },
            "Typewriter-Regular": {
              32: [0, 0, 0, 0, 0.525],
              33: [0, 0.61111, 0, 0, 0.525],
              34: [0, 0.61111, 0, 0, 0.525],
              35: [0, 0.61111, 0, 0, 0.525],
              36: [0.08333, 0.69444, 0, 0, 0.525],
              37: [0.08333, 0.69444, 0, 0, 0.525],
              38: [0, 0.61111, 0, 0, 0.525],
              39: [0, 0.61111, 0, 0, 0.525],
              40: [0.08333, 0.69444, 0, 0, 0.525],
              41: [0.08333, 0.69444, 0, 0, 0.525],
              42: [0, 0.52083, 0, 0, 0.525],
              43: [-0.08056, 0.53055, 0, 0, 0.525],
              44: [0.13889, 0.125, 0, 0, 0.525],
              45: [-0.08056, 0.53055, 0, 0, 0.525],
              46: [0, 0.125, 0, 0, 0.525],
              47: [0.08333, 0.69444, 0, 0, 0.525],
              48: [0, 0.61111, 0, 0, 0.525],
              49: [0, 0.61111, 0, 0, 0.525],
              50: [0, 0.61111, 0, 0, 0.525],
              51: [0, 0.61111, 0, 0, 0.525],
              52: [0, 0.61111, 0, 0, 0.525],
              53: [0, 0.61111, 0, 0, 0.525],
              54: [0, 0.61111, 0, 0, 0.525],
              55: [0, 0.61111, 0, 0, 0.525],
              56: [0, 0.61111, 0, 0, 0.525],
              57: [0, 0.61111, 0, 0, 0.525],
              58: [0, 0.43056, 0, 0, 0.525],
              59: [0.13889, 0.43056, 0, 0, 0.525],
              60: [-0.05556, 0.55556, 0, 0, 0.525],
              61: [-0.19549, 0.41562, 0, 0, 0.525],
              62: [-0.05556, 0.55556, 0, 0, 0.525],
              63: [0, 0.61111, 0, 0, 0.525],
              64: [0, 0.61111, 0, 0, 0.525],
              65: [0, 0.61111, 0, 0, 0.525],
              66: [0, 0.61111, 0, 0, 0.525],
              67: [0, 0.61111, 0, 0, 0.525],
              68: [0, 0.61111, 0, 0, 0.525],
              69: [0, 0.61111, 0, 0, 0.525],
              70: [0, 0.61111, 0, 0, 0.525],
              71: [0, 0.61111, 0, 0, 0.525],
              72: [0, 0.61111, 0, 0, 0.525],
              73: [0, 0.61111, 0, 0, 0.525],
              74: [0, 0.61111, 0, 0, 0.525],
              75: [0, 0.61111, 0, 0, 0.525],
              76: [0, 0.61111, 0, 0, 0.525],
              77: [0, 0.61111, 0, 0, 0.525],
              78: [0, 0.61111, 0, 0, 0.525],
              79: [0, 0.61111, 0, 0, 0.525],
              80: [0, 0.61111, 0, 0, 0.525],
              81: [0.13889, 0.61111, 0, 0, 0.525],
              82: [0, 0.61111, 0, 0, 0.525],
              83: [0, 0.61111, 0, 0, 0.525],
              84: [0, 0.61111, 0, 0, 0.525],
              85: [0, 0.61111, 0, 0, 0.525],
              86: [0, 0.61111, 0, 0, 0.525],
              87: [0, 0.61111, 0, 0, 0.525],
              88: [0, 0.61111, 0, 0, 0.525],
              89: [0, 0.61111, 0, 0, 0.525],
              90: [0, 0.61111, 0, 0, 0.525],
              91: [0.08333, 0.69444, 0, 0, 0.525],
              92: [0.08333, 0.69444, 0, 0, 0.525],
              93: [0.08333, 0.69444, 0, 0, 0.525],
              94: [0, 0.61111, 0, 0, 0.525],
              95: [0.09514, 0, 0, 0, 0.525],
              96: [0, 0.61111, 0, 0, 0.525],
              97: [0, 0.43056, 0, 0, 0.525],
              98: [0, 0.61111, 0, 0, 0.525],
              99: [0, 0.43056, 0, 0, 0.525],
              100: [0, 0.61111, 0, 0, 0.525],
              101: [0, 0.43056, 0, 0, 0.525],
              102: [0, 0.61111, 0, 0, 0.525],
              103: [0.22222, 0.43056, 0, 0, 0.525],
              104: [0, 0.61111, 0, 0, 0.525],
              105: [0, 0.61111, 0, 0, 0.525],
              106: [0.22222, 0.61111, 0, 0, 0.525],
              107: [0, 0.61111, 0, 0, 0.525],
              108: [0, 0.61111, 0, 0, 0.525],
              109: [0, 0.43056, 0, 0, 0.525],
              110: [0, 0.43056, 0, 0, 0.525],
              111: [0, 0.43056, 0, 0, 0.525],
              112: [0.22222, 0.43056, 0, 0, 0.525],
              113: [0.22222, 0.43056, 0, 0, 0.525],
              114: [0, 0.43056, 0, 0, 0.525],
              115: [0, 0.43056, 0, 0, 0.525],
              116: [0, 0.55358, 0, 0, 0.525],
              117: [0, 0.43056, 0, 0, 0.525],
              118: [0, 0.43056, 0, 0, 0.525],
              119: [0, 0.43056, 0, 0, 0.525],
              120: [0, 0.43056, 0, 0, 0.525],
              121: [0.22222, 0.43056, 0, 0, 0.525],
              122: [0, 0.43056, 0, 0, 0.525],
              123: [0.08333, 0.69444, 0, 0, 0.525],
              124: [0.08333, 0.69444, 0, 0, 0.525],
              125: [0.08333, 0.69444, 0, 0, 0.525],
              126: [0, 0.61111, 0, 0, 0.525],
              127: [0, 0.61111, 0, 0, 0.525],
              160: [0, 0, 0, 0, 0.525],
              176: [0, 0.61111, 0, 0, 0.525],
              184: [0.19445, 0, 0, 0, 0.525],
              305: [0, 0.43056, 0, 0, 0.525],
              567: [0.22222, 0.43056, 0, 0, 0.525],
              711: [0, 0.56597, 0, 0, 0.525],
              713: [0, 0.56555, 0, 0, 0.525],
              714: [0, 0.61111, 0, 0, 0.525],
              715: [0, 0.61111, 0, 0, 0.525],
              728: [0, 0.61111, 0, 0, 0.525],
              730: [0, 0.61111, 0, 0, 0.525],
              770: [0, 0.61111, 0, 0, 0.525],
              771: [0, 0.61111, 0, 0, 0.525],
              776: [0, 0.61111, 0, 0, 0.525],
              915: [0, 0.61111, 0, 0, 0.525],
              916: [0, 0.61111, 0, 0, 0.525],
              920: [0, 0.61111, 0, 0, 0.525],
              923: [0, 0.61111, 0, 0, 0.525],
              926: [0, 0.61111, 0, 0, 0.525],
              928: [0, 0.61111, 0, 0, 0.525],
              931: [0, 0.61111, 0, 0, 0.525],
              933: [0, 0.61111, 0, 0, 0.525],
              934: [0, 0.61111, 0, 0, 0.525],
              936: [0, 0.61111, 0, 0, 0.525],
              937: [0, 0.61111, 0, 0, 0.525],
              8216: [0, 0.61111, 0, 0, 0.525],
              8217: [0, 0.61111, 0, 0, 0.525],
              8242: [0, 0.61111, 0, 0, 0.525],
              9251: [0.11111, 0.21944, 0, 0, 0.525]
            }
          }, s0 = {
            slant: [0.25, 0.25, 0.25],
            // sigma1
            space: [0, 0, 0],
            // sigma2
            stretch: [0, 0, 0],
            // sigma3
            shrink: [0, 0, 0],
            // sigma4
            xHeight: [0.431, 0.431, 0.431],
            // sigma5
            quad: [1, 1.171, 1.472],
            // sigma6
            extraSpace: [0, 0, 0],
            // sigma7
            num1: [0.677, 0.732, 0.925],
            // sigma8
            num2: [0.394, 0.384, 0.387],
            // sigma9
            num3: [0.444, 0.471, 0.504],
            // sigma10
            denom1: [0.686, 0.752, 1.025],
            // sigma11
            denom2: [0.345, 0.344, 0.532],
            // sigma12
            sup1: [0.413, 0.503, 0.504],
            // sigma13
            sup2: [0.363, 0.431, 0.404],
            // sigma14
            sup3: [0.289, 0.286, 0.294],
            // sigma15
            sub1: [0.15, 0.143, 0.2],
            // sigma16
            sub2: [0.247, 0.286, 0.4],
            // sigma17
            supDrop: [0.386, 0.353, 0.494],
            // sigma18
            subDrop: [0.05, 0.071, 0.1],
            // sigma19
            delim1: [2.39, 1.7, 1.98],
            // sigma20
            delim2: [1.01, 1.157, 1.42],
            // sigma21
            axisHeight: [0.25, 0.25, 0.25],
            // sigma22
            // These font metrics are extracted from TeX by using tftopl on cmex10.tfm;
            // they correspond to the font parameters of the extension fonts (family 3).
            // See the TeXbook, page 441. In AMSTeX, the extension fonts scale; to
            // match cmex7, we'd use cmex7.tfm values for script and scriptscript
            // values.
            defaultRuleThickness: [0.04, 0.049, 0.049],
            // xi8; cmex7: 0.049
            bigOpSpacing1: [0.111, 0.111, 0.111],
            // xi9
            bigOpSpacing2: [0.166, 0.166, 0.166],
            // xi10
            bigOpSpacing3: [0.2, 0.2, 0.2],
            // xi11
            bigOpSpacing4: [0.6, 0.611, 0.611],
            // xi12; cmex7: 0.611
            bigOpSpacing5: [0.1, 0.143, 0.143],
            // xi13; cmex7: 0.143
            // The \sqrt rule width is taken from the height of the surd character.
            // Since we use the same font at all sizes, this thickness doesn't scale.
            sqrtRuleThickness: [0.04, 0.04, 0.04],
            // This value determines how large a pt is, for metrics which are defined
            // in terms of pts.
            // This value is also used in katex.less; if you change it make sure the
            // values match.
            ptPerEm: [10, 10, 10],
            // The space between adjacent `|` columns in an array definition. From
            // `\showthe\doublerulesep` in LaTeX. Equals 2.0 / ptPerEm.
            doubleRuleSep: [0.2, 0.2, 0.2],
            // The width of separator lines in {array} environments. From
            // `\showthe\arrayrulewidth` in LaTeX. Equals 0.4 / ptPerEm.
            arrayRuleWidth: [0.04, 0.04, 0.04],
            // Two values from LaTeX source2e:
            fboxsep: [0.3, 0.3, 0.3],
            //        3 pt / ptPerEm
            fboxrule: [0.04, 0.04, 0.04]
            // 0.4 pt / ptPerEm
          }, o0 = {
            // Latin-1
            Å: "A",
            Ð: "D",
            Þ: "o",
            å: "a",
            ð: "d",
            þ: "o",
            // Cyrillic
            А: "A",
            Б: "B",
            В: "B",
            Г: "F",
            Д: "A",
            Е: "E",
            Ж: "K",
            З: "3",
            И: "N",
            Й: "N",
            К: "K",
            Л: "N",
            М: "M",
            Н: "H",
            О: "O",
            П: "N",
            Р: "P",
            С: "C",
            Т: "T",
            У: "y",
            Ф: "O",
            Х: "X",
            Ц: "U",
            Ч: "h",
            Ш: "W",
            Щ: "W",
            Ъ: "B",
            Ы: "X",
            Ь: "B",
            Э: "3",
            Ю: "X",
            Я: "R",
            а: "a",
            б: "b",
            в: "a",
            г: "r",
            д: "y",
            е: "e",
            ж: "m",
            з: "e",
            и: "n",
            й: "n",
            к: "n",
            л: "n",
            м: "m",
            н: "n",
            о: "o",
            п: "n",
            р: "p",
            с: "c",
            т: "o",
            у: "y",
            ф: "b",
            х: "x",
            ц: "n",
            ч: "n",
            ш: "w",
            щ: "w",
            ъ: "a",
            ы: "m",
            ь: "a",
            э: "e",
            ю: "m",
            я: "r"
          };
          function u0(h, e) {
            xt[h] = e;
          }
          function qt(h, e, t) {
            if (!xt[e])
              throw new Error("Font metrics not found for font: " + e + ".");
            var r = h.charCodeAt(0), n = xt[e][r];
            if (!n && h[0] in o0 && (r = o0[h[0]].charCodeAt(0), n = xt[e][r]), !n && t === "text" && wt(r) && (n = xt[e][77]), n)
              return {
                depth: n[0],
                height: n[1],
                italic: n[2],
                skew: n[3],
                width: n[4]
              };
          }
          var V0 = {};
          function Mr(h) {
            var e;
            if (h >= 5 ? e = 0 : h >= 3 ? e = 1 : e = 2, !V0[e]) {
              var t = V0[e] = {
                cssEmPerMu: s0.quad[e] / 18
              };
              for (var r in s0)
                s0.hasOwnProperty(r) && (t[r] = s0[r][e]);
            }
            return V0[e];
          }
          var zr = [
            // Each element contains [textsize, scriptsize, scriptscriptsize].
            // The size mappings are taken from TeX with \normalsize=10pt.
            [1, 1, 1],
            // size1: [5, 5, 5]              \tiny
            [2, 1, 1],
            // size2: [6, 5, 5]
            [3, 1, 1],
            // size3: [7, 5, 5]              \scriptsize
            [4, 2, 1],
            // size4: [8, 6, 5]              \footnotesize
            [5, 2, 1],
            // size5: [9, 6, 5]              \small
            [6, 3, 1],
            // size6: [10, 7, 5]             \normalsize
            [7, 4, 2],
            // size7: [12, 8, 6]             \large
            [8, 6, 3],
            // size8: [14.4, 10, 7]          \Large
            [9, 7, 6],
            // size9: [17.28, 12, 10]        \LARGE
            [10, 8, 7],
            // size10: [20.74, 14.4, 12]     \huge
            [11, 10, 9]
            // size11: [24.88, 20.74, 17.28] \HUGE
          ], W0 = [
            // fontMetrics.js:getGlobalMetrics also uses size indexes, so if
            // you change size indexes, change that function.
            0.5,
            0.6,
            0.7,
            0.8,
            0.9,
            1,
            1.2,
            1.44,
            1.728,
            2.074,
            2.488
          ], ur = function(e, t) {
            return t.size < 2 ? e : zr[e - 1][t.size - 1];
          }, N0 = /* @__PURE__ */ function() {
            function h(t) {
              this.style = void 0, this.color = void 0, this.size = void 0, this.textSize = void 0, this.phantom = void 0, this.font = void 0, this.fontFamily = void 0, this.fontWeight = void 0, this.fontShape = void 0, this.sizeMultiplier = void 0, this.maxSize = void 0, this.minRuleThickness = void 0, this._fontMetrics = void 0, this.style = t.style, this.color = t.color, this.size = t.size || h.BASESIZE, this.textSize = t.textSize || this.size, this.phantom = !!t.phantom, this.font = t.font || "", this.fontFamily = t.fontFamily || "", this.fontWeight = t.fontWeight || "", this.fontShape = t.fontShape || "", this.sizeMultiplier = W0[this.size - 1], this.maxSize = t.maxSize, this.minRuleThickness = t.minRuleThickness, this._fontMetrics = void 0;
            }
            var e = h.prototype;
            return e.extend = function(r) {
              var n = {
                style: this.style,
                size: this.size,
                textSize: this.textSize,
                color: this.color,
                phantom: this.phantom,
                font: this.font,
                fontFamily: this.fontFamily,
                fontWeight: this.fontWeight,
                fontShape: this.fontShape,
                maxSize: this.maxSize,
                minRuleThickness: this.minRuleThickness
              };
              for (var s in r)
                r.hasOwnProperty(s) && (n[s] = r[s]);
              return new h(n);
            }, e.havingStyle = function(r) {
              return this.style === r ? this : this.extend({
                style: r,
                size: ur(this.textSize, r)
              });
            }, e.havingCrampedStyle = function() {
              return this.havingStyle(this.style.cramp());
            }, e.havingSize = function(r) {
              return this.size === r && this.textSize === r ? this : this.extend({
                style: this.style.text(),
                size: r,
                textSize: r,
                sizeMultiplier: W0[r - 1]
              });
            }, e.havingBaseStyle = function(r) {
              r = r || this.style.text();
              var n = ur(h.BASESIZE, r);
              return this.size === n && this.textSize === h.BASESIZE && this.style === r ? this : this.extend({
                style: r,
                size: n
              });
            }, e.havingBaseSizing = function() {
              var r;
              switch (this.style.id) {
                case 4:
                case 5:
                  r = 3;
                  break;
                case 6:
                case 7:
                  r = 1;
                  break;
                default:
                  r = 6;
              }
              return this.extend({
                style: this.style.text(),
                size: r
              });
            }, e.withColor = function(r) {
              return this.extend({
                color: r
              });
            }, e.withPhantom = function() {
              return this.extend({
                phantom: !0
              });
            }, e.withFont = function(r) {
              return this.extend({
                font: r
              });
            }, e.withTextFontFamily = function(r) {
              return this.extend({
                fontFamily: r,
                font: ""
              });
            }, e.withTextFontWeight = function(r) {
              return this.extend({
                fontWeight: r,
                font: ""
              });
            }, e.withTextFontShape = function(r) {
              return this.extend({
                fontShape: r,
                font: ""
              });
            }, e.sizingClasses = function(r) {
              return r.size !== this.size ? ["sizing", "reset-size" + r.size, "size" + this.size] : [];
            }, e.baseSizingClasses = function() {
              return this.size !== h.BASESIZE ? ["sizing", "reset-size" + this.size, "size" + h.BASESIZE] : [];
            }, e.fontMetrics = function() {
              return this._fontMetrics || (this._fontMetrics = Mr(this.size)), this._fontMetrics;
            }, e.getColor = function() {
              return this.phantom ? "transparent" : this.color;
            }, h;
          }();
          N0.BASESIZE = 6;
          var Y0 = N0, mt = {
            // https://en.wikibooks.org/wiki/LaTeX/Lengths and
            // https://tex.stackexchange.com/a/8263
            pt: 1,
            // TeX point
            mm: 7227 / 2540,
            // millimeter
            cm: 7227 / 254,
            // centimeter
            in: 72.27,
            // inch
            bp: 803 / 800,
            // big (PostScript) points
            pc: 12,
            // pica
            dd: 1238 / 1157,
            // didot
            cc: 14856 / 1157,
            // cicero (12 didot)
            nd: 685 / 642,
            // new didot
            nc: 1370 / 107,
            // new cicero (12 new didot)
            sp: 1 / 65536,
            // scaled point (TeX's internal smallest unit)
            // https://tex.stackexchange.com/a/41371
            px: 803 / 800
            // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
          }, c0 = {
            ex: !0,
            em: !0,
            mu: !0
          }, X0 = function(e) {
            return typeof e != "string" && (e = e.unit), e in mt || e in c0 || e === "ex";
          }, Ie = function(e, t) {
            var r;
            if (e.unit in mt)
              r = mt[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
            else if (e.unit === "mu")
              r = t.fontMetrics().cssEmPerMu;
            else {
              var n;
              if (t.style.isTight() ? n = t.havingStyle(t.style.text()) : n = t, e.unit === "ex")
                r = n.fontMetrics().xHeight;
              else if (e.unit === "em")
                r = n.fontMetrics().quad;
              else
                throw new c("Invalid unit: '" + e.unit + "'");
              n !== t && (r *= n.sizeMultiplier / t.sizeMultiplier);
            }
            return Math.min(e.number * r, t.maxSize);
          }, J = function(e) {
            return +e.toFixed(4) + "em";
          }, nt = function(e) {
            return e.filter(function(t) {
              return t;
            }).join(" ");
          }, Nr = function(e, t, r) {
            if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = r || {}, t) {
              t.style.isTight() && this.classes.push("mtight");
              var n = t.getColor();
              n && (this.style.color = n);
            }
          }, Rr = function(e) {
            var t = document.createElement(e);
            t.className = nt(this.classes);
            for (var r in this.style)
              this.style.hasOwnProperty(r) && (t.style[r] = this.style[r]);
            for (var n in this.attributes)
              this.attributes.hasOwnProperty(n) && t.setAttribute(n, this.attributes[n]);
            for (var s = 0; s < this.children.length; s++)
              t.appendChild(this.children[s].toNode());
            return t;
          }, je = function(e) {
            var t = "<" + e;
            this.classes.length && (t += ' class="' + L.escape(nt(this.classes)) + '"');
            var r = "";
            for (var n in this.style)
              this.style.hasOwnProperty(n) && (r += L.hyphenate(n) + ":" + this.style[n] + ";");
            r && (t += ' style="' + L.escape(r) + '"');
            for (var s in this.attributes)
              this.attributes.hasOwnProperty(s) && (t += " " + s + '="' + L.escape(this.attributes[s]) + '"');
            t += ">";
            for (var f = 0; f < this.children.length; f++)
              t += this.children[f].toMarkup();
            return t += "</" + e + ">", t;
          }, Dt = /* @__PURE__ */ function() {
            function h(t, r, n, s) {
              this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, Nr.call(this, t, n, s), this.children = r || [];
            }
            var e = h.prototype;
            return e.setAttribute = function(r, n) {
              this.attributes[r] = n;
            }, e.hasClass = function(r) {
              return L.contains(this.classes, r);
            }, e.toNode = function() {
              return Rr.call(this, "span");
            }, e.toMarkup = function() {
              return je.call(this, "span");
            }, h;
          }(), cr = /* @__PURE__ */ function() {
            function h(t, r, n, s) {
              this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, Nr.call(this, r, s), this.children = n || [], this.setAttribute("href", t);
            }
            var e = h.prototype;
            return e.setAttribute = function(r, n) {
              this.attributes[r] = n;
            }, e.hasClass = function(r) {
              return L.contains(this.classes, r);
            }, e.toNode = function() {
              return Rr.call(this, "a");
            }, e.toMarkup = function() {
              return je.call(this, "a");
            }, h;
          }(), Ir = /* @__PURE__ */ function() {
            function h(t, r, n) {
              this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = r, this.src = t, this.classes = ["mord"], this.style = n;
            }
            var e = h.prototype;
            return e.hasClass = function(r) {
              return L.contains(this.classes, r);
            }, e.toNode = function() {
              var r = document.createElement("img");
              r.src = this.src, r.alt = this.alt, r.className = "mord";
              for (var n in this.style)
                this.style.hasOwnProperty(n) && (r.style[n] = this.style[n]);
              return r;
            }, e.toMarkup = function() {
              var r = "<img  src='" + this.src + " 'alt='" + this.alt + "' ", n = "";
              for (var s in this.style)
                this.style.hasOwnProperty(s) && (n += L.hyphenate(s) + ":" + this.style[s] + ";");
              return n && (r += ' style="' + L.escape(n) + '"'), r += "'/>", r;
            }, h;
          }(), hr = {
            î: "ı̂",
            ï: "ı̈",
            í: "ı́",
            // 'ī': '\u0131\u0304', // enable when we add Extended Latin
            ì: "ı̀"
          }, it = /* @__PURE__ */ function() {
            function h(t, r, n, s, f, g, w, x) {
              this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = t, this.height = r || 0, this.depth = n || 0, this.italic = s || 0, this.skew = f || 0, this.width = g || 0, this.classes = w || [], this.style = x || {}, this.maxFontSize = 0;
              var E = re(this.text.charCodeAt(0));
              E && this.classes.push(E + "_fallback"), /[îïíì]/.test(this.text) && (this.text = hr[this.text]);
            }
            var e = h.prototype;
            return e.hasClass = function(r) {
              return L.contains(this.classes, r);
            }, e.toNode = function() {
              var r = document.createTextNode(this.text), n = null;
              this.italic > 0 && (n = document.createElement("span"), n.style.marginRight = J(this.italic)), this.classes.length > 0 && (n = n || document.createElement("span"), n.className = nt(this.classes));
              for (var s in this.style)
                this.style.hasOwnProperty(s) && (n = n || document.createElement("span"), n.style[s] = this.style[s]);
              return n ? (n.appendChild(r), n) : r;
            }, e.toMarkup = function() {
              var r = !1, n = "<span";
              this.classes.length && (r = !0, n += ' class="', n += L.escape(nt(this.classes)), n += '"');
              var s = "";
              this.italic > 0 && (s += "margin-right:" + this.italic + "em;");
              for (var f in this.style)
                this.style.hasOwnProperty(f) && (s += L.hyphenate(f) + ":" + this.style[f] + ";");
              s && (r = !0, n += ' style="' + L.escape(s) + '"');
              var g = L.escape(this.text);
              return r ? (n += ">", n += g, n += "</span>", n) : g;
            }, h;
          }(), At = /* @__PURE__ */ function() {
            function h(t, r) {
              this.children = void 0, this.attributes = void 0, this.children = t || [], this.attributes = r || {};
            }
            var e = h.prototype;
            return e.toNode = function() {
              var r = "http://www.w3.org/2000/svg", n = document.createElementNS(r, "svg");
              for (var s in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, s) && n.setAttribute(s, this.attributes[s]);
              for (var f = 0; f < this.children.length; f++)
                n.appendChild(this.children[f].toNode());
              return n;
            }, e.toMarkup = function() {
              var r = '<svg xmlns="http://www.w3.org/2000/svg"';
              for (var n in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, n) && (r += " " + n + "='" + this.attributes[n] + "'");
              r += ">";
              for (var s = 0; s < this.children.length; s++)
                r += this.children[s].toMarkup();
              return r += "</svg>", r;
            }, h;
          }(), Pt = /* @__PURE__ */ function() {
            function h(t, r) {
              this.pathName = void 0, this.alternate = void 0, this.pathName = t, this.alternate = r;
            }
            var e = h.prototype;
            return e.toNode = function() {
              var r = "http://www.w3.org/2000/svg", n = document.createElementNS(r, "path");
              return this.alternate ? n.setAttribute("d", this.alternate) : n.setAttribute("d", z0[this.pathName]), n;
            }, e.toMarkup = function() {
              return this.alternate ? "<path d='" + this.alternate + "'/>" : "<path d='" + z0[this.pathName] + "'/>";
            }, h;
          }(), h0 = /* @__PURE__ */ function() {
            function h(t) {
              this.attributes = void 0, this.attributes = t || {};
            }
            var e = h.prototype;
            return e.toNode = function() {
              var r = "http://www.w3.org/2000/svg", n = document.createElementNS(r, "line");
              for (var s in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, s) && n.setAttribute(s, this.attributes[s]);
              return n;
            }, e.toMarkup = function() {
              var r = "<line";
              for (var n in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, n) && (r += " " + n + "='" + this.attributes[n] + "'");
              return r += "/>", r;
            }, h;
          }();
          function j0(h) {
            if (h instanceof it)
              return h;
            throw new Error("Expected symbolNode but got " + String(h) + ".");
          }
          function Cn(h) {
            if (h instanceof Dt)
              return h;
            throw new Error("Expected span<HtmlDomNode> but got " + String(h) + ".");
          }
          var Jt = {
            bin: 1,
            close: 1,
            inner: 1,
            open: 1,
            punct: 1,
            rel: 1
          }, fr = {
            "accent-token": 1,
            mathord: 1,
            "op-token": 1,
            spacing: 1,
            textord: 1
          }, R0 = {
            math: {},
            text: {}
          }, qe = R0;
          function o(h, e, t, r, n, s) {
            R0[h][n] = {
              font: e,
              group: t,
              replace: r
            }, s && r && (R0[h][r] = R0[h][n]);
          }
          var d = "math", G = "text", b = "main", _ = "ams", Le = "accent-token", le = "bin", tt = "close", fe = "inner", F = "mathord", V = "op-token", te = "open", Be = "punct", A = "rel", Pe = "spacing", T = "textord";
          o(d, b, A, "≡", "\\equiv", !0), o(d, b, A, "≺", "\\prec", !0), o(d, b, A, "≻", "\\succ", !0), o(d, b, A, "∼", "\\sim", !0), o(d, b, A, "⊥", "\\perp"), o(d, b, A, "⪯", "\\preceq", !0), o(d, b, A, "⪰", "\\succeq", !0), o(d, b, A, "≃", "\\simeq", !0), o(d, b, A, "∣", "\\mid", !0), o(d, b, A, "≪", "\\ll", !0), o(d, b, A, "≫", "\\gg", !0), o(d, b, A, "≍", "\\asymp", !0), o(d, b, A, "∥", "\\parallel"), o(d, b, A, "⋈", "\\bowtie", !0), o(d, b, A, "⌣", "\\smile", !0), o(d, b, A, "⊑", "\\sqsubseteq", !0), o(d, b, A, "⊒", "\\sqsupseteq", !0), o(d, b, A, "≐", "\\doteq", !0), o(d, b, A, "⌢", "\\frown", !0), o(d, b, A, "∋", "\\ni", !0), o(d, b, A, "∝", "\\propto", !0), o(d, b, A, "⊢", "\\vdash", !0), o(d, b, A, "⊣", "\\dashv", !0), o(d, b, A, "∋", "\\owns"), o(d, b, Be, ".", "\\ldotp"), o(d, b, Be, "⋅", "\\cdotp"), o(d, b, T, "#", "\\#"), o(G, b, T, "#", "\\#"), o(d, b, T, "&", "\\&"), o(G, b, T, "&", "\\&"), o(d, b, T, "ℵ", "\\aleph", !0), o(d, b, T, "∀", "\\forall", !0), o(d, b, T, "ℏ", "\\hbar", !0), o(d, b, T, "∃", "\\exists", !0), o(d, b, T, "∇", "\\nabla", !0), o(d, b, T, "♭", "\\flat", !0), o(d, b, T, "ℓ", "\\ell", !0), o(d, b, T, "♮", "\\natural", !0), o(d, b, T, "♣", "\\clubsuit", !0), o(d, b, T, "℘", "\\wp", !0), o(d, b, T, "♯", "\\sharp", !0), o(d, b, T, "♢", "\\diamondsuit", !0), o(d, b, T, "ℜ", "\\Re", !0), o(d, b, T, "♡", "\\heartsuit", !0), o(d, b, T, "ℑ", "\\Im", !0), o(d, b, T, "♠", "\\spadesuit", !0), o(d, b, T, "§", "\\S", !0), o(G, b, T, "§", "\\S"), o(d, b, T, "¶", "\\P", !0), o(G, b, T, "¶", "\\P"), o(d, b, T, "†", "\\dag"), o(G, b, T, "†", "\\dag"), o(G, b, T, "†", "\\textdagger"), o(d, b, T, "‡", "\\ddag"), o(G, b, T, "‡", "\\ddag"), o(G, b, T, "‡", "\\textdaggerdbl"), o(d, b, tt, "⎱", "\\rmoustache", !0), o(d, b, te, "⎰", "\\lmoustache", !0), o(d, b, tt, "⟯", "\\rgroup", !0), o(d, b, te, "⟮", "\\lgroup", !0), o(d, b, le, "∓", "\\mp", !0), o(d, b, le, "⊖", "\\ominus", !0), o(d, b, le, "⊎", "\\uplus", !0), o(d, b, le, "⊓", "\\sqcap", !0), o(d, b, le, "∗", "\\ast"), o(d, b, le, "⊔", "\\sqcup", !0), o(d, b, le, "◯", "\\bigcirc", !0), o(d, b, le, "∙", "\\bullet", !0), o(d, b, le, "‡", "\\ddagger"), o(d, b, le, "≀", "\\wr", !0), o(d, b, le, "⨿", "\\amalg"), o(d, b, le, "&", "\\And"), o(d, b, A, "⟵", "\\longleftarrow", !0), o(d, b, A, "⇐", "\\Leftarrow", !0), o(d, b, A, "⟸", "\\Longleftarrow", !0), o(d, b, A, "⟶", "\\longrightarrow", !0), o(d, b, A, "⇒", "\\Rightarrow", !0), o(d, b, A, "⟹", "\\Longrightarrow", !0), o(d, b, A, "↔", "\\leftrightarrow", !0), o(d, b, A, "⟷", "\\longleftrightarrow", !0), o(d, b, A, "⇔", "\\Leftrightarrow", !0), o(d, b, A, "⟺", "\\Longleftrightarrow", !0), o(d, b, A, "↦", "\\mapsto", !0), o(d, b, A, "⟼", "\\longmapsto", !0), o(d, b, A, "↗", "\\nearrow", !0), o(d, b, A, "↩", "\\hookleftarrow", !0), o(d, b, A, "↪", "\\hookrightarrow", !0), o(d, b, A, "↘", "\\searrow", !0), o(d, b, A, "↼", "\\leftharpoonup", !0), o(d, b, A, "⇀", "\\rightharpoonup", !0), o(d, b, A, "↙", "\\swarrow", !0), o(d, b, A, "↽", "\\leftharpoondown", !0), o(d, b, A, "⇁", "\\rightharpoondown", !0), o(d, b, A, "↖", "\\nwarrow", !0), o(d, b, A, "⇌", "\\rightleftharpoons", !0), o(d, _, A, "≮", "\\nless", !0), o(d, _, A, "", "\\@nleqslant"), o(d, _, A, "", "\\@nleqq"), o(d, _, A, "⪇", "\\lneq", !0), o(d, _, A, "≨", "\\lneqq", !0), o(d, _, A, "", "\\@lvertneqq"), o(d, _, A, "⋦", "\\lnsim", !0), o(d, _, A, "⪉", "\\lnapprox", !0), o(d, _, A, "⊀", "\\nprec", !0), o(d, _, A, "⋠", "\\npreceq", !0), o(d, _, A, "⋨", "\\precnsim", !0), o(d, _, A, "⪹", "\\precnapprox", !0), o(d, _, A, "≁", "\\nsim", !0), o(d, _, A, "", "\\@nshortmid"), o(d, _, A, "∤", "\\nmid", !0), o(d, _, A, "⊬", "\\nvdash", !0), o(d, _, A, "⊭", "\\nvDash", !0), o(d, _, A, "⋪", "\\ntriangleleft"), o(d, _, A, "⋬", "\\ntrianglelefteq", !0), o(d, _, A, "⊊", "\\subsetneq", !0), o(d, _, A, "", "\\@varsubsetneq"), o(d, _, A, "⫋", "\\subsetneqq", !0), o(d, _, A, "", "\\@varsubsetneqq"), o(d, _, A, "≯", "\\ngtr", !0), o(d, _, A, "", "\\@ngeqslant"), o(d, _, A, "", "\\@ngeqq"), o(d, _, A, "⪈", "\\gneq", !0), o(d, _, A, "≩", "\\gneqq", !0), o(d, _, A, "", "\\@gvertneqq"), o(d, _, A, "⋧", "\\gnsim", !0), o(d, _, A, "⪊", "\\gnapprox", !0), o(d, _, A, "⊁", "\\nsucc", !0), o(d, _, A, "⋡", "\\nsucceq", !0), o(d, _, A, "⋩", "\\succnsim", !0), o(d, _, A, "⪺", "\\succnapprox", !0), o(d, _, A, "≆", "\\ncong", !0), o(d, _, A, "", "\\@nshortparallel"), o(d, _, A, "∦", "\\nparallel", !0), o(d, _, A, "⊯", "\\nVDash", !0), o(d, _, A, "⋫", "\\ntriangleright"), o(d, _, A, "⋭", "\\ntrianglerighteq", !0), o(d, _, A, "", "\\@nsupseteqq"), o(d, _, A, "⊋", "\\supsetneq", !0), o(d, _, A, "", "\\@varsupsetneq"), o(d, _, A, "⫌", "\\supsetneqq", !0), o(d, _, A, "", "\\@varsupsetneqq"), o(d, _, A, "⊮", "\\nVdash", !0), o(d, _, A, "⪵", "\\precneqq", !0), o(d, _, A, "⪶", "\\succneqq", !0), o(d, _, A, "", "\\@nsubseteqq"), o(d, _, le, "⊴", "\\unlhd"), o(d, _, le, "⊵", "\\unrhd"), o(d, _, A, "↚", "\\nleftarrow", !0), o(d, _, A, "↛", "\\nrightarrow", !0), o(d, _, A, "⇍", "\\nLeftarrow", !0), o(d, _, A, "⇏", "\\nRightarrow", !0), o(d, _, A, "↮", "\\nleftrightarrow", !0), o(d, _, A, "⇎", "\\nLeftrightarrow", !0), o(d, _, A, "△", "\\vartriangle"), o(d, _, T, "ℏ", "\\hslash"), o(d, _, T, "▽", "\\triangledown"), o(d, _, T, "◊", "\\lozenge"), o(d, _, T, "Ⓢ", "\\circledS"), o(d, _, T, "®", "\\circledR"), o(G, _, T, "®", "\\circledR"), o(d, _, T, "∡", "\\measuredangle", !0), o(d, _, T, "∄", "\\nexists"), o(d, _, T, "℧", "\\mho"), o(d, _, T, "Ⅎ", "\\Finv", !0), o(d, _, T, "⅁", "\\Game", !0), o(d, _, T, "‵", "\\backprime"), o(d, _, T, "▲", "\\blacktriangle"), o(d, _, T, "▼", "\\blacktriangledown"), o(d, _, T, "■", "\\blacksquare"), o(d, _, T, "⧫", "\\blacklozenge"), o(d, _, T, "★", "\\bigstar"), o(d, _, T, "∢", "\\sphericalangle", !0), o(d, _, T, "∁", "\\complement", !0), o(d, _, T, "ð", "\\eth", !0), o(G, b, T, "ð", "ð"), o(d, _, T, "╱", "\\diagup"), o(d, _, T, "╲", "\\diagdown"), o(d, _, T, "□", "\\square"), o(d, _, T, "□", "\\Box"), o(d, _, T, "◊", "\\Diamond"), o(d, _, T, "¥", "\\yen", !0), o(G, _, T, "¥", "\\yen", !0), o(d, _, T, "✓", "\\checkmark", !0), o(G, _, T, "✓", "\\checkmark"), o(d, _, T, "ℶ", "\\beth", !0), o(d, _, T, "ℸ", "\\daleth", !0), o(d, _, T, "ℷ", "\\gimel", !0), o(d, _, T, "ϝ", "\\digamma", !0), o(d, _, T, "ϰ", "\\varkappa"), o(d, _, te, "┌", "\\@ulcorner", !0), o(d, _, tt, "┐", "\\@urcorner", !0), o(d, _, te, "└", "\\@llcorner", !0), o(d, _, tt, "┘", "\\@lrcorner", !0), o(d, _, A, "≦", "\\leqq", !0), o(d, _, A, "⩽", "\\leqslant", !0), o(d, _, A, "⪕", "\\eqslantless", !0), o(d, _, A, "≲", "\\lesssim", !0), o(d, _, A, "⪅", "\\lessapprox", !0), o(d, _, A, "≊", "\\approxeq", !0), o(d, _, le, "⋖", "\\lessdot"), o(d, _, A, "⋘", "\\lll", !0), o(d, _, A, "≶", "\\lessgtr", !0), o(d, _, A, "⋚", "\\lesseqgtr", !0), o(d, _, A, "⪋", "\\lesseqqgtr", !0), o(d, _, A, "≑", "\\doteqdot"), o(d, _, A, "≓", "\\risingdotseq", !0), o(d, _, A, "≒", "\\fallingdotseq", !0), o(d, _, A, "∽", "\\backsim", !0), o(d, _, A, "⋍", "\\backsimeq", !0), o(d, _, A, "⫅", "\\subseteqq", !0), o(d, _, A, "⋐", "\\Subset", !0), o(d, _, A, "⊏", "\\sqsubset", !0), o(d, _, A, "≼", "\\preccurlyeq", !0), o(d, _, A, "⋞", "\\curlyeqprec", !0), o(d, _, A, "≾", "\\precsim", !0), o(d, _, A, "⪷", "\\precapprox", !0), o(d, _, A, "⊲", "\\vartriangleleft"), o(d, _, A, "⊴", "\\trianglelefteq"), o(d, _, A, "⊨", "\\vDash", !0), o(d, _, A, "⊪", "\\Vvdash", !0), o(d, _, A, "⌣", "\\smallsmile"), o(d, _, A, "⌢", "\\smallfrown"), o(d, _, A, "≏", "\\bumpeq", !0), o(d, _, A, "≎", "\\Bumpeq", !0), o(d, _, A, "≧", "\\geqq", !0), o(d, _, A, "⩾", "\\geqslant", !0), o(d, _, A, "⪖", "\\eqslantgtr", !0), o(d, _, A, "≳", "\\gtrsim", !0), o(d, _, A, "⪆", "\\gtrapprox", !0), o(d, _, le, "⋗", "\\gtrdot"), o(d, _, A, "⋙", "\\ggg", !0), o(d, _, A, "≷", "\\gtrless", !0), o(d, _, A, "⋛", "\\gtreqless", !0), o(d, _, A, "⪌", "\\gtreqqless", !0), o(d, _, A, "≖", "\\eqcirc", !0), o(d, _, A, "≗", "\\circeq", !0), o(d, _, A, "≜", "\\triangleq", !0), o(d, _, A, "∼", "\\thicksim"), o(d, _, A, "≈", "\\thickapprox"), o(d, _, A, "⫆", "\\supseteqq", !0), o(d, _, A, "⋑", "\\Supset", !0), o(d, _, A, "⊐", "\\sqsupset", !0), o(d, _, A, "≽", "\\succcurlyeq", !0), o(d, _, A, "⋟", "\\curlyeqsucc", !0), o(d, _, A, "≿", "\\succsim", !0), o(d, _, A, "⪸", "\\succapprox", !0), o(d, _, A, "⊳", "\\vartriangleright"), o(d, _, A, "⊵", "\\trianglerighteq"), o(d, _, A, "⊩", "\\Vdash", !0), o(d, _, A, "∣", "\\shortmid"), o(d, _, A, "∥", "\\shortparallel"), o(d, _, A, "≬", "\\between", !0), o(d, _, A, "⋔", "\\pitchfork", !0), o(d, _, A, "∝", "\\varpropto"), o(d, _, A, "◀", "\\blacktriangleleft"), o(d, _, A, "∴", "\\therefore", !0), o(d, _, A, "∍", "\\backepsilon"), o(d, _, A, "▶", "\\blacktriangleright"), o(d, _, A, "∵", "\\because", !0), o(d, _, A, "⋘", "\\llless"), o(d, _, A, "⋙", "\\gggtr"), o(d, _, le, "⊲", "\\lhd"), o(d, _, le, "⊳", "\\rhd"), o(d, _, A, "≂", "\\eqsim", !0), o(d, b, A, "⋈", "\\Join"), o(d, _, A, "≑", "\\Doteq", !0), o(d, _, le, "∔", "\\dotplus", !0), o(d, _, le, "∖", "\\smallsetminus"), o(d, _, le, "⋒", "\\Cap", !0), o(d, _, le, "⋓", "\\Cup", !0), o(d, _, le, "⩞", "\\doublebarwedge", !0), o(d, _, le, "⊟", "\\boxminus", !0), o(d, _, le, "⊞", "\\boxplus", !0), o(d, _, le, "⋇", "\\divideontimes", !0), o(d, _, le, "⋉", "\\ltimes", !0), o(d, _, le, "⋊", "\\rtimes", !0), o(d, _, le, "⋋", "\\leftthreetimes", !0), o(d, _, le, "⋌", "\\rightthreetimes", !0), o(d, _, le, "⋏", "\\curlywedge", !0), o(d, _, le, "⋎", "\\curlyvee", !0), o(d, _, le, "⊝", "\\circleddash", !0), o(d, _, le, "⊛", "\\circledast", !0), o(d, _, le, "⋅", "\\centerdot"), o(d, _, le, "⊺", "\\intercal", !0), o(d, _, le, "⋒", "\\doublecap"), o(d, _, le, "⋓", "\\doublecup"), o(d, _, le, "⊠", "\\boxtimes", !0), o(d, _, A, "⇢", "\\dashrightarrow", !0), o(d, _, A, "⇠", "\\dashleftarrow", !0), o(d, _, A, "⇇", "\\leftleftarrows", !0), o(d, _, A, "⇆", "\\leftrightarrows", !0), o(d, _, A, "⇚", "\\Lleftarrow", !0), o(d, _, A, "↞", "\\twoheadleftarrow", !0), o(d, _, A, "↢", "\\leftarrowtail", !0), o(d, _, A, "↫", "\\looparrowleft", !0), o(d, _, A, "⇋", "\\leftrightharpoons", !0), o(d, _, A, "↶", "\\curvearrowleft", !0), o(d, _, A, "↺", "\\circlearrowleft", !0), o(d, _, A, "↰", "\\Lsh", !0), o(d, _, A, "⇈", "\\upuparrows", !0), o(d, _, A, "↿", "\\upharpoonleft", !0), o(d, _, A, "⇃", "\\downharpoonleft", !0), o(d, b, A, "⊶", "\\origof", !0), o(d, b, A, "⊷", "\\imageof", !0), o(d, _, A, "⊸", "\\multimap", !0), o(d, _, A, "↭", "\\leftrightsquigarrow", !0), o(d, _, A, "⇉", "\\rightrightarrows", !0), o(d, _, A, "⇄", "\\rightleftarrows", !0), o(d, _, A, "↠", "\\twoheadrightarrow", !0), o(d, _, A, "↣", "\\rightarrowtail", !0), o(d, _, A, "↬", "\\looparrowright", !0), o(d, _, A, "↷", "\\curvearrowright", !0), o(d, _, A, "↻", "\\circlearrowright", !0), o(d, _, A, "↱", "\\Rsh", !0), o(d, _, A, "⇊", "\\downdownarrows", !0), o(d, _, A, "↾", "\\upharpoonright", !0), o(d, _, A, "⇂", "\\downharpoonright", !0), o(d, _, A, "⇝", "\\rightsquigarrow", !0), o(d, _, A, "⇝", "\\leadsto"), o(d, _, A, "⇛", "\\Rrightarrow", !0), o(d, _, A, "↾", "\\restriction"), o(d, b, T, "‘", "`"), o(d, b, T, "$", "\\$"), o(G, b, T, "$", "\\$"), o(G, b, T, "$", "\\textdollar"), o(d, b, T, "%", "\\%"), o(G, b, T, "%", "\\%"), o(d, b, T, "_", "\\_"), o(G, b, T, "_", "\\_"), o(G, b, T, "_", "\\textunderscore"), o(d, b, T, "∠", "\\angle", !0), o(d, b, T, "∞", "\\infty", !0), o(d, b, T, "′", "\\prime"), o(d, b, T, "△", "\\triangle"), o(d, b, T, "Γ", "\\Gamma", !0), o(d, b, T, "Δ", "\\Delta", !0), o(d, b, T, "Θ", "\\Theta", !0), o(d, b, T, "Λ", "\\Lambda", !0), o(d, b, T, "Ξ", "\\Xi", !0), o(d, b, T, "Π", "\\Pi", !0), o(d, b, T, "Σ", "\\Sigma", !0), o(d, b, T, "Υ", "\\Upsilon", !0), o(d, b, T, "Φ", "\\Phi", !0), o(d, b, T, "Ψ", "\\Psi", !0), o(d, b, T, "Ω", "\\Omega", !0), o(d, b, T, "A", "Α"), o(d, b, T, "B", "Β"), o(d, b, T, "E", "Ε"), o(d, b, T, "Z", "Ζ"), o(d, b, T, "H", "Η"), o(d, b, T, "I", "Ι"), o(d, b, T, "K", "Κ"), o(d, b, T, "M", "Μ"), o(d, b, T, "N", "Ν"), o(d, b, T, "O", "Ο"), o(d, b, T, "P", "Ρ"), o(d, b, T, "T", "Τ"), o(d, b, T, "X", "Χ"), o(d, b, T, "¬", "\\neg", !0), o(d, b, T, "¬", "\\lnot"), o(d, b, T, "⊤", "\\top"), o(d, b, T, "⊥", "\\bot"), o(d, b, T, "∅", "\\emptyset"), o(d, _, T, "∅", "\\varnothing"), o(d, b, F, "α", "\\alpha", !0), o(d, b, F, "β", "\\beta", !0), o(d, b, F, "γ", "\\gamma", !0), o(d, b, F, "δ", "\\delta", !0), o(d, b, F, "ϵ", "\\epsilon", !0), o(d, b, F, "ζ", "\\zeta", !0), o(d, b, F, "η", "\\eta", !0), o(d, b, F, "θ", "\\theta", !0), o(d, b, F, "ι", "\\iota", !0), o(d, b, F, "κ", "\\kappa", !0), o(d, b, F, "λ", "\\lambda", !0), o(d, b, F, "μ", "\\mu", !0), o(d, b, F, "ν", "\\nu", !0), o(d, b, F, "ξ", "\\xi", !0), o(d, b, F, "ο", "\\omicron", !0), o(d, b, F, "π", "\\pi", !0), o(d, b, F, "ρ", "\\rho", !0), o(d, b, F, "σ", "\\sigma", !0), o(d, b, F, "τ", "\\tau", !0), o(d, b, F, "υ", "\\upsilon", !0), o(d, b, F, "ϕ", "\\phi", !0), o(d, b, F, "χ", "\\chi", !0), o(d, b, F, "ψ", "\\psi", !0), o(d, b, F, "ω", "\\omega", !0), o(d, b, F, "ε", "\\varepsilon", !0), o(d, b, F, "ϑ", "\\vartheta", !0), o(d, b, F, "ϖ", "\\varpi", !0), o(d, b, F, "ϱ", "\\varrho", !0), o(d, b, F, "ς", "\\varsigma", !0), o(d, b, F, "φ", "\\varphi", !0), o(d, b, le, "∗", "*", !0), o(d, b, le, "+", "+"), o(d, b, le, "−", "-", !0), o(d, b, le, "⋅", "\\cdot", !0), o(d, b, le, "∘", "\\circ", !0), o(d, b, le, "÷", "\\div", !0), o(d, b, le, "±", "\\pm", !0), o(d, b, le, "×", "\\times", !0), o(d, b, le, "∩", "\\cap", !0), o(d, b, le, "∪", "\\cup", !0), o(d, b, le, "∖", "\\setminus", !0), o(d, b, le, "∧", "\\land"), o(d, b, le, "∨", "\\lor"), o(d, b, le, "∧", "\\wedge", !0), o(d, b, le, "∨", "\\vee", !0), o(d, b, T, "√", "\\surd"), o(d, b, te, "⟨", "\\langle", !0), o(d, b, te, "∣", "\\lvert"), o(d, b, te, "∥", "\\lVert"), o(d, b, tt, "?", "?"), o(d, b, tt, "!", "!"), o(d, b, tt, "⟩", "\\rangle", !0), o(d, b, tt, "∣", "\\rvert"), o(d, b, tt, "∥", "\\rVert"), o(d, b, A, "=", "="), o(d, b, A, ":", ":"), o(d, b, A, "≈", "\\approx", !0), o(d, b, A, "≅", "\\cong", !0), o(d, b, A, "≥", "\\ge"), o(d, b, A, "≥", "\\geq", !0), o(d, b, A, "←", "\\gets"), o(d, b, A, ">", "\\gt", !0), o(d, b, A, "∈", "\\in", !0), o(d, b, A, "", "\\@not"), o(d, b, A, "⊂", "\\subset", !0), o(d, b, A, "⊃", "\\supset", !0), o(d, b, A, "⊆", "\\subseteq", !0), o(d, b, A, "⊇", "\\supseteq", !0), o(d, _, A, "⊈", "\\nsubseteq", !0), o(d, _, A, "⊉", "\\nsupseteq", !0), o(d, b, A, "⊨", "\\models"), o(d, b, A, "←", "\\leftarrow", !0), o(d, b, A, "≤", "\\le"), o(d, b, A, "≤", "\\leq", !0), o(d, b, A, "<", "\\lt", !0), o(d, b, A, "→", "\\rightarrow", !0), o(d, b, A, "→", "\\to"), o(d, _, A, "≱", "\\ngeq", !0), o(d, _, A, "≰", "\\nleq", !0), o(d, b, Pe, " ", "\\ "), o(d, b, Pe, " ", "\\space"), o(d, b, Pe, " ", "\\nobreakspace"), o(G, b, Pe, " ", "\\ "), o(G, b, Pe, " ", " "), o(G, b, Pe, " ", "\\space"), o(G, b, Pe, " ", "\\nobreakspace"), o(d, b, Pe, null, "\\nobreak"), o(d, b, Pe, null, "\\allowbreak"), o(d, b, Be, ",", ","), o(d, b, Be, ";", ";"), o(d, _, le, "⊼", "\\barwedge", !0), o(d, _, le, "⊻", "\\veebar", !0), o(d, b, le, "⊙", "\\odot", !0), o(d, b, le, "⊕", "\\oplus", !0), o(d, b, le, "⊗", "\\otimes", !0), o(d, b, T, "∂", "\\partial", !0), o(d, b, le, "⊘", "\\oslash", !0), o(d, _, le, "⊚", "\\circledcirc", !0), o(d, _, le, "⊡", "\\boxdot", !0), o(d, b, le, "△", "\\bigtriangleup"), o(d, b, le, "▽", "\\bigtriangledown"), o(d, b, le, "†", "\\dagger"), o(d, b, le, "⋄", "\\diamond"), o(d, b, le, "⋆", "\\star"), o(d, b, le, "◃", "\\triangleleft"), o(d, b, le, "▹", "\\triangleright"), o(d, b, te, "{", "\\{"), o(G, b, T, "{", "\\{"), o(G, b, T, "{", "\\textbraceleft"), o(d, b, tt, "}", "\\}"), o(G, b, T, "}", "\\}"), o(G, b, T, "}", "\\textbraceright"), o(d, b, te, "{", "\\lbrace"), o(d, b, tt, "}", "\\rbrace"), o(d, b, te, "[", "\\lbrack", !0), o(G, b, T, "[", "\\lbrack", !0), o(d, b, tt, "]", "\\rbrack", !0), o(G, b, T, "]", "\\rbrack", !0), o(d, b, te, "(", "\\lparen", !0), o(d, b, tt, ")", "\\rparen", !0), o(G, b, T, "<", "\\textless", !0), o(G, b, T, ">", "\\textgreater", !0), o(d, b, te, "⌊", "\\lfloor", !0), o(d, b, tt, "⌋", "\\rfloor", !0), o(d, b, te, "⌈", "\\lceil", !0), o(d, b, tt, "⌉", "\\rceil", !0), o(d, b, T, "\\", "\\backslash"), o(d, b, T, "∣", "|"), o(d, b, T, "∣", "\\vert"), o(G, b, T, "|", "\\textbar", !0), o(d, b, T, "∥", "\\|"), o(d, b, T, "∥", "\\Vert"), o(G, b, T, "∥", "\\textbardbl"), o(G, b, T, "~", "\\textasciitilde"), o(G, b, T, "\\", "\\textbackslash"), o(G, b, T, "^", "\\textasciicircum"), o(d, b, A, "↑", "\\uparrow", !0), o(d, b, A, "⇑", "\\Uparrow", !0), o(d, b, A, "↓", "\\downarrow", !0), o(d, b, A, "⇓", "\\Downarrow", !0), o(d, b, A, "↕", "\\updownarrow", !0), o(d, b, A, "⇕", "\\Updownarrow", !0), o(d, b, V, "∐", "\\coprod"), o(d, b, V, "⋁", "\\bigvee"), o(d, b, V, "⋀", "\\bigwedge"), o(d, b, V, "⨄", "\\biguplus"), o(d, b, V, "⋂", "\\bigcap"), o(d, b, V, "⋃", "\\bigcup"), o(d, b, V, "∫", "\\int"), o(d, b, V, "∫", "\\intop"), o(d, b, V, "∬", "\\iint"), o(d, b, V, "∭", "\\iiint"), o(d, b, V, "∏", "\\prod"), o(d, b, V, "∑", "\\sum"), o(d, b, V, "⨂", "\\bigotimes"), o(d, b, V, "⨁", "\\bigoplus"), o(d, b, V, "⨀", "\\bigodot"), o(d, b, V, "∮", "\\oint"), o(d, b, V, "∯", "\\oiint"), o(d, b, V, "∰", "\\oiiint"), o(d, b, V, "⨆", "\\bigsqcup"), o(d, b, V, "∫", "\\smallint"), o(G, b, fe, "…", "\\textellipsis"), o(d, b, fe, "…", "\\mathellipsis"), o(G, b, fe, "…", "\\ldots", !0), o(d, b, fe, "…", "\\ldots", !0), o(d, b, fe, "⋯", "\\@cdots", !0), o(d, b, fe, "⋱", "\\ddots", !0), o(d, b, T, "⋮", "\\varvdots"), o(d, b, Le, "ˊ", "\\acute"), o(d, b, Le, "ˋ", "\\grave"), o(d, b, Le, "¨", "\\ddot"), o(d, b, Le, "~", "\\tilde"), o(d, b, Le, "ˉ", "\\bar"), o(d, b, Le, "˘", "\\breve"), o(d, b, Le, "ˇ", "\\check"), o(d, b, Le, "^", "\\hat"), o(d, b, Le, "⃗", "\\vec"), o(d, b, Le, "˙", "\\dot"), o(d, b, Le, "˚", "\\mathring"), o(d, b, F, "", "\\@imath"), o(d, b, F, "", "\\@jmath"), o(d, b, T, "ı", "ı"), o(d, b, T, "ȷ", "ȷ"), o(G, b, T, "ı", "\\i", !0), o(G, b, T, "ȷ", "\\j", !0), o(G, b, T, "ß", "\\ss", !0), o(G, b, T, "æ", "\\ae", !0), o(G, b, T, "œ", "\\oe", !0), o(G, b, T, "ø", "\\o", !0), o(G, b, T, "Æ", "\\AE", !0), o(G, b, T, "Œ", "\\OE", !0), o(G, b, T, "Ø", "\\O", !0), o(G, b, Le, "ˊ", "\\'"), o(G, b, Le, "ˋ", "\\`"), o(G, b, Le, "ˆ", "\\^"), o(G, b, Le, "˜", "\\~"), o(G, b, Le, "ˉ", "\\="), o(G, b, Le, "˘", "\\u"), o(G, b, Le, "˙", "\\."), o(G, b, Le, "¸", "\\c"), o(G, b, Le, "˚", "\\r"), o(G, b, Le, "ˇ", "\\v"), o(G, b, Le, "¨", '\\"'), o(G, b, Le, "˝", "\\H"), o(G, b, Le, "◯", "\\textcircled");
          var Ht = {
            "--": !0,
            "---": !0,
            "``": !0,
            "''": !0
          };
          o(G, b, T, "–", "--", !0), o(G, b, T, "–", "\\textendash"), o(G, b, T, "—", "---", !0), o(G, b, T, "—", "\\textemdash"), o(G, b, T, "‘", "`", !0), o(G, b, T, "‘", "\\textquoteleft"), o(G, b, T, "’", "'", !0), o(G, b, T, "’", "\\textquoteright"), o(G, b, T, "“", "``", !0), o(G, b, T, "“", "\\textquotedblleft"), o(G, b, T, "”", "''", !0), o(G, b, T, "”", "\\textquotedblright"), o(d, b, T, "°", "\\degree", !0), o(G, b, T, "°", "\\degree"), o(G, b, T, "°", "\\textdegree", !0), o(d, b, T, "£", "\\pounds"), o(d, b, T, "£", "\\mathsterling", !0), o(G, b, T, "£", "\\pounds"), o(G, b, T, "£", "\\textsterling", !0), o(d, _, T, "✠", "\\maltese"), o(G, _, T, "✠", "\\maltese");
          for (var f0 = '0123456789/@."', et = 0; et < f0.length; et++) {
            var mr = f0.charAt(et);
            o(d, b, T, mr, mr);
          }
          for (var dr = '0123456789!@*()-=+";:?/.,', Tn = 0; Tn < dr.length; Tn++) {
            var Wa = dr.charAt(Tn);
            o(G, b, T, Wa, Wa);
          }
          for (var Lr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", Bn = 0; Bn < Lr.length; Bn++) {
            var Or = Lr.charAt(Bn);
            o(d, b, F, Or, Or), o(G, b, T, Or, Or);
          }
          o(d, _, T, "C", "ℂ"), o(G, _, T, "C", "ℂ"), o(d, _, T, "H", "ℍ"), o(G, _, T, "H", "ℍ"), o(d, _, T, "N", "ℕ"), o(G, _, T, "N", "ℕ"), o(d, _, T, "P", "ℙ"), o(G, _, T, "P", "ℙ"), o(d, _, T, "Q", "ℚ"), o(G, _, T, "Q", "ℚ"), o(d, _, T, "R", "ℝ"), o(G, _, T, "R", "ℝ"), o(d, _, T, "Z", "ℤ"), o(G, _, T, "Z", "ℤ"), o(d, b, F, "h", "ℎ"), o(G, b, F, "h", "ℎ");
          for (var ve = "", lt = 0; lt < Lr.length; lt++) {
            var Ye = Lr.charAt(lt);
            ve = String.fromCharCode(55349, 56320 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve), ve = String.fromCharCode(55349, 56372 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve), ve = String.fromCharCode(55349, 56424 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve), ve = String.fromCharCode(55349, 56580 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve), ve = String.fromCharCode(55349, 56684 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve), ve = String.fromCharCode(55349, 56736 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve), ve = String.fromCharCode(55349, 56788 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve), ve = String.fromCharCode(55349, 56840 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve), ve = String.fromCharCode(55349, 56944 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve), lt < 26 && (ve = String.fromCharCode(55349, 56632 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve), ve = String.fromCharCode(55349, 56476 + lt), o(d, b, F, Ye, ve), o(G, b, T, Ye, ve));
          }
          ve = String.fromCharCode(55349, 56668), o(d, b, F, "k", ve), o(G, b, T, "k", ve);
          for (var I0 = 0; I0 < 10; I0++) {
            var m0 = I0.toString();
            ve = String.fromCharCode(55349, 57294 + I0), o(d, b, F, m0, ve), o(G, b, T, m0, ve), ve = String.fromCharCode(55349, 57314 + I0), o(d, b, F, m0, ve), o(G, b, T, m0, ve), ve = String.fromCharCode(55349, 57324 + I0), o(d, b, F, m0, ve), o(G, b, T, m0, ve), ve = String.fromCharCode(55349, 57334 + I0), o(d, b, F, m0, ve), o(G, b, T, m0, ve);
          }
          for (var Mn = "ÐÞþ", zn = 0; zn < Mn.length; zn++) {
            var qr = Mn.charAt(zn);
            o(d, b, F, qr, qr), o(G, b, T, qr, qr);
          }
          var Pr = [
            ["mathbf", "textbf", "Main-Bold"],
            // A-Z bold upright
            ["mathbf", "textbf", "Main-Bold"],
            // a-z bold upright
            ["mathnormal", "textit", "Math-Italic"],
            // A-Z italic
            ["mathnormal", "textit", "Math-Italic"],
            // a-z italic
            ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
            // A-Z bold italic
            ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
            // a-z bold italic
            // Map fancy A-Z letters to script, not calligraphic.
            // This aligns with unicode-math and math fonts (except Cambria Math).
            ["mathscr", "textscr", "Script-Regular"],
            // A-Z script
            ["", "", ""],
            // a-z script.  No font
            ["", "", ""],
            // A-Z bold script. No font
            ["", "", ""],
            // a-z bold script. No font
            ["mathfrak", "textfrak", "Fraktur-Regular"],
            // A-Z Fraktur
            ["mathfrak", "textfrak", "Fraktur-Regular"],
            // a-z Fraktur
            ["mathbb", "textbb", "AMS-Regular"],
            // A-Z double-struck
            ["mathbb", "textbb", "AMS-Regular"],
            // k double-struck
            // Note that we are using a bold font, but font metrics for regular Fraktur.
            ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
            // A-Z bold Fraktur
            ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
            // a-z bold Fraktur
            ["mathsf", "textsf", "SansSerif-Regular"],
            // A-Z sans-serif
            ["mathsf", "textsf", "SansSerif-Regular"],
            // a-z sans-serif
            ["mathboldsf", "textboldsf", "SansSerif-Bold"],
            // A-Z bold sans-serif
            ["mathboldsf", "textboldsf", "SansSerif-Bold"],
            // a-z bold sans-serif
            ["mathitsf", "textitsf", "SansSerif-Italic"],
            // A-Z italic sans-serif
            ["mathitsf", "textitsf", "SansSerif-Italic"],
            // a-z italic sans-serif
            ["", "", ""],
            // A-Z bold italic sans. No font
            ["", "", ""],
            // a-z bold italic sans. No font
            ["mathtt", "texttt", "Typewriter-Regular"],
            // A-Z monospace
            ["mathtt", "texttt", "Typewriter-Regular"]
            // a-z monospace
          ], Ya = [
            ["mathbf", "textbf", "Main-Bold"],
            // 0-9 bold
            ["", "", ""],
            // 0-9 double-struck. No KaTeX font.
            ["mathsf", "textsf", "SansSerif-Regular"],
            // 0-9 sans-serif
            ["mathboldsf", "textboldsf", "SansSerif-Bold"],
            // 0-9 bold sans-serif
            ["mathtt", "texttt", "Typewriter-Regular"]
            // 0-9 monospace
          ], oo = function(e, t) {
            var r = e.charCodeAt(0), n = e.charCodeAt(1), s = (r - 55296) * 1024 + (n - 56320) + 65536, f = t === "math" ? 0 : 1;
            if (119808 <= s && s < 120484) {
              var g = Math.floor((s - 119808) / 26);
              return [Pr[g][2], Pr[g][f]];
            } else if (120782 <= s && s <= 120831) {
              var w = Math.floor((s - 120782) / 10);
              return [Ya[w][2], Ya[w][f]];
            } else {
              if (s === 120485 || s === 120486)
                return [Pr[0][2], Pr[0][f]];
              if (120486 < s && s < 120782)
                return ["", ""];
              throw new c("Unsupported character: " + e);
            }
          }, Hr = function(e, t, r) {
            return qe[r][e] && qe[r][e].replace && (e = qe[r][e].replace), {
              value: e,
              metrics: qt(e, t, r)
            };
          }, zt = function(e, t, r, n, s) {
            var f = Hr(e, t, r), g = f.metrics;
            e = f.value;
            var w;
            if (g) {
              var x = g.italic;
              (r === "text" || n && n.font === "mathit") && (x = 0), w = new it(e, g.height, g.depth, x, g.skew, g.width, s);
            } else
              typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + r + "'")), w = new it(e, 0, 0, 0, 0, 0, s);
            if (n) {
              w.maxFontSize = n.sizeMultiplier, n.style.isTight() && w.classes.push("mtight");
              var E = n.getColor();
              E && (w.style.color = E);
            }
            return w;
          }, uo = function(e, t, r, n) {
            return n === void 0 && (n = []), r.font === "boldsymbol" && Hr(e, "Main-Bold", t).metrics ? zt(e, "Main-Bold", t, r, n.concat(["mathbf"])) : e === "\\" || qe[t][e].font === "main" ? zt(e, "Main-Regular", t, r, n) : zt(e, "AMS-Regular", t, r, n.concat(["amsrm"]));
          }, co = function(e, t, r, n, s) {
            return s !== "textord" && Hr(e, "Math-BoldItalic", t).metrics ? {
              fontName: "Math-BoldItalic",
              fontClass: "boldsymbol"
            } : {
              fontName: "Main-Bold",
              fontClass: "mathbf"
            };
          }, ho = function(e, t, r) {
            var n = e.mode, s = e.text, f = ["mord"], g = n === "math" || n === "text" && t.font, w = g ? t.font : t.fontFamily, x = "", E = "";
            if (s.charCodeAt(0) === 55349) {
              var z = oo(s, n);
              x = z[0], E = z[1];
            }
            if (x.length > 0)
              return zt(s, x, n, t, f.concat(E));
            if (w) {
              var q, O;
              if (w === "boldsymbol") {
                var U = co(s, n, t, f, r);
                q = U.fontName, O = [U.fontClass];
              } else
                g ? (q = Za[w].fontName, O = [w]) : (q = Ur(w, t.fontWeight, t.fontShape), O = [w, t.fontWeight, t.fontShape]);
              if (Hr(s, q, n).metrics)
                return zt(s, q, n, t, f.concat(O));
              if (Ht.hasOwnProperty(s) && q.slice(0, 10) === "Typewriter") {
                for (var Q = [], ee = 0; ee < s.length; ee++)
                  Q.push(zt(s[ee], q, n, t, f.concat(O)));
                return ja(Q);
              }
            }
            if (r === "mathord")
              return zt(s, "Math-Italic", n, t, f.concat(["mathnormal"]));
            if (r === "textord") {
              var ce = qe[n][s] && qe[n][s].font;
              if (ce === "ams") {
                var me = Ur("amsrm", t.fontWeight, t.fontShape);
                return zt(s, me, n, t, f.concat("amsrm", t.fontWeight, t.fontShape));
              } else if (ce === "main" || !ce) {
                var pe = Ur("textrm", t.fontWeight, t.fontShape);
                return zt(s, pe, n, t, f.concat(t.fontWeight, t.fontShape));
              } else {
                var Ce = Ur(ce, t.fontWeight, t.fontShape);
                return zt(s, Ce, n, t, f.concat(Ce, t.fontWeight, t.fontShape));
              }
            } else
              throw new Error("unexpected type: " + r + " in makeOrd");
          }, fo = function(e, t) {
            if (nt(e.classes) !== nt(t.classes) || e.skew !== t.skew || e.maxFontSize !== t.maxFontSize)
              return !1;
            if (e.classes.length === 1) {
              var r = e.classes[0];
              if (r === "mbin" || r === "mord")
                return !1;
            }
            for (var n in e.style)
              if (e.style.hasOwnProperty(n) && e.style[n] !== t.style[n])
                return !1;
            for (var s in t.style)
              if (t.style.hasOwnProperty(s) && e.style[s] !== t.style[s])
                return !1;
            return !0;
          }, mo = function(e) {
            for (var t = 0; t < e.length - 1; t++) {
              var r = e[t], n = e[t + 1];
              r instanceof it && n instanceof it && fo(r, n) && (r.text += n.text, r.height = Math.max(r.height, n.height), r.depth = Math.max(r.depth, n.depth), r.italic = n.italic, e.splice(t + 1, 1), t--);
            }
            return e;
          }, Nn = function(e) {
            for (var t = 0, r = 0, n = 0, s = 0; s < e.children.length; s++) {
              var f = e.children[s];
              f.height > t && (t = f.height), f.depth > r && (r = f.depth), f.maxFontSize > n && (n = f.maxFontSize);
            }
            e.height = t, e.depth = r, e.maxFontSize = n;
          }, ht = function(e, t, r, n) {
            var s = new Dt(e, t, r, n);
            return Nn(s), s;
          }, Xa = function(e, t, r, n) {
            return new Dt(e, t, r, n);
          }, po = function(e, t, r) {
            var n = ht([e], [], t);
            return n.height = Math.max(r || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), n.style.borderBottomWidth = J(n.height), n.maxFontSize = 1, n;
          }, go = function(e, t, r, n) {
            var s = new cr(e, t, r, n);
            return Nn(s), s;
          }, ja = function(e) {
            var t = new l0(e);
            return Nn(t), t;
          }, vo = function(e, t) {
            return e instanceof l0 ? ht([], [e], t) : e;
          }, bo = function(e) {
            if (e.positionType === "individualShift") {
              for (var t = e.children, r = [t[0]], n = -t[0].shift - t[0].elem.depth, s = n, f = 1; f < t.length; f++) {
                var g = -t[f].shift - s - t[f].elem.depth, w = g - (t[f - 1].elem.height + t[f - 1].elem.depth);
                s = s + g, r.push({
                  type: "kern",
                  size: w
                }), r.push(t[f]);
              }
              return {
                children: r,
                depth: n
              };
            }
            var x;
            if (e.positionType === "top") {
              for (var E = e.positionData, z = 0; z < e.children.length; z++) {
                var q = e.children[z];
                E -= q.type === "kern" ? q.size : q.elem.height + q.elem.depth;
              }
              x = E;
            } else if (e.positionType === "bottom")
              x = -e.positionData;
            else {
              var O = e.children[0];
              if (O.type !== "elem")
                throw new Error('First child must have type "elem".');
              if (e.positionType === "shift")
                x = -O.elem.depth - e.positionData;
              else if (e.positionType === "firstBaseline")
                x = -O.elem.depth;
              else
                throw new Error("Invalid positionType " + e.positionType + ".");
            }
            return {
              children: e.children,
              depth: x
            };
          }, yo = function(e, t) {
            for (var r = bo(e), n = r.children, s = r.depth, f = 0, g = 0; g < n.length; g++) {
              var w = n[g];
              if (w.type === "elem") {
                var x = w.elem;
                f = Math.max(f, x.maxFontSize, x.height);
              }
            }
            f += 2;
            var E = ht(["pstrut"], []);
            E.style.height = J(f);
            for (var z = [], q = s, O = s, U = s, Q = 0; Q < n.length; Q++) {
              var ee = n[Q];
              if (ee.type === "kern")
                U += ee.size;
              else {
                var ce = ee.elem, me = ee.wrapperClasses || [], pe = ee.wrapperStyle || {}, Ce = ht(me, [E, ce], void 0, pe);
                Ce.style.top = J(-f - U - ce.depth), ee.marginLeft && (Ce.style.marginLeft = ee.marginLeft), ee.marginRight && (Ce.style.marginRight = ee.marginRight), z.push(Ce), U += ce.height + ce.depth;
              }
              q = Math.min(q, U), O = Math.max(O, U);
            }
            var we = ht(["vlist"], z);
            we.style.height = J(O);
            var Me;
            if (q < 0) {
              var Fe = ht([], []), ze = ht(["vlist"], [Fe]);
              ze.style.height = J(-q);
              var He = ht(["vlist-s"], [new it("​")]);
              Me = [ht(["vlist-r"], [we, He]), ht(["vlist-r"], [ze])];
            } else
              Me = [ht(["vlist-r"], [we])];
            var rt = ht(["vlist-t"], Me);
            return Me.length === 2 && rt.classes.push("vlist-t2"), rt.height = O, rt.depth = -q, rt;
          }, wo = function(e, t) {
            var r = ht(["mspace"], [], t), n = Ie(e, t);
            return r.style.marginRight = J(n), r;
          }, Ur = function(e, t, r) {
            var n = "";
            switch (e) {
              case "amsrm":
                n = "AMS";
                break;
              case "textrm":
                n = "Main";
                break;
              case "textsf":
                n = "SansSerif";
                break;
              case "texttt":
                n = "Typewriter";
                break;
              default:
                n = e;
            }
            var s;
            return t === "textbf" && r === "textit" ? s = "BoldItalic" : t === "textbf" ? s = "Bold" : t === "textit" ? s = "Italic" : s = "Regular", n + "-" + s;
          }, Za = {
            // styles
            mathbf: {
              variant: "bold",
              fontName: "Main-Bold"
            },
            mathrm: {
              variant: "normal",
              fontName: "Main-Regular"
            },
            textit: {
              variant: "italic",
              fontName: "Main-Italic"
            },
            mathit: {
              variant: "italic",
              fontName: "Main-Italic"
            },
            mathnormal: {
              variant: "italic",
              fontName: "Math-Italic"
            },
            // "boldsymbol" is missing because they require the use of multiple fonts:
            // Math-BoldItalic and Main-Bold.  This is handled by a special case in
            // makeOrd which ends up calling boldsymbol.
            // families
            mathbb: {
              variant: "double-struck",
              fontName: "AMS-Regular"
            },
            mathcal: {
              variant: "script",
              fontName: "Caligraphic-Regular"
            },
            mathfrak: {
              variant: "fraktur",
              fontName: "Fraktur-Regular"
            },
            mathscr: {
              variant: "script",
              fontName: "Script-Regular"
            },
            mathsf: {
              variant: "sans-serif",
              fontName: "SansSerif-Regular"
            },
            mathtt: {
              variant: "monospace",
              fontName: "Typewriter-Regular"
            }
          }, Ka = {
            //   path, width, height
            vec: ["vec", 0.471, 0.714],
            // values from the font glyph
            oiintSize1: ["oiintSize1", 0.957, 0.499],
            // oval to overlay the integrand
            oiintSize2: ["oiintSize2", 1.472, 0.659],
            oiiintSize1: ["oiiintSize1", 1.304, 0.499],
            oiiintSize2: ["oiiintSize2", 1.98, 0.659]
          }, ko = function(e, t) {
            var r = Ka[e], n = r[0], s = r[1], f = r[2], g = new Pt(n), w = new At([g], {
              width: J(s),
              height: J(f),
              // Override CSS rule `.katex svg { width: 100% }`
              style: "width:" + J(s),
              viewBox: "0 0 " + 1e3 * s + " " + 1e3 * f,
              preserveAspectRatio: "xMinYMin"
            }), x = Xa(["overlay"], [w], t);
            return x.height = f, x.style.height = J(f), x.style.width = J(s), x;
          }, N = {
            fontMap: Za,
            makeSymbol: zt,
            mathsym: uo,
            makeSpan: ht,
            makeSvgSpan: Xa,
            makeLineSpan: po,
            makeAnchor: go,
            makeFragment: ja,
            wrapFragment: vo,
            makeVList: yo,
            makeOrd: ho,
            makeGlue: wo,
            staticSvg: ko,
            svgData: Ka,
            tryCombineChars: mo
          }, Ge = {
            number: 3,
            unit: "mu"
          }, L0 = {
            number: 4,
            unit: "mu"
          }, $t = {
            number: 5,
            unit: "mu"
          }, xo = {
            mord: {
              mop: Ge,
              mbin: L0,
              mrel: $t,
              minner: Ge
            },
            mop: {
              mord: Ge,
              mop: Ge,
              mrel: $t,
              minner: Ge
            },
            mbin: {
              mord: L0,
              mop: L0,
              mopen: L0,
              minner: L0
            },
            mrel: {
              mord: $t,
              mop: $t,
              mopen: $t,
              minner: $t
            },
            mopen: {},
            mclose: {
              mop: Ge,
              mbin: L0,
              mrel: $t,
              minner: Ge
            },
            mpunct: {
              mord: Ge,
              mop: Ge,
              mrel: $t,
              mopen: Ge,
              mclose: Ge,
              mpunct: Ge,
              minner: Ge
            },
            minner: {
              mord: Ge,
              mop: Ge,
              mbin: L0,
              mrel: $t,
              mopen: Ge,
              mpunct: Ge,
              minner: Ge
            }
          }, Do = {
            mord: {
              mop: Ge
            },
            mop: {
              mord: Ge,
              mop: Ge
            },
            mbin: {},
            mrel: {},
            mopen: {},
            mclose: {
              mop: Ge
            },
            mpunct: {},
            minner: {
              mop: Ge
            }
          }, Qa = {}, Gr = {}, Vr = {};
          function ne(h) {
            for (var e = h.type, t = h.names, r = h.props, n = h.handler, s = h.htmlBuilder, f = h.mathmlBuilder, g = {
              type: e,
              numArgs: r.numArgs,
              argTypes: r.argTypes,
              allowedInArgument: !!r.allowedInArgument,
              allowedInText: !!r.allowedInText,
              allowedInMath: r.allowedInMath === void 0 ? !0 : r.allowedInMath,
              numOptionalArgs: r.numOptionalArgs || 0,
              infix: !!r.infix,
              primitive: !!r.primitive,
              handler: n
            }, w = 0; w < t.length; ++w)
              Qa[t[w]] = g;
            e && (s && (Gr[e] = s), f && (Vr[e] = f));
          }
          function O0(h) {
            var e = h.type, t = h.htmlBuilder, r = h.mathmlBuilder;
            ne({
              type: e,
              names: [],
              props: {
                numArgs: 0
              },
              handler: function() {
                throw new Error("Should never be called.");
              },
              htmlBuilder: t,
              mathmlBuilder: r
            });
          }
          var Wr = function(e) {
            return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
          }, Ze = function(e) {
            return e.type === "ordgroup" ? e.body : [e];
          }, e0 = N.makeSpan, Ao = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"], _o = ["rightmost", "mrel", "mclose", "mpunct"], So = {
            display: K.DISPLAY,
            text: K.TEXT,
            script: K.SCRIPT,
            scriptscript: K.SCRIPTSCRIPT
          }, Fo = {
            mord: "mord",
            mop: "mop",
            mbin: "mbin",
            mrel: "mrel",
            mopen: "mopen",
            mclose: "mclose",
            mpunct: "mpunct",
            minner: "minner"
          }, $e = function(e, t, r, n) {
            n === void 0 && (n = [null, null]);
            for (var s = [], f = 0; f < e.length; f++) {
              var g = Se(e[f], t);
              if (g instanceof l0) {
                var w = g.children;
                s.push.apply(s, w);
              } else
                s.push(g);
            }
            if (N.tryCombineChars(s), !r)
              return s;
            var x = t;
            if (e.length === 1) {
              var E = e[0];
              E.type === "sizing" ? x = t.havingSize(E.size) : E.type === "styling" && (x = t.havingStyle(So[E.style]));
            }
            var z = e0([n[0] || "leftmost"], [], t), q = e0([n[1] || "rightmost"], [], t), O = r === "root";
            return Ja(s, function(U, Q) {
              var ee = Q.classes[0], ce = U.classes[0];
              ee === "mbin" && L.contains(_o, ce) ? Q.classes[0] = "mord" : ce === "mbin" && L.contains(Ao, ee) && (U.classes[0] = "mord");
            }, {
              node: z
            }, q, O), Ja(s, function(U, Q) {
              var ee = Rn(Q), ce = Rn(U), me = ee && ce ? U.hasClass("mtight") ? Do[ee][ce] : xo[ee][ce] : null;
              if (me)
                return N.makeGlue(me, x);
            }, {
              node: z
            }, q, O), s;
          }, Ja = function h(e, t, r, n, s) {
            n && e.push(n);
            for (var f = 0; f < e.length; f++) {
              var g = e[f], w = $a(g);
              if (w) {
                h(w.children, t, r, null, s);
                continue;
              }
              var x = !g.hasClass("mspace");
              if (x) {
                var E = t(g, r.node);
                E && (r.insertAfter ? r.insertAfter(E) : (e.unshift(E), f++));
              }
              x ? r.node = g : s && g.hasClass("newline") && (r.node = e0(["leftmost"])), r.insertAfter = function(z) {
                return function(q) {
                  e.splice(z + 1, 0, q), f++;
                };
              }(f);
            }
            n && e.pop();
          }, $a = function(e) {
            return e instanceof l0 || e instanceof cr || e instanceof Dt && e.hasClass("enclosing") ? e : null;
          }, Eo = function h(e, t) {
            var r = $a(e);
            if (r) {
              var n = r.children;
              if (n.length) {
                if (t === "right")
                  return h(n[n.length - 1], "right");
                if (t === "left")
                  return h(n[0], "left");
              }
            }
            return e;
          }, Rn = function(e, t) {
            return e ? (t && (e = Eo(e, t)), Fo[e.classes[0]] || null) : null;
          }, pr = function(e, t) {
            var r = ["nulldelimiter"].concat(e.baseSizingClasses());
            return e0(t.concat(r));
          }, Se = function(e, t, r) {
            if (!e)
              return e0();
            if (Gr[e.type]) {
              var n = Gr[e.type](e, t);
              if (r && t.size !== r.size) {
                n = e0(t.sizingClasses(r), [n], t);
                var s = t.sizeMultiplier / r.sizeMultiplier;
                n.height *= s, n.depth *= s;
              }
              return n;
            } else
              throw new c("Got group of unknown type: '" + e.type + "'");
          };
          function Yr(h, e) {
            var t = e0(["base"], h, e), r = e0(["strut"]);
            return r.style.height = J(t.height + t.depth), t.depth && (r.style.verticalAlign = J(-t.depth)), t.children.unshift(r), t;
          }
          function In(h, e) {
            var t = null;
            h.length === 1 && h[0].type === "tag" && (t = h[0].tag, h = h[0].body);
            var r = $e(h, e, "root"), n;
            r.length === 2 && r[1].hasClass("tag") && (n = r.pop());
            for (var s = [], f = [], g = 0; g < r.length; g++)
              if (f.push(r[g]), r[g].hasClass("mbin") || r[g].hasClass("mrel") || r[g].hasClass("allowbreak")) {
                for (var w = !1; g < r.length - 1 && r[g + 1].hasClass("mspace") && !r[g + 1].hasClass("newline"); )
                  g++, f.push(r[g]), r[g].hasClass("nobreak") && (w = !0);
                w || (s.push(Yr(f, e)), f = []);
              } else
                r[g].hasClass("newline") && (f.pop(), f.length > 0 && (s.push(Yr(f, e)), f = []), s.push(r[g]));
            f.length > 0 && s.push(Yr(f, e));
            var x;
            t ? (x = Yr($e(t, e, !0)), x.classes = ["tag"], s.push(x)) : n && s.push(n);
            var E = e0(["katex-html"], s);
            if (E.setAttribute("aria-hidden", "true"), x) {
              var z = x.children[0];
              z.style.height = J(E.height + E.depth), E.depth && (z.style.verticalAlign = J(-E.depth));
            }
            return E;
          }
          function ei(h) {
            return new l0(h);
          }
          var _t = /* @__PURE__ */ function() {
            function h(t, r, n) {
              this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = t, this.attributes = {}, this.children = r || [], this.classes = n || [];
            }
            var e = h.prototype;
            return e.setAttribute = function(r, n) {
              this.attributes[r] = n;
            }, e.getAttribute = function(r) {
              return this.attributes[r];
            }, e.toNode = function() {
              var r = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
              for (var n in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, n) && r.setAttribute(n, this.attributes[n]);
              this.classes.length > 0 && (r.className = nt(this.classes));
              for (var s = 0; s < this.children.length; s++)
                r.appendChild(this.children[s].toNode());
              return r;
            }, e.toMarkup = function() {
              var r = "<" + this.type;
              for (var n in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, n) && (r += " " + n + '="', r += L.escape(this.attributes[n]), r += '"');
              this.classes.length > 0 && (r += ' class ="' + L.escape(nt(this.classes)) + '"'), r += ">";
              for (var s = 0; s < this.children.length; s++)
                r += this.children[s].toMarkup();
              return r += "</" + this.type + ">", r;
            }, e.toText = function() {
              return this.children.map(function(r) {
                return r.toText();
              }).join("");
            }, h;
          }(), gr = /* @__PURE__ */ function() {
            function h(t) {
              this.text = void 0, this.text = t;
            }
            var e = h.prototype;
            return e.toNode = function() {
              return document.createTextNode(this.text);
            }, e.toMarkup = function() {
              return L.escape(this.toText());
            }, e.toText = function() {
              return this.text;
            }, h;
          }(), Co = /* @__PURE__ */ function() {
            function h(t) {
              this.width = void 0, this.character = void 0, this.width = t, t >= 0.05555 && t <= 0.05556 ? this.character = " " : t >= 0.1666 && t <= 0.1667 ? this.character = " " : t >= 0.2222 && t <= 0.2223 ? this.character = " " : t >= 0.2777 && t <= 0.2778 ? this.character = "  " : t >= -0.05556 && t <= -0.05555 ? this.character = " ⁣" : t >= -0.1667 && t <= -0.1666 ? this.character = " ⁣" : t >= -0.2223 && t <= -0.2222 ? this.character = " ⁣" : t >= -0.2778 && t <= -0.2777 ? this.character = " ⁣" : this.character = null;
            }
            var e = h.prototype;
            return e.toNode = function() {
              if (this.character)
                return document.createTextNode(this.character);
              var r = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
              return r.setAttribute("width", J(this.width)), r;
            }, e.toMarkup = function() {
              return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + J(this.width) + '"/>';
            }, e.toText = function() {
              return this.character ? this.character : " ";
            }, h;
          }(), Y = {
            MathNode: _t,
            TextNode: gr,
            SpaceNode: Co,
            newDocumentFragment: ei
          }, St = function(e, t, r) {
            return qe[t][e] && qe[t][e].replace && e.charCodeAt(0) !== 55349 && !(Ht.hasOwnProperty(e) && r && (r.fontFamily && r.fontFamily.slice(4, 6) === "tt" || r.font && r.font.slice(4, 6) === "tt")) && (e = qe[t][e].replace), new Y.TextNode(e);
          }, Ln = function(e) {
            return e.length === 1 ? e[0] : new Y.MathNode("mrow", e);
          }, On = function(e, t) {
            if (t.fontFamily === "texttt")
              return "monospace";
            if (t.fontFamily === "textsf")
              return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
            if (t.fontShape === "textit" && t.fontWeight === "textbf")
              return "bold-italic";
            if (t.fontShape === "textit")
              return "italic";
            if (t.fontWeight === "textbf")
              return "bold";
            var r = t.font;
            if (!r || r === "mathnormal")
              return null;
            var n = e.mode;
            if (r === "mathit")
              return "italic";
            if (r === "boldsymbol")
              return e.type === "textord" ? "bold" : "bold-italic";
            if (r === "mathbf")
              return "bold";
            if (r === "mathbb")
              return "double-struck";
            if (r === "mathfrak")
              return "fraktur";
            if (r === "mathscr" || r === "mathcal")
              return "script";
            if (r === "mathsf")
              return "sans-serif";
            if (r === "mathtt")
              return "monospace";
            var s = e.text;
            if (L.contains(["\\imath", "\\jmath"], s))
              return null;
            qe[n][s] && qe[n][s].replace && (s = qe[n][s].replace);
            var f = N.fontMap[r].fontName;
            return qt(s, f, n) ? N.fontMap[r].variant : null;
          }, ft = function(e, t, r) {
            if (e.length === 1) {
              var n = Oe(e[0], t);
              return r && n instanceof _t && n.type === "mo" && (n.setAttribute("lspace", "0em"), n.setAttribute("rspace", "0em")), [n];
            }
            for (var s = [], f, g = 0; g < e.length; g++) {
              var w = Oe(e[g], t);
              if (w instanceof _t && f instanceof _t) {
                if (w.type === "mtext" && f.type === "mtext" && w.getAttribute("mathvariant") === f.getAttribute("mathvariant")) {
                  var x;
                  (x = f.children).push.apply(x, w.children);
                  continue;
                } else if (w.type === "mn" && f.type === "mn") {
                  var E;
                  (E = f.children).push.apply(E, w.children);
                  continue;
                } else if (w.type === "mi" && w.children.length === 1 && f.type === "mn") {
                  var z = w.children[0];
                  if (z instanceof gr && z.text === ".") {
                    var q;
                    (q = f.children).push.apply(q, w.children);
                    continue;
                  }
                } else if (f.type === "mi" && f.children.length === 1) {
                  var O = f.children[0];
                  if (O instanceof gr && O.text === "̸" && (w.type === "mo" || w.type === "mi" || w.type === "mn")) {
                    var U = w.children[0];
                    U instanceof gr && U.text.length > 0 && (U.text = U.text.slice(0, 1) + "̸" + U.text.slice(1), s.pop());
                  }
                }
              }
              s.push(w), f = w;
            }
            return s;
          }, d0 = function(e, t, r) {
            return Ln(ft(e, t, r));
          }, Oe = function(e, t) {
            if (!e)
              return new Y.MathNode("mrow");
            if (Vr[e.type]) {
              var r = Vr[e.type](e, t);
              return r;
            } else
              throw new c("Got group of unknown type: '" + e.type + "'");
          };
          function ti(h, e, t, r, n) {
            var s = ft(h, t), f;
            s.length === 1 && s[0] instanceof _t && L.contains(["mrow", "mtable"], s[0].type) ? f = s[0] : f = new Y.MathNode("mrow", s);
            var g = new Y.MathNode("annotation", [new Y.TextNode(e)]);
            g.setAttribute("encoding", "application/x-tex");
            var w = new Y.MathNode("semantics", [f, g]), x = new Y.MathNode("math", [w]);
            x.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML"), r && x.setAttribute("display", "block");
            var E = n ? "katex" : "katex-mathml";
            return N.makeSpan([E], [x]);
          }
          var ri = function(e) {
            return new Y0({
              style: e.displayMode ? K.DISPLAY : K.TEXT,
              maxSize: e.maxSize,
              minRuleThickness: e.minRuleThickness
            });
          }, ni = function(e, t) {
            if (t.displayMode) {
              var r = ["katex-display"];
              t.leqno && r.push("leqno"), t.fleqn && r.push("fleqn"), e = N.makeSpan(r, [e]);
            }
            return e;
          }, To = function(e, t, r) {
            var n = ri(r), s;
            if (r.output === "mathml")
              return ti(e, t, n, r.displayMode, !0);
            if (r.output === "html") {
              var f = In(e, n);
              s = N.makeSpan(["katex"], [f]);
            } else {
              var g = ti(e, t, n, r.displayMode, !1), w = In(e, n);
              s = N.makeSpan(["katex"], [g, w]);
            }
            return ni(s, r);
          }, Bo = function(e, t, r) {
            var n = ri(r), s = In(e, n), f = N.makeSpan(["katex"], [s]);
            return ni(f, r);
          }, Mo = {
            widehat: "^",
            widecheck: "ˇ",
            widetilde: "~",
            utilde: "~",
            overleftarrow: "←",
            underleftarrow: "←",
            xleftarrow: "←",
            overrightarrow: "→",
            underrightarrow: "→",
            xrightarrow: "→",
            underbrace: "⏟",
            overbrace: "⏞",
            overgroup: "⏠",
            undergroup: "⏡",
            overleftrightarrow: "↔",
            underleftrightarrow: "↔",
            xleftrightarrow: "↔",
            Overrightarrow: "⇒",
            xRightarrow: "⇒",
            overleftharpoon: "↼",
            xleftharpoonup: "↼",
            overrightharpoon: "⇀",
            xrightharpoonup: "⇀",
            xLeftarrow: "⇐",
            xLeftrightarrow: "⇔",
            xhookleftarrow: "↩",
            xhookrightarrow: "↪",
            xmapsto: "↦",
            xrightharpoondown: "⇁",
            xleftharpoondown: "↽",
            xrightleftharpoons: "⇌",
            xleftrightharpoons: "⇋",
            xtwoheadleftarrow: "↞",
            xtwoheadrightarrow: "↠",
            xlongequal: "=",
            xtofrom: "⇄",
            xrightleftarrows: "⇄",
            xrightequilibrium: "⇌",
            // Not a perfect match.
            xleftequilibrium: "⇋",
            // None better available.
            "\\cdrightarrow": "→",
            "\\cdleftarrow": "←",
            "\\cdlongequal": "="
          }, zo = function(e) {
            var t = new Y.MathNode("mo", [new Y.TextNode(Mo[e.replace(/^\\/, "")])]);
            return t.setAttribute("stretchy", "true"), t;
          }, No = {
            //   path(s), minWidth, height, align
            overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
            overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
            underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
            underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
            xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
            "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
            // CD minwwidth2.5pc
            xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
            "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
            Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
            xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
            xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
            overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
            xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
            xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
            overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
            xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
            xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
            xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
            "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
            xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
            xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
            overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
            overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
            underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
            underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
            xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
            xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
            xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
            xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
            xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
            xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
            overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
            underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
            overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
            undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
            xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
            xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
            // The next three arrows are from the mhchem package.
            // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
            // document as \xrightarrow or \xrightleftharpoons. Those have
            // min-length = 1.75em, so we set min-length on these next three to match.
            xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
            xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
            xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
          }, Ro = function(e) {
            return e.type === "ordgroup" ? e.body.length : 1;
          }, Io = function(e, t) {
            function r() {
              var w = 4e5, x = e.label.slice(1);
              if (L.contains(["widehat", "widecheck", "widetilde", "utilde"], x)) {
                var E = e, z = Ro(E.base), q, O, U;
                if (z > 5)
                  x === "widehat" || x === "widecheck" ? (q = 420, w = 2364, U = 0.42, O = x + "4") : (q = 312, w = 2340, U = 0.34, O = "tilde4");
                else {
                  var Q = [1, 1, 2, 2, 3, 3][z];
                  x === "widehat" || x === "widecheck" ? (w = [0, 1062, 2364, 2364, 2364][Q], q = [0, 239, 300, 360, 420][Q], U = [0, 0.24, 0.3, 0.3, 0.36, 0.42][Q], O = x + Q) : (w = [0, 600, 1033, 2339, 2340][Q], q = [0, 260, 286, 306, 312][Q], U = [0, 0.26, 0.286, 0.3, 0.306, 0.34][Q], O = "tilde" + Q);
                }
                var ee = new Pt(O), ce = new At([ee], {
                  width: "100%",
                  height: J(U),
                  viewBox: "0 0 " + w + " " + q,
                  preserveAspectRatio: "none"
                });
                return {
                  span: N.makeSvgSpan([], [ce], t),
                  minWidth: 0,
                  height: U
                };
              } else {
                var me = [], pe = No[x], Ce = pe[0], we = pe[1], Me = pe[2], Fe = Me / 1e3, ze = Ce.length, He, rt;
                if (ze === 1) {
                  var dt = pe[3];
                  He = ["hide-tail"], rt = [dt];
                } else if (ze === 2)
                  He = ["halfarrow-left", "halfarrow-right"], rt = ["xMinYMin", "xMaxYMin"];
                else if (ze === 3)
                  He = ["brace-left", "brace-center", "brace-right"], rt = ["xMinYMin", "xMidYMin", "xMaxYMin"];
                else
                  throw new Error(`Correct katexImagesData or update code here to support
                    ` + ze + " children.");
                for (var Ve = 0; Ve < ze; Ve++) {
                  var q0 = new Pt(Ce[Ve]), Ft = new At([q0], {
                    width: "400em",
                    height: J(Fe),
                    viewBox: "0 0 " + w + " " + Me,
                    preserveAspectRatio: rt[Ve] + " slice"
                  }), st = N.makeSvgSpan([He[Ve]], [Ft], t);
                  if (ze === 1)
                    return {
                      span: st,
                      minWidth: we,
                      height: Fe
                    };
                  st.style.height = J(Fe), me.push(st);
                }
                return {
                  span: N.makeSpan(["stretchy"], me, t),
                  minWidth: we,
                  height: Fe
                };
              }
            }
            var n = r(), s = n.span, f = n.minWidth, g = n.height;
            return s.height = g, s.style.height = J(g), f > 0 && (s.style.minWidth = J(f)), s;
          }, Lo = function(e, t, r, n, s) {
            var f, g = e.height + e.depth + r + n;
            if (/fbox|color|angl/.test(t)) {
              if (f = N.makeSpan(["stretchy", t], [], s), t === "fbox") {
                var w = s.color && s.getColor();
                w && (f.style.borderColor = w);
              }
            } else {
              var x = [];
              /^[bx]cancel$/.test(t) && x.push(new h0({
                x1: "0",
                y1: "0",
                x2: "100%",
                y2: "100%",
                "stroke-width": "0.046em"
              })), /^x?cancel$/.test(t) && x.push(new h0({
                x1: "0",
                y1: "100%",
                x2: "100%",
                y2: "0",
                "stroke-width": "0.046em"
              }));
              var E = new At(x, {
                width: "100%",
                height: J(g)
              });
              f = N.makeSvgSpan([], [E], s);
            }
            return f.height = g, f.style.height = J(g), f;
          }, t0 = {
            encloseSpan: Lo,
            mathMLnode: zo,
            svgSpan: Io
          };
          function ye(h, e) {
            if (!h || h.type !== e)
              throw new Error("Expected node of type " + e + ", but got " + (h ? "node of type " + h.type : String(h)));
            return h;
          }
          function qn(h) {
            var e = Xr(h);
            if (!e)
              throw new Error("Expected node of symbol group type, but got " + (h ? "node of type " + h.type : String(h)));
            return e;
          }
          function Xr(h) {
            return h && (h.type === "atom" || fr.hasOwnProperty(h.type)) ? h : null;
          }
          var Pn = function(e, t) {
            var r, n, s;
            e && e.type === "supsub" ? (n = ye(e.base, "accent"), r = n.base, e.base = r, s = Cn(Se(e, t)), e.base = n) : (n = ye(e, "accent"), r = n.base);
            var f = Se(r, t.havingCrampedStyle()), g = n.isShifty && L.isCharacterBox(r), w = 0;
            if (g) {
              var x = L.getBaseElem(r), E = Se(x, t.havingCrampedStyle());
              w = j0(E).skew;
            }
            var z = n.label === "\\c", q = z ? f.height + f.depth : Math.min(f.height, t.fontMetrics().xHeight), O;
            if (n.isStretchy)
              O = t0.svgSpan(n, t), O = N.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: f
                }, {
                  type: "elem",
                  elem: O,
                  wrapperClasses: ["svg-align"],
                  wrapperStyle: w > 0 ? {
                    width: "calc(100% - " + J(2 * w) + ")",
                    marginLeft: J(2 * w)
                  } : void 0
                }]
              }, t);
            else {
              var U, Q;
              n.label === "\\vec" ? (U = N.staticSvg("vec", t), Q = N.svgData.vec[1]) : (U = N.makeOrd({
                mode: n.mode,
                text: n.label
              }, t, "textord"), U = j0(U), U.italic = 0, Q = U.width, z && (q += U.depth)), O = N.makeSpan(["accent-body"], [U]);
              var ee = n.label === "\\textcircled";
              ee && (O.classes.push("accent-full"), q = f.height);
              var ce = w;
              ee || (ce -= Q / 2), O.style.left = J(ce), n.label === "\\textcircled" && (O.style.top = ".2em"), O = N.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: f
                }, {
                  type: "kern",
                  size: -q
                }, {
                  type: "elem",
                  elem: O
                }]
              }, t);
            }
            var me = N.makeSpan(["mord", "accent"], [O], t);
            return s ? (s.children[0] = me, s.height = Math.max(me.height, s.height), s.classes[0] = "mord", s) : me;
          }, ai = function(e, t) {
            var r = e.isStretchy ? t0.mathMLnode(e.label) : new Y.MathNode("mo", [St(e.label, e.mode)]), n = new Y.MathNode("mover", [Oe(e.base, t), r]);
            return n.setAttribute("accent", "true"), n;
          }, Oo = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map(function(h) {
            return "\\" + h;
          }).join("|"));
          ne({
            type: "accent",
            names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = Wr(t[0]), n = !Oo.test(e.funcName), s = !n || e.funcName === "\\widehat" || e.funcName === "\\widetilde" || e.funcName === "\\widecheck";
              return {
                type: "accent",
                mode: e.parser.mode,
                label: e.funcName,
                isStretchy: n,
                isShifty: s,
                base: r
              };
            },
            htmlBuilder: Pn,
            mathmlBuilder: ai
          }), ne({
            type: "accent",
            names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
            props: {
              numArgs: 1,
              allowedInText: !0,
              allowedInMath: !0,
              // unless in strict mode
              argTypes: ["primitive"]
            },
            handler: function(e, t) {
              var r = t[0], n = e.parser.mode;
              return n === "math" && (e.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + e.funcName + " works only in text mode"), n = "text"), {
                type: "accent",
                mode: n,
                label: e.funcName,
                isStretchy: !1,
                isShifty: !0,
                base: r
              };
            },
            htmlBuilder: Pn,
            mathmlBuilder: ai
          }), ne({
            type: "accentUnder",
            names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = t[0];
              return {
                type: "accentUnder",
                mode: r.mode,
                label: n,
                base: s
              };
            },
            htmlBuilder: function(e, t) {
              var r = Se(e.base, t), n = t0.svgSpan(e, t), s = e.label === "\\utilde" ? 0.12 : 0, f = N.makeVList({
                positionType: "top",
                positionData: r.height,
                children: [{
                  type: "elem",
                  elem: n,
                  wrapperClasses: ["svg-align"]
                }, {
                  type: "kern",
                  size: s
                }, {
                  type: "elem",
                  elem: r
                }]
              }, t);
              return N.makeSpan(["mord", "accentunder"], [f], t);
            },
            mathmlBuilder: function(e, t) {
              var r = t0.mathMLnode(e.label), n = new Y.MathNode("munder", [Oe(e.base, t), r]);
              return n.setAttribute("accentunder", "true"), n;
            }
          });
          var jr = function(e) {
            var t = new Y.MathNode("mpadded", e ? [e] : []);
            return t.setAttribute("width", "+0.6em"), t.setAttribute("lspace", "0.3em"), t;
          };
          ne({
            type: "xArrow",
            names: [
              "\\xleftarrow",
              "\\xrightarrow",
              "\\xLeftarrow",
              "\\xRightarrow",
              "\\xleftrightarrow",
              "\\xLeftrightarrow",
              "\\xhookleftarrow",
              "\\xhookrightarrow",
              "\\xmapsto",
              "\\xrightharpoondown",
              "\\xrightharpoonup",
              "\\xleftharpoondown",
              "\\xleftharpoonup",
              "\\xrightleftharpoons",
              "\\xleftrightharpoons",
              "\\xlongequal",
              "\\xtwoheadrightarrow",
              "\\xtwoheadleftarrow",
              "\\xtofrom",
              // The next 3 functions are here to support the mhchem extension.
              // Direct use of these functions is discouraged and may break someday.
              "\\xrightleftarrows",
              "\\xrightequilibrium",
              "\\xleftequilibrium",
              // The next 3 functions are here only to support the {CD} environment.
              "\\\\cdrightarrow",
              "\\\\cdleftarrow",
              "\\\\cdlongequal"
            ],
            props: {
              numArgs: 1,
              numOptionalArgs: 1
            },
            handler: function(e, t, r) {
              var n = e.parser, s = e.funcName;
              return {
                type: "xArrow",
                mode: n.mode,
                label: s,
                body: t[0],
                below: r[0]
              };
            },
            // Flow is unable to correctly infer the type of `group`, even though it's
            // unambiguously determined from the passed-in `type` above.
            htmlBuilder: function(e, t) {
              var r = t.style, n = t.havingStyle(r.sup()), s = N.wrapFragment(Se(e.body, n, t), t), f = e.label.slice(0, 2) === "\\x" ? "x" : "cd";
              s.classes.push(f + "-arrow-pad");
              var g;
              e.below && (n = t.havingStyle(r.sub()), g = N.wrapFragment(Se(e.below, n, t), t), g.classes.push(f + "-arrow-pad"));
              var w = t0.svgSpan(e, t), x = -t.fontMetrics().axisHeight + 0.5 * w.height, E = -t.fontMetrics().axisHeight - 0.5 * w.height - 0.111;
              (s.depth > 0.25 || e.label === "\\xleftequilibrium") && (E -= s.depth);
              var z;
              if (g) {
                var q = -t.fontMetrics().axisHeight + g.height + 0.5 * w.height + 0.111;
                z = N.makeVList({
                  positionType: "individualShift",
                  children: [{
                    type: "elem",
                    elem: s,
                    shift: E
                  }, {
                    type: "elem",
                    elem: w,
                    shift: x
                  }, {
                    type: "elem",
                    elem: g,
                    shift: q
                  }]
                }, t);
              } else
                z = N.makeVList({
                  positionType: "individualShift",
                  children: [{
                    type: "elem",
                    elem: s,
                    shift: E
                  }, {
                    type: "elem",
                    elem: w,
                    shift: x
                  }]
                }, t);
              return z.children[0].children[0].children[1].classes.push("svg-align"), N.makeSpan(["mrel", "x-arrow"], [z], t);
            },
            mathmlBuilder: function(e, t) {
              var r = t0.mathMLnode(e.label);
              r.setAttribute("minsize", e.label.charAt(0) === "x" ? "1.75em" : "3.0em");
              var n;
              if (e.body) {
                var s = jr(Oe(e.body, t));
                if (e.below) {
                  var f = jr(Oe(e.below, t));
                  n = new Y.MathNode("munderover", [r, f, s]);
                } else
                  n = new Y.MathNode("mover", [r, s]);
              } else if (e.below) {
                var g = jr(Oe(e.below, t));
                n = new Y.MathNode("munder", [r, g]);
              } else
                n = jr(), n = new Y.MathNode("mover", [r, n]);
              return n;
            }
          });
          var qo = N.makeSpan;
          function ii(h, e) {
            var t = $e(h.body, e, !0);
            return qo([h.mclass], t, e);
          }
          function li(h, e) {
            var t, r = ft(h.body, e);
            return h.mclass === "minner" ? t = new Y.MathNode("mpadded", r) : h.mclass === "mord" ? h.isCharacterBox ? (t = r[0], t.type = "mi") : t = new Y.MathNode("mi", r) : (h.isCharacterBox ? (t = r[0], t.type = "mo") : t = new Y.MathNode("mo", r), h.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : h.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : h.mclass === "mopen" || h.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : h.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
          }
          ne({
            type: "mclass",
            names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
            props: {
              numArgs: 1,
              primitive: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = t[0];
              return {
                type: "mclass",
                mode: r.mode,
                mclass: "m" + n.slice(5),
                // TODO(kevinb): don't prefix with 'm'
                body: Ze(s),
                isCharacterBox: L.isCharacterBox(s)
              };
            },
            htmlBuilder: ii,
            mathmlBuilder: li
          });
          var Zr = function(e) {
            var t = e.type === "ordgroup" && e.body.length ? e.body[0] : e;
            return t.type === "atom" && (t.family === "bin" || t.family === "rel") ? "m" + t.family : "mord";
          };
          ne({
            type: "mclass",
            names: ["\\@binrel"],
            props: {
              numArgs: 2
            },
            handler: function(e, t) {
              var r = e.parser;
              return {
                type: "mclass",
                mode: r.mode,
                mclass: Zr(t[0]),
                body: Ze(t[1]),
                isCharacterBox: L.isCharacterBox(t[1])
              };
            }
          }), ne({
            type: "mclass",
            names: ["\\stackrel", "\\overset", "\\underset"],
            props: {
              numArgs: 2
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = t[1], f = t[0], g;
              n !== "\\stackrel" ? g = Zr(s) : g = "mrel";
              var w = {
                type: "op",
                mode: s.mode,
                limits: !0,
                alwaysHandleSupSub: !0,
                parentIsSupSub: !1,
                symbol: !1,
                suppressBaseShift: n !== "\\stackrel",
                body: Ze(s)
              }, x = {
                type: "supsub",
                mode: f.mode,
                base: w,
                sup: n === "\\underset" ? null : f,
                sub: n === "\\underset" ? f : null
              };
              return {
                type: "mclass",
                mode: r.mode,
                mclass: g,
                body: [x],
                isCharacterBox: L.isCharacterBox(x)
              };
            },
            htmlBuilder: ii,
            mathmlBuilder: li
          }), ne({
            type: "pmb",
            names: ["\\pmb"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser;
              return {
                type: "pmb",
                mode: r.mode,
                mclass: Zr(t[0]),
                body: Ze(t[0])
              };
            },
            htmlBuilder: function(e, t) {
              var r = $e(e.body, t, !0), n = N.makeSpan([e.mclass], r, t);
              return n.style.textShadow = "0.02em 0.01em 0.04px", n;
            },
            mathmlBuilder: function(e, t) {
              var r = ft(e.body, t), n = new Y.MathNode("mstyle", r);
              return n.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), n;
            }
          });
          var Po = {
            ">": "\\\\cdrightarrow",
            "<": "\\\\cdleftarrow",
            "=": "\\\\cdlongequal",
            A: "\\uparrow",
            V: "\\downarrow",
            "|": "\\Vert",
            ".": "no arrow"
          }, si = function() {
            return {
              type: "styling",
              body: [],
              mode: "math",
              style: "display"
            };
          }, oi = function(e) {
            return e.type === "textord" && e.text === "@";
          }, Ho = function(e, t) {
            return (e.type === "mathord" || e.type === "atom") && e.text === t;
          };
          function Uo(h, e, t) {
            var r = Po[h];
            switch (r) {
              case "\\\\cdrightarrow":
              case "\\\\cdleftarrow":
                return t.callFunction(r, [e[0]], [e[1]]);
              case "\\uparrow":
              case "\\downarrow": {
                var n = t.callFunction("\\\\cdleft", [e[0]], []), s = {
                  type: "atom",
                  text: r,
                  mode: "math",
                  family: "rel"
                }, f = t.callFunction("\\Big", [s], []), g = t.callFunction("\\\\cdright", [e[1]], []), w = {
                  type: "ordgroup",
                  mode: "math",
                  body: [n, f, g]
                };
                return t.callFunction("\\\\cdparent", [w], []);
              }
              case "\\\\cdlongequal":
                return t.callFunction("\\\\cdlongequal", [], []);
              case "\\Vert": {
                var x = {
                  type: "textord",
                  text: "\\Vert",
                  mode: "math"
                };
                return t.callFunction("\\Big", [x], []);
              }
              default:
                return {
                  type: "textord",
                  text: " ",
                  mode: "math"
                };
            }
          }
          function Go(h) {
            var e = [];
            for (h.gullet.beginGroup(), h.gullet.macros.set("\\cr", "\\\\\\relax"), h.gullet.beginGroup(); ; ) {
              e.push(h.parseExpression(!1, "\\\\")), h.gullet.endGroup(), h.gullet.beginGroup();
              var t = h.fetch().text;
              if (t === "&" || t === "\\\\")
                h.consume();
              else if (t === "\\end") {
                e[e.length - 1].length === 0 && e.pop();
                break;
              } else
                throw new c("Expected \\\\ or \\cr or \\end", h.nextToken);
            }
            for (var r = [], n = [r], s = 0; s < e.length; s++) {
              for (var f = e[s], g = si(), w = 0; w < f.length; w++)
                if (!oi(f[w]))
                  g.body.push(f[w]);
                else {
                  r.push(g), w += 1;
                  var x = qn(f[w]).text, E = new Array(2);
                  if (E[0] = {
                    type: "ordgroup",
                    mode: "math",
                    body: []
                  }, E[1] = {
                    type: "ordgroup",
                    mode: "math",
                    body: []
                  }, !("=|.".indexOf(x) > -1))
                    if ("<>AV".indexOf(x) > -1)
                      for (var z = 0; z < 2; z++) {
                        for (var q = !0, O = w + 1; O < f.length; O++) {
                          if (Ho(f[O], x)) {
                            q = !1, w = O;
                            break;
                          }
                          if (oi(f[O]))
                            throw new c("Missing a " + x + " character to complete a CD arrow.", f[O]);
                          E[z].body.push(f[O]);
                        }
                        if (q)
                          throw new c("Missing a " + x + " character to complete a CD arrow.", f[w]);
                      }
                    else
                      throw new c('Expected one of "<>AV=|." after @', f[w]);
                  var U = Uo(x, E, h), Q = {
                    type: "styling",
                    body: [U],
                    mode: "math",
                    style: "display"
                    // CD is always displaystyle.
                  };
                  r.push(Q), g = si();
                }
              s % 2 === 0 ? r.push(g) : r.shift(), r = [], n.push(r);
            }
            h.gullet.endGroup(), h.gullet.endGroup();
            var ee = new Array(n[0].length).fill({
              type: "align",
              align: "c",
              pregap: 0.25,
              // CD package sets \enskip between columns.
              postgap: 0.25
              // So pre and post each get half an \enskip, i.e. 0.25em.
            });
            return {
              type: "array",
              mode: "math",
              body: n,
              arraystretch: 1,
              addJot: !0,
              rowGaps: [null],
              cols: ee,
              colSeparationType: "CD",
              hLinesBeforeRow: new Array(n.length + 1).fill([])
            };
          }
          ne({
            type: "cdlabel",
            names: ["\\\\cdleft", "\\\\cdright"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName;
              return {
                type: "cdlabel",
                mode: r.mode,
                side: n.slice(4),
                label: t[0]
              };
            },
            htmlBuilder: function(e, t) {
              var r = t.havingStyle(t.style.sup()), n = N.wrapFragment(Se(e.label, r, t), t);
              return n.classes.push("cd-label-" + e.side), n.style.bottom = J(0.8 - n.depth), n.height = 0, n.depth = 0, n;
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mrow", [Oe(e.label, t)]);
              return r = new Y.MathNode("mpadded", [r]), r.setAttribute("width", "0"), e.side === "left" && r.setAttribute("lspace", "-1width"), r.setAttribute("voffset", "0.7em"), r = new Y.MathNode("mstyle", [r]), r.setAttribute("displaystyle", "false"), r.setAttribute("scriptlevel", "1"), r;
            }
          }), ne({
            type: "cdlabelparent",
            names: ["\\\\cdparent"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = e.parser;
              return {
                type: "cdlabelparent",
                mode: r.mode,
                fragment: t[0]
              };
            },
            htmlBuilder: function(e, t) {
              var r = N.wrapFragment(Se(e.fragment, t), t);
              return r.classes.push("cd-vert-arrow"), r;
            },
            mathmlBuilder: function(e, t) {
              return new Y.MathNode("mrow", [Oe(e.fragment, t)]);
            }
          }), ne({
            type: "textord",
            names: ["\\@char"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, t) {
              for (var r = e.parser, n = ye(t[0], "ordgroup"), s = n.body, f = "", g = 0; g < s.length; g++) {
                var w = ye(s[g], "textord");
                f += w.text;
              }
              var x = parseInt(f), E;
              if (isNaN(x))
                throw new c("\\@char has non-numeric argument " + f);
              if (x < 0 || x >= 1114111)
                throw new c("\\@char with invalid code point " + f);
              return x <= 65535 ? E = String.fromCharCode(x) : (x -= 65536, E = String.fromCharCode((x >> 10) + 55296, (x & 1023) + 56320)), {
                type: "textord",
                mode: r.mode,
                text: E
              };
            }
          });
          var ui = function(e, t) {
            var r = $e(e.body, t.withColor(e.color), !1);
            return N.makeFragment(r);
          }, ci = function(e, t) {
            var r = ft(e.body, t.withColor(e.color)), n = new Y.MathNode("mstyle", r);
            return n.setAttribute("mathcolor", e.color), n;
          };
          ne({
            type: "color",
            names: ["\\textcolor"],
            props: {
              numArgs: 2,
              allowedInText: !0,
              argTypes: ["color", "original"]
            },
            handler: function(e, t) {
              var r = e.parser, n = ye(t[0], "color-token").color, s = t[1];
              return {
                type: "color",
                mode: r.mode,
                color: n,
                body: Ze(s)
              };
            },
            htmlBuilder: ui,
            mathmlBuilder: ci
          }), ne({
            type: "color",
            names: ["\\color"],
            props: {
              numArgs: 1,
              allowedInText: !0,
              argTypes: ["color"]
            },
            handler: function(e, t) {
              var r = e.parser, n = e.breakOnTokenText, s = ye(t[0], "color-token").color;
              r.gullet.macros.set("\\current@color", s);
              var f = r.parseExpression(!0, n);
              return {
                type: "color",
                mode: r.mode,
                color: s,
                body: f
              };
            },
            htmlBuilder: ui,
            mathmlBuilder: ci
          }), ne({
            type: "cr",
            names: ["\\\\"],
            props: {
              numArgs: 0,
              numOptionalArgs: 0,
              allowedInText: !0
            },
            handler: function(e, t, r) {
              var n = e.parser, s = n.gullet.future().text === "[" ? n.parseSizeGroup(!0) : null, f = !n.settings.displayMode || !n.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
              return {
                type: "cr",
                mode: n.mode,
                newLine: f,
                size: s && ye(s, "size").value
              };
            },
            // The following builders are called only at the top level,
            // not within tabular/array environments.
            htmlBuilder: function(e, t) {
              var r = N.makeSpan(["mspace"], [], t);
              return e.newLine && (r.classes.push("newline"), e.size && (r.style.marginTop = J(Ie(e.size, t)))), r;
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mspace");
              return e.newLine && (r.setAttribute("linebreak", "newline"), e.size && r.setAttribute("height", J(Ie(e.size, t)))), r;
            }
          });
          var Hn = {
            "\\global": "\\global",
            "\\long": "\\\\globallong",
            "\\\\globallong": "\\\\globallong",
            "\\def": "\\gdef",
            "\\gdef": "\\gdef",
            "\\edef": "\\xdef",
            "\\xdef": "\\xdef",
            "\\let": "\\\\globallet",
            "\\futurelet": "\\\\globalfuture"
          }, hi = function(e) {
            var t = e.text;
            if (/^(?:[\\{}$&#^_]|EOF)$/.test(t))
              throw new c("Expected a control sequence", e);
            return t;
          }, Vo = function(e) {
            var t = e.gullet.popToken();
            return t.text === "=" && (t = e.gullet.popToken(), t.text === " " && (t = e.gullet.popToken())), t;
          }, fi = function(e, t, r, n) {
            var s = e.gullet.macros.get(r.text);
            s == null && (r.noexpand = !0, s = {
              tokens: [r],
              numArgs: 0,
              // reproduce the same behavior in expansion
              unexpandable: !e.gullet.isExpandable(r.text)
            }), e.gullet.macros.set(t, s, n);
          };
          ne({
            type: "internal",
            names: [
              "\\global",
              "\\long",
              "\\\\globallong"
              // can’t be entered directly
            ],
            props: {
              numArgs: 0,
              allowedInText: !0
            },
            handler: function(e) {
              var t = e.parser, r = e.funcName;
              t.consumeSpaces();
              var n = t.fetch();
              if (Hn[n.text])
                return (r === "\\global" || r === "\\\\globallong") && (n.text = Hn[n.text]), ye(t.parseFunction(), "internal");
              throw new c("Invalid token after macro prefix", n);
            }
          }), ne({
            type: "internal",
            names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
            props: {
              numArgs: 0,
              allowedInText: !0,
              primitive: !0
            },
            handler: function(e) {
              var t = e.parser, r = e.funcName, n = t.gullet.popToken(), s = n.text;
              if (/^(?:[\\{}$&#^_]|EOF)$/.test(s))
                throw new c("Expected a control sequence", n);
              for (var f = 0, g, w = [[]]; t.gullet.future().text !== "{"; )
                if (n = t.gullet.popToken(), n.text === "#") {
                  if (t.gullet.future().text === "{") {
                    g = t.gullet.future(), w[f].push("{");
                    break;
                  }
                  if (n = t.gullet.popToken(), !/^[1-9]$/.test(n.text))
                    throw new c('Invalid argument number "' + n.text + '"');
                  if (parseInt(n.text) !== f + 1)
                    throw new c('Argument number "' + n.text + '" out of order');
                  f++, w.push([]);
                } else {
                  if (n.text === "EOF")
                    throw new c("Expected a macro definition");
                  w[f].push(n.text);
                }
              var x = t.gullet.consumeArg(), E = x.tokens;
              return g && E.unshift(g), (r === "\\edef" || r === "\\xdef") && (E = t.gullet.expandTokens(E), E.reverse()), t.gullet.macros.set(s, {
                tokens: E,
                numArgs: f,
                delimiters: w
              }, r === Hn[r]), {
                type: "internal",
                mode: t.mode
              };
            }
          }), ne({
            type: "internal",
            names: [
              "\\let",
              "\\\\globallet"
              // can’t be entered directly
            ],
            props: {
              numArgs: 0,
              allowedInText: !0,
              primitive: !0
            },
            handler: function(e) {
              var t = e.parser, r = e.funcName, n = hi(t.gullet.popToken());
              t.gullet.consumeSpaces();
              var s = Vo(t);
              return fi(t, n, s, r === "\\\\globallet"), {
                type: "internal",
                mode: t.mode
              };
            }
          }), ne({
            type: "internal",
            names: [
              "\\futurelet",
              "\\\\globalfuture"
              // can’t be entered directly
            ],
            props: {
              numArgs: 0,
              allowedInText: !0,
              primitive: !0
            },
            handler: function(e) {
              var t = e.parser, r = e.funcName, n = hi(t.gullet.popToken()), s = t.gullet.popToken(), f = t.gullet.popToken();
              return fi(t, n, f, r === "\\\\globalfuture"), t.gullet.pushToken(f), t.gullet.pushToken(s), {
                type: "internal",
                mode: t.mode
              };
            }
          });
          var vr = function(e, t, r) {
            var n = qe.math[e] && qe.math[e].replace, s = qt(n || e, t, r);
            if (!s)
              throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
            return s;
          }, Un = function(e, t, r, n) {
            var s = r.havingBaseStyle(t), f = N.makeSpan(n.concat(s.sizingClasses(r)), [e], r), g = s.sizeMultiplier / r.sizeMultiplier;
            return f.height *= g, f.depth *= g, f.maxFontSize = s.sizeMultiplier, f;
          }, mi = function(e, t, r) {
            var n = t.havingBaseStyle(r), s = (1 - t.sizeMultiplier / n.sizeMultiplier) * t.fontMetrics().axisHeight;
            e.classes.push("delimcenter"), e.style.top = J(s), e.height -= s, e.depth += s;
          }, Wo = function(e, t, r, n, s, f) {
            var g = N.makeSymbol(e, "Main-Regular", s, n), w = Un(g, t, n, f);
            return r && mi(w, n, t), w;
          }, Yo = function(e, t, r, n) {
            return N.makeSymbol(e, "Size" + t + "-Regular", r, n);
          }, di = function(e, t, r, n, s, f) {
            var g = Yo(e, t, s, n), w = Un(N.makeSpan(["delimsizing", "size" + t], [g], n), K.TEXT, n, f);
            return r && mi(w, n, K.TEXT), w;
          }, Gn = function(e, t, r) {
            var n;
            t === "Size1-Regular" ? n = "delim-size1" : n = "delim-size4";
            var s = N.makeSpan(["delimsizinginner", n], [N.makeSpan([], [N.makeSymbol(e, t, r)])]);
            return {
              type: "elem",
              elem: s
            };
          }, Vn = function(e, t, r) {
            var n = xt["Size4-Regular"][e.charCodeAt(0)] ? xt["Size4-Regular"][e.charCodeAt(0)][4] : xt["Size1-Regular"][e.charCodeAt(0)][4], s = new Pt("inner", G0(e, Math.round(1e3 * t))), f = new At([s], {
              width: J(n),
              height: J(t),
              // Override CSS rule `.katex svg { width: 100% }`
              style: "width:" + J(n),
              viewBox: "0 0 " + 1e3 * n + " " + Math.round(1e3 * t),
              preserveAspectRatio: "xMinYMin"
            }), g = N.makeSvgSpan([], [f], r);
            return g.height = t, g.style.height = J(t), g.style.width = J(n), {
              type: "elem",
              elem: g
            };
          }, Wn = 8e-3, Kr = {
            type: "kern",
            size: -1 * Wn
          }, Xo = ["|", "\\lvert", "\\rvert", "\\vert"], jo = ["\\|", "\\lVert", "\\rVert", "\\Vert"], pi = function(e, t, r, n, s, f) {
            var g, w, x, E, z = "", q = 0;
            g = x = E = e, w = null;
            var O = "Size1-Regular";
            e === "\\uparrow" ? x = E = "⏐" : e === "\\Uparrow" ? x = E = "‖" : e === "\\downarrow" ? g = x = "⏐" : e === "\\Downarrow" ? g = x = "‖" : e === "\\updownarrow" ? (g = "\\uparrow", x = "⏐", E = "\\downarrow") : e === "\\Updownarrow" ? (g = "\\Uparrow", x = "‖", E = "\\Downarrow") : L.contains(Xo, e) ? (x = "∣", z = "vert", q = 333) : L.contains(jo, e) ? (x = "∥", z = "doublevert", q = 556) : e === "[" || e === "\\lbrack" ? (g = "⎡", x = "⎢", E = "⎣", O = "Size4-Regular", z = "lbrack", q = 667) : e === "]" || e === "\\rbrack" ? (g = "⎤", x = "⎥", E = "⎦", O = "Size4-Regular", z = "rbrack", q = 667) : e === "\\lfloor" || e === "⌊" ? (x = g = "⎢", E = "⎣", O = "Size4-Regular", z = "lfloor", q = 667) : e === "\\lceil" || e === "⌈" ? (g = "⎡", x = E = "⎢", O = "Size4-Regular", z = "lceil", q = 667) : e === "\\rfloor" || e === "⌋" ? (x = g = "⎥", E = "⎦", O = "Size4-Regular", z = "rfloor", q = 667) : e === "\\rceil" || e === "⌉" ? (g = "⎤", x = E = "⎥", O = "Size4-Regular", z = "rceil", q = 667) : e === "(" || e === "\\lparen" ? (g = "⎛", x = "⎜", E = "⎝", O = "Size4-Regular", z = "lparen", q = 875) : e === ")" || e === "\\rparen" ? (g = "⎞", x = "⎟", E = "⎠", O = "Size4-Regular", z = "rparen", q = 875) : e === "\\{" || e === "\\lbrace" ? (g = "⎧", w = "⎨", E = "⎩", x = "⎪", O = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (g = "⎫", w = "⎬", E = "⎭", x = "⎪", O = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (g = "⎧", E = "⎩", x = "⎪", O = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (g = "⎫", E = "⎭", x = "⎪", O = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (g = "⎧", E = "⎭", x = "⎪", O = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (g = "⎫", E = "⎩", x = "⎪", O = "Size4-Regular");
            var U = vr(g, O, s), Q = U.height + U.depth, ee = vr(x, O, s), ce = ee.height + ee.depth, me = vr(E, O, s), pe = me.height + me.depth, Ce = 0, we = 1;
            if (w !== null) {
              var Me = vr(w, O, s);
              Ce = Me.height + Me.depth, we = 2;
            }
            var Fe = Q + pe + Ce, ze = Math.max(0, Math.ceil((t - Fe) / (we * ce))), He = Fe + ze * we * ce, rt = n.fontMetrics().axisHeight;
            r && (rt *= n.sizeMultiplier);
            var dt = He / 2 - rt, Ve = [];
            if (z.length > 0) {
              var q0 = He - Q - pe, Ft = Math.round(He * 1e3), st = Br(z, Math.round(q0 * 1e3)), b0 = new Pt(z, st), K0 = (q / 1e3).toFixed(3) + "em", Q0 = (Ft / 1e3).toFixed(3) + "em", ca = new At([b0], {
                width: K0,
                height: Q0,
                viewBox: "0 0 " + q + " " + Ft
              }), y0 = N.makeSvgSpan([], [ca], n);
              y0.height = Ft / 1e3, y0.style.width = K0, y0.style.height = Q0, Ve.push({
                type: "elem",
                elem: y0
              });
            } else {
              if (Ve.push(Gn(E, O, s)), Ve.push(Kr), w === null) {
                var w0 = He - Q - pe + 2 * Wn;
                Ve.push(Vn(x, w0, n));
              } else {
                var Et = (He - Q - pe - Ce) / 2 + 2 * Wn;
                Ve.push(Vn(x, Et, n)), Ve.push(Kr), Ve.push(Gn(w, O, s)), Ve.push(Kr), Ve.push(Vn(x, Et, n));
              }
              Ve.push(Kr), Ve.push(Gn(g, O, s));
            }
            var wr = n.havingBaseStyle(K.TEXT), ha = N.makeVList({
              positionType: "bottom",
              positionData: dt,
              children: Ve
            }, wr);
            return Un(N.makeSpan(["delimsizing", "mult"], [ha], wr), K.TEXT, n, f);
          }, Yn = 80, Xn = 0.08, jn = function(e, t, r, n, s) {
            var f = i0(e, n, r), g = new Pt(e, f), w = new At([g], {
              // Note: 1000:1 ratio of viewBox to document em width.
              width: "400em",
              height: J(t),
              viewBox: "0 0 400000 " + r,
              preserveAspectRatio: "xMinYMin slice"
            });
            return N.makeSvgSpan(["hide-tail"], [w], s);
          }, Zo = function(e, t) {
            var r = t.havingBaseSizing(), n = yi("\\surd", e * r.sizeMultiplier, bi, r), s = r.sizeMultiplier, f = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), g, w = 0, x = 0, E = 0, z;
            return n.type === "small" ? (E = 1e3 + 1e3 * f + Yn, e < 1 ? s = 1 : e < 1.4 && (s = 0.7), w = (1 + f + Xn) / s, x = (1 + f) / s, g = jn("sqrtMain", w, E, f, t), g.style.minWidth = "0.853em", z = 0.833 / s) : n.type === "large" ? (E = (1e3 + Yn) * br[n.size], x = (br[n.size] + f) / s, w = (br[n.size] + f + Xn) / s, g = jn("sqrtSize" + n.size, w, E, f, t), g.style.minWidth = "1.02em", z = 1 / s) : (w = e + f + Xn, x = e + f, E = Math.floor(1e3 * e + f) + Yn, g = jn("sqrtTall", w, E, f, t), g.style.minWidth = "0.742em", z = 1.056), g.height = x, g.style.height = J(w), {
              span: g,
              advanceWidth: z,
              // Calculate the actual line width.
              // This actually should depend on the chosen font -- e.g. \boldmath
              // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
              // have thicker rules.
              ruleWidth: (t.fontMetrics().sqrtRuleThickness + f) * s
            };
          }, gi = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"], Ko = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"], vi = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"], br = [0, 1.2, 1.8, 2.4, 3], Qo = function(e, t, r, n, s) {
            if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), L.contains(gi, e) || L.contains(vi, e))
              return di(e, t, !1, r, n, s);
            if (L.contains(Ko, e))
              return pi(e, br[t], !1, r, n, s);
            throw new c("Illegal delimiter: '" + e + "'");
          }, Jo = [{
            type: "small",
            style: K.SCRIPTSCRIPT
          }, {
            type: "small",
            style: K.SCRIPT
          }, {
            type: "small",
            style: K.TEXT
          }, {
            type: "large",
            size: 1
          }, {
            type: "large",
            size: 2
          }, {
            type: "large",
            size: 3
          }, {
            type: "large",
            size: 4
          }], $o = [{
            type: "small",
            style: K.SCRIPTSCRIPT
          }, {
            type: "small",
            style: K.SCRIPT
          }, {
            type: "small",
            style: K.TEXT
          }, {
            type: "stack"
          }], bi = [{
            type: "small",
            style: K.SCRIPTSCRIPT
          }, {
            type: "small",
            style: K.SCRIPT
          }, {
            type: "small",
            style: K.TEXT
          }, {
            type: "large",
            size: 1
          }, {
            type: "large",
            size: 2
          }, {
            type: "large",
            size: 3
          }, {
            type: "large",
            size: 4
          }, {
            type: "stack"
          }], eu = function(e) {
            if (e.type === "small")
              return "Main-Regular";
            if (e.type === "large")
              return "Size" + e.size + "-Regular";
            if (e.type === "stack")
              return "Size4-Regular";
            throw new Error("Add support for delim type '" + e.type + "' here.");
          }, yi = function(e, t, r, n) {
            for (var s = Math.min(2, 3 - n.style.size), f = s; f < r.length && r[f].type !== "stack"; f++) {
              var g = vr(e, eu(r[f]), "math"), w = g.height + g.depth;
              if (r[f].type === "small") {
                var x = n.havingBaseStyle(r[f].style);
                w *= x.sizeMultiplier;
              }
              if (w > t)
                return r[f];
            }
            return r[r.length - 1];
          }, wi = function(e, t, r, n, s, f) {
            e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
            var g;
            L.contains(vi, e) ? g = Jo : L.contains(gi, e) ? g = bi : g = $o;
            var w = yi(e, t, g, n);
            return w.type === "small" ? Wo(e, w.style, r, n, s, f) : w.type === "large" ? di(e, w.size, r, n, s, f) : pi(e, t, r, n, s, f);
          }, tu = function(e, t, r, n, s, f) {
            var g = n.fontMetrics().axisHeight * n.sizeMultiplier, w = 901, x = 5 / n.fontMetrics().ptPerEm, E = Math.max(t - g, r + g), z = Math.max(
              // In real TeX, calculations are done using integral values which are
              // 65536 per pt, or 655360 per em. So, the division here truncates in
              // TeX but doesn't here, producing different results. If we wanted to
              // exactly match TeX's calculation, we could do
              //   Math.floor(655360 * maxDistFromAxis / 500) *
              //    delimiterFactor / 655360
              // (To see the difference, compare
              //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
              // in TeX and KaTeX)
              E / 500 * w,
              2 * E - x
            );
            return wi(e, z, !0, n, s, f);
          }, r0 = {
            sqrtImage: Zo,
            sizedDelim: Qo,
            sizeToMaxHeight: br,
            customSizedDelim: wi,
            leftRightDelim: tu
          }, ki = {
            "\\bigl": {
              mclass: "mopen",
              size: 1
            },
            "\\Bigl": {
              mclass: "mopen",
              size: 2
            },
            "\\biggl": {
              mclass: "mopen",
              size: 3
            },
            "\\Biggl": {
              mclass: "mopen",
              size: 4
            },
            "\\bigr": {
              mclass: "mclose",
              size: 1
            },
            "\\Bigr": {
              mclass: "mclose",
              size: 2
            },
            "\\biggr": {
              mclass: "mclose",
              size: 3
            },
            "\\Biggr": {
              mclass: "mclose",
              size: 4
            },
            "\\bigm": {
              mclass: "mrel",
              size: 1
            },
            "\\Bigm": {
              mclass: "mrel",
              size: 2
            },
            "\\biggm": {
              mclass: "mrel",
              size: 3
            },
            "\\Biggm": {
              mclass: "mrel",
              size: 4
            },
            "\\big": {
              mclass: "mord",
              size: 1
            },
            "\\Big": {
              mclass: "mord",
              size: 2
            },
            "\\bigg": {
              mclass: "mord",
              size: 3
            },
            "\\Bigg": {
              mclass: "mord",
              size: 4
            }
          }, ru = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
          function Qr(h, e) {
            var t = Xr(h);
            if (t && L.contains(ru, t.text))
              return t;
            throw t ? new c("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", h) : new c("Invalid delimiter type '" + h.type + "'", h);
          }
          ne({
            type: "delimsizing",
            names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
            props: {
              numArgs: 1,
              argTypes: ["primitive"]
            },
            handler: function(e, t) {
              var r = Qr(t[0], e);
              return {
                type: "delimsizing",
                mode: e.parser.mode,
                size: ki[e.funcName].size,
                mclass: ki[e.funcName].mclass,
                delim: r.text
              };
            },
            htmlBuilder: function(e, t) {
              return e.delim === "." ? N.makeSpan([e.mclass]) : r0.sizedDelim(e.delim, e.size, t, e.mode, [e.mclass]);
            },
            mathmlBuilder: function(e) {
              var t = [];
              e.delim !== "." && t.push(St(e.delim, e.mode));
              var r = new Y.MathNode("mo", t);
              e.mclass === "mopen" || e.mclass === "mclose" ? r.setAttribute("fence", "true") : r.setAttribute("fence", "false"), r.setAttribute("stretchy", "true");
              var n = J(r0.sizeToMaxHeight[e.size]);
              return r.setAttribute("minsize", n), r.setAttribute("maxsize", n), r;
            }
          });
          function xi(h) {
            if (!h.body)
              throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
          }
          ne({
            type: "leftright-right",
            names: ["\\right"],
            props: {
              numArgs: 1,
              primitive: !0
            },
            handler: function(e, t) {
              var r = e.parser.gullet.macros.get("\\current@color");
              if (r && typeof r != "string")
                throw new c("\\current@color set to non-string in \\right");
              return {
                type: "leftright-right",
                mode: e.parser.mode,
                delim: Qr(t[0], e).text,
                color: r
                // undefined if not set via \color
              };
            }
          }), ne({
            type: "leftright",
            names: ["\\left"],
            props: {
              numArgs: 1,
              primitive: !0
            },
            handler: function(e, t) {
              var r = Qr(t[0], e), n = e.parser;
              ++n.leftrightDepth;
              var s = n.parseExpression(!1);
              --n.leftrightDepth, n.expect("\\right", !1);
              var f = ye(n.parseFunction(), "leftright-right");
              return {
                type: "leftright",
                mode: n.mode,
                body: s,
                left: r.text,
                right: f.delim,
                rightColor: f.color
              };
            },
            htmlBuilder: function(e, t) {
              xi(e);
              for (var r = $e(e.body, t, !0, ["mopen", "mclose"]), n = 0, s = 0, f = !1, g = 0; g < r.length; g++)
                r[g].isMiddle ? f = !0 : (n = Math.max(r[g].height, n), s = Math.max(r[g].depth, s));
              n *= t.sizeMultiplier, s *= t.sizeMultiplier;
              var w;
              if (e.left === "." ? w = pr(t, ["mopen"]) : w = r0.leftRightDelim(e.left, n, s, t, e.mode, ["mopen"]), r.unshift(w), f)
                for (var x = 1; x < r.length; x++) {
                  var E = r[x], z = E.isMiddle;
                  z && (r[x] = r0.leftRightDelim(z.delim, n, s, z.options, e.mode, []));
                }
              var q;
              if (e.right === ".")
                q = pr(t, ["mclose"]);
              else {
                var O = e.rightColor ? t.withColor(e.rightColor) : t;
                q = r0.leftRightDelim(e.right, n, s, O, e.mode, ["mclose"]);
              }
              return r.push(q), N.makeSpan(["minner"], r, t);
            },
            mathmlBuilder: function(e, t) {
              xi(e);
              var r = ft(e.body, t);
              if (e.left !== ".") {
                var n = new Y.MathNode("mo", [St(e.left, e.mode)]);
                n.setAttribute("fence", "true"), r.unshift(n);
              }
              if (e.right !== ".") {
                var s = new Y.MathNode("mo", [St(e.right, e.mode)]);
                s.setAttribute("fence", "true"), e.rightColor && s.setAttribute("mathcolor", e.rightColor), r.push(s);
              }
              return Ln(r);
            }
          }), ne({
            type: "middle",
            names: ["\\middle"],
            props: {
              numArgs: 1,
              primitive: !0
            },
            handler: function(e, t) {
              var r = Qr(t[0], e);
              if (!e.parser.leftrightDepth)
                throw new c("\\middle without preceding \\left", r);
              return {
                type: "middle",
                mode: e.parser.mode,
                delim: r.text
              };
            },
            htmlBuilder: function(e, t) {
              var r;
              if (e.delim === ".")
                r = pr(t, []);
              else {
                r = r0.sizedDelim(e.delim, 1, t, e.mode, []);
                var n = {
                  delim: e.delim,
                  options: t
                };
                r.isMiddle = n;
              }
              return r;
            },
            mathmlBuilder: function(e, t) {
              var r = e.delim === "\\vert" || e.delim === "|" ? St("|", "text") : St(e.delim, e.mode), n = new Y.MathNode("mo", [r]);
              return n.setAttribute("fence", "true"), n.setAttribute("lspace", "0.05em"), n.setAttribute("rspace", "0.05em"), n;
            }
          });
          var Zn = function(e, t) {
            var r = N.wrapFragment(Se(e.body, t), t), n = e.label.slice(1), s = t.sizeMultiplier, f, g = 0, w = L.isCharacterBox(e.body);
            if (n === "sout")
              f = N.makeSpan(["stretchy", "sout"]), f.height = t.fontMetrics().defaultRuleThickness / s, g = -0.5 * t.fontMetrics().xHeight;
            else if (n === "phase") {
              var x = Ie({
                number: 0.6,
                unit: "pt"
              }, t), E = Ie({
                number: 0.35,
                unit: "ex"
              }, t), z = t.havingBaseSizing();
              s = s / z.sizeMultiplier;
              var q = r.height + r.depth + x + E;
              r.style.paddingLeft = J(q / 2 + x);
              var O = Math.floor(1e3 * q * s), U = M0(O), Q = new At([new Pt("phase", U)], {
                width: "400em",
                height: J(O / 1e3),
                viewBox: "0 0 400000 " + O,
                preserveAspectRatio: "xMinYMin slice"
              });
              f = N.makeSvgSpan(["hide-tail"], [Q], t), f.style.height = J(q), g = r.depth + x + E;
            } else {
              /cancel/.test(n) ? w || r.classes.push("cancel-pad") : n === "angl" ? r.classes.push("anglpad") : r.classes.push("boxpad");
              var ee = 0, ce = 0, me = 0;
              /box/.test(n) ? (me = Math.max(
                t.fontMetrics().fboxrule,
                // default
                t.minRuleThickness
                // User override.
              ), ee = t.fontMetrics().fboxsep + (n === "colorbox" ? 0 : me), ce = ee) : n === "angl" ? (me = Math.max(t.fontMetrics().defaultRuleThickness, t.minRuleThickness), ee = 4 * me, ce = Math.max(0, 0.25 - r.depth)) : (ee = w ? 0.2 : 0, ce = ee), f = t0.encloseSpan(r, n, ee, ce, t), /fbox|boxed|fcolorbox/.test(n) ? (f.style.borderStyle = "solid", f.style.borderWidth = J(me)) : n === "angl" && me !== 0.049 && (f.style.borderTopWidth = J(me), f.style.borderRightWidth = J(me)), g = r.depth + ce, e.backgroundColor && (f.style.backgroundColor = e.backgroundColor, e.borderColor && (f.style.borderColor = e.borderColor));
            }
            var pe;
            if (e.backgroundColor)
              pe = N.makeVList({
                positionType: "individualShift",
                children: [
                  // Put the color background behind inner;
                  {
                    type: "elem",
                    elem: f,
                    shift: g
                  },
                  {
                    type: "elem",
                    elem: r,
                    shift: 0
                  }
                ]
              }, t);
            else {
              var Ce = /cancel|phase/.test(n) ? ["svg-align"] : [];
              pe = N.makeVList({
                positionType: "individualShift",
                children: [
                  // Write the \cancel stroke on top of inner.
                  {
                    type: "elem",
                    elem: r,
                    shift: 0
                  },
                  {
                    type: "elem",
                    elem: f,
                    shift: g,
                    wrapperClasses: Ce
                  }
                ]
              }, t);
            }
            return /cancel/.test(n) && (pe.height = r.height, pe.depth = r.depth), /cancel/.test(n) && !w ? N.makeSpan(["mord", "cancel-lap"], [pe], t) : N.makeSpan(["mord"], [pe], t);
          }, Kn = function(e, t) {
            var r = 0, n = new Y.MathNode(e.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [Oe(e.body, t)]);
            switch (e.label) {
              case "\\cancel":
                n.setAttribute("notation", "updiagonalstrike");
                break;
              case "\\bcancel":
                n.setAttribute("notation", "downdiagonalstrike");
                break;
              case "\\phase":
                n.setAttribute("notation", "phasorangle");
                break;
              case "\\sout":
                n.setAttribute("notation", "horizontalstrike");
                break;
              case "\\fbox":
                n.setAttribute("notation", "box");
                break;
              case "\\angl":
                n.setAttribute("notation", "actuarial");
                break;
              case "\\fcolorbox":
              case "\\colorbox":
                if (r = t.fontMetrics().fboxsep * t.fontMetrics().ptPerEm, n.setAttribute("width", "+" + 2 * r + "pt"), n.setAttribute("height", "+" + 2 * r + "pt"), n.setAttribute("lspace", r + "pt"), n.setAttribute("voffset", r + "pt"), e.label === "\\fcolorbox") {
                  var s = Math.max(
                    t.fontMetrics().fboxrule,
                    // default
                    t.minRuleThickness
                    // user override
                  );
                  n.setAttribute("style", "border: " + s + "em solid " + String(e.borderColor));
                }
                break;
              case "\\xcancel":
                n.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
                break;
            }
            return e.backgroundColor && n.setAttribute("mathbackground", e.backgroundColor), n;
          };
          ne({
            type: "enclose",
            names: ["\\colorbox"],
            props: {
              numArgs: 2,
              allowedInText: !0,
              argTypes: ["color", "text"]
            },
            handler: function(e, t, r) {
              var n = e.parser, s = e.funcName, f = ye(t[0], "color-token").color, g = t[1];
              return {
                type: "enclose",
                mode: n.mode,
                label: s,
                backgroundColor: f,
                body: g
              };
            },
            htmlBuilder: Zn,
            mathmlBuilder: Kn
          }), ne({
            type: "enclose",
            names: ["\\fcolorbox"],
            props: {
              numArgs: 3,
              allowedInText: !0,
              argTypes: ["color", "color", "text"]
            },
            handler: function(e, t, r) {
              var n = e.parser, s = e.funcName, f = ye(t[0], "color-token").color, g = ye(t[1], "color-token").color, w = t[2];
              return {
                type: "enclose",
                mode: n.mode,
                label: s,
                backgroundColor: g,
                borderColor: f,
                body: w
              };
            },
            htmlBuilder: Zn,
            mathmlBuilder: Kn
          }), ne({
            type: "enclose",
            names: ["\\fbox"],
            props: {
              numArgs: 1,
              argTypes: ["hbox"],
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser;
              return {
                type: "enclose",
                mode: r.mode,
                label: "\\fbox",
                body: t[0]
              };
            }
          }), ne({
            type: "enclose",
            names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = t[0];
              return {
                type: "enclose",
                mode: r.mode,
                label: n,
                body: s
              };
            },
            htmlBuilder: Zn,
            mathmlBuilder: Kn
          }), ne({
            type: "enclose",
            names: ["\\angl"],
            props: {
              numArgs: 1,
              argTypes: ["hbox"],
              allowedInText: !1
            },
            handler: function(e, t) {
              var r = e.parser;
              return {
                type: "enclose",
                mode: r.mode,
                label: "\\angl",
                body: t[0]
              };
            }
          });
          var Di = {};
          function Ut(h) {
            for (var e = h.type, t = h.names, r = h.props, n = h.handler, s = h.htmlBuilder, f = h.mathmlBuilder, g = {
              type: e,
              numArgs: r.numArgs || 0,
              allowedInText: !1,
              numOptionalArgs: 0,
              handler: n
            }, w = 0; w < t.length; ++w)
              Di[t[w]] = g;
            s && (Gr[e] = s), f && (Vr[e] = f);
          }
          var Ai = {};
          function k(h, e) {
            Ai[h] = e;
          }
          var Nt = /* @__PURE__ */ function() {
            function h(e, t, r) {
              this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = r;
            }
            return h.range = function(t, r) {
              return r ? !t || !t.loc || !r.loc || t.loc.lexer !== r.loc.lexer ? null : new h(t.loc.lexer, t.loc.start, r.loc.end) : t && t.loc;
            }, h;
          }(), p0 = /* @__PURE__ */ function() {
            function h(t, r) {
              this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = t, this.loc = r;
            }
            var e = h.prototype;
            return e.range = function(r, n) {
              return new h(n, Nt.range(this, r));
            }, h;
          }();
          function _i(h) {
            var e = [];
            h.consumeSpaces();
            var t = h.fetch().text;
            for (t === "\\relax" && (h.consume(), h.consumeSpaces(), t = h.fetch().text); t === "\\hline" || t === "\\hdashline"; )
              h.consume(), e.push(t === "\\hdashline"), h.consumeSpaces(), t = h.fetch().text;
            return e;
          }
          var Jr = function(e) {
            var t = e.parser.settings;
            if (!t.displayMode)
              throw new c("{" + e.envName + "} can be used only in display mode.");
          };
          function Qn(h) {
            if (h.indexOf("ed") === -1)
              return h.indexOf("*") === -1;
          }
          function g0(h, e, t) {
            var r = e.hskipBeforeAndAfter, n = e.addJot, s = e.cols, f = e.arraystretch, g = e.colSeparationType, w = e.autoTag, x = e.singleRow, E = e.emptySingleRow, z = e.maxNumCols, q = e.leqno;
            if (h.gullet.beginGroup(), x || h.gullet.macros.set("\\cr", "\\\\\\relax"), !f) {
              var O = h.gullet.expandMacroAsText("\\arraystretch");
              if (O == null)
                f = 1;
              else if (f = parseFloat(O), !f || f < 0)
                throw new c("Invalid \\arraystretch: " + O);
            }
            h.gullet.beginGroup();
            var U = [], Q = [U], ee = [], ce = [], me = w != null ? [] : void 0;
            function pe() {
              w && h.gullet.macros.set("\\@eqnsw", "1", !0);
            }
            function Ce() {
              me && (h.gullet.macros.get("\\df@tag") ? (me.push(h.subparse([new p0("\\df@tag")])), h.gullet.macros.set("\\df@tag", void 0, !0)) : me.push(!!w && h.gullet.macros.get("\\@eqnsw") === "1"));
            }
            for (pe(), ce.push(_i(h)); ; ) {
              var we = h.parseExpression(!1, x ? "\\end" : "\\\\");
              h.gullet.endGroup(), h.gullet.beginGroup(), we = {
                type: "ordgroup",
                mode: h.mode,
                body: we
              }, t && (we = {
                type: "styling",
                mode: h.mode,
                style: t,
                body: [we]
              }), U.push(we);
              var Me = h.fetch().text;
              if (Me === "&") {
                if (z && U.length === z) {
                  if (x || g)
                    throw new c("Too many tab characters: &", h.nextToken);
                  h.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
                }
                h.consume();
              } else if (Me === "\\end") {
                Ce(), U.length === 1 && we.type === "styling" && we.body[0].body.length === 0 && (Q.length > 1 || !E) && Q.pop(), ce.length < Q.length + 1 && ce.push([]);
                break;
              } else if (Me === "\\\\") {
                h.consume();
                var Fe = void 0;
                h.gullet.future().text !== " " && (Fe = h.parseSizeGroup(!0)), ee.push(Fe ? Fe.value : null), Ce(), ce.push(_i(h)), U = [], Q.push(U), pe();
              } else
                throw new c("Expected & or \\\\ or \\cr or \\end", h.nextToken);
            }
            return h.gullet.endGroup(), h.gullet.endGroup(), {
              type: "array",
              mode: h.mode,
              addJot: n,
              arraystretch: f,
              body: Q,
              cols: s,
              rowGaps: ee,
              hskipBeforeAndAfter: r,
              hLinesBeforeRow: ce,
              colSeparationType: g,
              tags: me,
              leqno: q
            };
          }
          function Jn(h) {
            return h.slice(0, 1) === "d" ? "display" : "text";
          }
          var Gt = function(e, t) {
            var r, n, s = e.body.length, f = e.hLinesBeforeRow, g = 0, w = new Array(s), x = [], E = Math.max(
              // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
              t.fontMetrics().arrayRuleWidth,
              t.minRuleThickness
              // User override.
            ), z = 1 / t.fontMetrics().ptPerEm, q = 5 * z;
            if (e.colSeparationType && e.colSeparationType === "small") {
              var O = t.havingStyle(K.SCRIPT).sizeMultiplier;
              q = 0.2778 * (O / t.sizeMultiplier);
            }
            var U = e.colSeparationType === "CD" ? Ie({
              number: 3,
              unit: "ex"
            }, t) : 12 * z, Q = 3 * z, ee = e.arraystretch * U, ce = 0.7 * ee, me = 0.3 * ee, pe = 0;
            function Ce(rn) {
              for (var nn = 0; nn < rn.length; ++nn)
                nn > 0 && (pe += 0.25), x.push({
                  pos: pe,
                  isDashed: rn[nn]
                });
            }
            for (Ce(f[0]), r = 0; r < e.body.length; ++r) {
              var we = e.body[r], Me = ce, Fe = me;
              g < we.length && (g = we.length);
              var ze = new Array(we.length);
              for (n = 0; n < we.length; ++n) {
                var He = Se(we[n], t);
                Fe < He.depth && (Fe = He.depth), Me < He.height && (Me = He.height), ze[n] = He;
              }
              var rt = e.rowGaps[r], dt = 0;
              rt && (dt = Ie(rt, t), dt > 0 && (dt += me, Fe < dt && (Fe = dt), dt = 0)), e.addJot && (Fe += Q), ze.height = Me, ze.depth = Fe, pe += Me, ze.pos = pe, pe += Fe + dt, w[r] = ze, Ce(f[r + 1]);
            }
            var Ve = pe / 2 + t.fontMetrics().axisHeight, q0 = e.cols || [], Ft = [], st, b0, K0 = [];
            if (e.tags && e.tags.some(function(rn) {
              return rn;
            }))
              for (r = 0; r < s; ++r) {
                var Q0 = w[r], ca = Q0.pos - Ve, y0 = e.tags[r], w0 = void 0;
                y0 === !0 ? w0 = N.makeSpan(["eqn-num"], [], t) : y0 === !1 ? w0 = N.makeSpan([], [], t) : w0 = N.makeSpan([], $e(y0, t, !0), t), w0.depth = Q0.depth, w0.height = Q0.height, K0.push({
                  type: "elem",
                  elem: w0,
                  shift: ca
                });
              }
            for (
              n = 0, b0 = 0;
              // Continue while either there are more columns or more column
              // descriptions, so trailing separators don't get lost.
              n < g || b0 < q0.length;
              ++n, ++b0
            ) {
              for (var Et = q0[b0] || {}, wr = !0; Et.type === "separator"; ) {
                if (wr || (st = N.makeSpan(["arraycolsep"], []), st.style.width = J(t.fontMetrics().doubleRuleSep), Ft.push(st)), Et.separator === "|" || Et.separator === ":") {
                  var ha = Et.separator === "|" ? "solid" : "dashed", J0 = N.makeSpan(["vertical-separator"], [], t);
                  J0.style.height = J(pe), J0.style.borderRightWidth = J(E), J0.style.borderRightStyle = ha, J0.style.margin = "0 " + J(-E / 2);
                  var ll = pe - Ve;
                  ll && (J0.style.verticalAlign = J(-ll)), Ft.push(J0);
                } else
                  throw new c("Invalid separator type: " + Et.separator);
                b0++, Et = q0[b0] || {}, wr = !1;
              }
              if (!(n >= g)) {
                var $0 = void 0;
                (n > 0 || e.hskipBeforeAndAfter) && ($0 = L.deflt(Et.pregap, q), $0 !== 0 && (st = N.makeSpan(["arraycolsep"], []), st.style.width = J($0), Ft.push(st)));
                var er = [];
                for (r = 0; r < s; ++r) {
                  var en = w[r], tn = en[n];
                  if (tn) {
                    var Cu = en.pos - Ve;
                    tn.depth = en.depth, tn.height = en.height, er.push({
                      type: "elem",
                      elem: tn,
                      shift: Cu
                    });
                  }
                }
                er = N.makeVList({
                  positionType: "individualShift",
                  children: er
                }, t), er = N.makeSpan(["col-align-" + (Et.align || "c")], [er]), Ft.push(er), (n < g - 1 || e.hskipBeforeAndAfter) && ($0 = L.deflt(Et.postgap, q), $0 !== 0 && (st = N.makeSpan(["arraycolsep"], []), st.style.width = J($0), Ft.push(st)));
              }
            }
            if (w = N.makeSpan(["mtable"], Ft), x.length > 0) {
              for (var Tu = N.makeLineSpan("hline", t, E), Bu = N.makeLineSpan("hdashline", t, E), fa = [{
                type: "elem",
                elem: w,
                shift: 0
              }]; x.length > 0; ) {
                var sl = x.pop(), ol = sl.pos - Ve;
                sl.isDashed ? fa.push({
                  type: "elem",
                  elem: Bu,
                  shift: ol
                }) : fa.push({
                  type: "elem",
                  elem: Tu,
                  shift: ol
                });
              }
              w = N.makeVList({
                positionType: "individualShift",
                children: fa
              }, t);
            }
            if (K0.length === 0)
              return N.makeSpan(["mord"], [w], t);
            var ma = N.makeVList({
              positionType: "individualShift",
              children: K0
            }, t);
            return ma = N.makeSpan(["tag"], [ma], t), N.makeFragment([w, ma]);
          }, nu = {
            c: "center ",
            l: "left ",
            r: "right "
          }, Vt = function(e, t) {
            for (var r = [], n = new Y.MathNode("mtd", [], ["mtr-glue"]), s = new Y.MathNode("mtd", [], ["mml-eqn-num"]), f = 0; f < e.body.length; f++) {
              for (var g = e.body[f], w = [], x = 0; x < g.length; x++)
                w.push(new Y.MathNode("mtd", [Oe(g[x], t)]));
              e.tags && e.tags[f] && (w.unshift(n), w.push(n), e.leqno ? w.unshift(s) : w.push(s)), r.push(new Y.MathNode("mtr", w));
            }
            var E = new Y.MathNode("mtable", r), z = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
            E.setAttribute("rowspacing", J(z));
            var q = "", O = "";
            if (e.cols && e.cols.length > 0) {
              var U = e.cols, Q = "", ee = !1, ce = 0, me = U.length;
              U[0].type === "separator" && (q += "top ", ce = 1), U[U.length - 1].type === "separator" && (q += "bottom ", me -= 1);
              for (var pe = ce; pe < me; pe++)
                U[pe].type === "align" ? (O += nu[U[pe].align], ee && (Q += "none "), ee = !0) : U[pe].type === "separator" && ee && (Q += U[pe].separator === "|" ? "solid " : "dashed ", ee = !1);
              E.setAttribute("columnalign", O.trim()), /[sd]/.test(Q) && E.setAttribute("columnlines", Q.trim());
            }
            if (e.colSeparationType === "align") {
              for (var Ce = e.cols || [], we = "", Me = 1; Me < Ce.length; Me++)
                we += Me % 2 ? "0em " : "1em ";
              E.setAttribute("columnspacing", we.trim());
            } else
              e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? E.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? E.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? E.setAttribute("columnspacing", "0.5em") : E.setAttribute("columnspacing", "1em");
            var Fe = "", ze = e.hLinesBeforeRow;
            q += ze[0].length > 0 ? "left " : "", q += ze[ze.length - 1].length > 0 ? "right " : "";
            for (var He = 1; He < ze.length - 1; He++)
              Fe += ze[He].length === 0 ? "none " : ze[He][0] ? "dashed " : "solid ";
            return /[sd]/.test(Fe) && E.setAttribute("rowlines", Fe.trim()), q !== "" && (E = new Y.MathNode("menclose", [E]), E.setAttribute("notation", q.trim())), e.arraystretch && e.arraystretch < 1 && (E = new Y.MathNode("mstyle", [E]), E.setAttribute("scriptlevel", "1")), E;
          }, Si = function(e, t) {
            e.envName.indexOf("ed") === -1 && Jr(e);
            var r = [], n = e.envName.indexOf("at") > -1 ? "alignat" : "align", s = e.envName === "split", f = g0(e.parser, {
              cols: r,
              addJot: !0,
              autoTag: s ? void 0 : Qn(e.envName),
              emptySingleRow: !0,
              colSeparationType: n,
              maxNumCols: s ? 2 : void 0,
              leqno: e.parser.settings.leqno
            }, "display"), g, w = 0, x = {
              type: "ordgroup",
              mode: e.mode,
              body: []
            };
            if (t[0] && t[0].type === "ordgroup") {
              for (var E = "", z = 0; z < t[0].body.length; z++) {
                var q = ye(t[0].body[z], "textord");
                E += q.text;
              }
              g = Number(E), w = g * 2;
            }
            var O = !w;
            f.body.forEach(function(ce) {
              for (var me = 1; me < ce.length; me += 2) {
                var pe = ye(ce[me], "styling"), Ce = ye(pe.body[0], "ordgroup");
                Ce.body.unshift(x);
              }
              if (O)
                w < ce.length && (w = ce.length);
              else {
                var we = ce.length / 2;
                if (g < we)
                  throw new c("Too many math in a row: " + ("expected " + g + ", but got " + we), ce[0]);
              }
            });
            for (var U = 0; U < w; ++U) {
              var Q = "r", ee = 0;
              U % 2 === 1 ? Q = "l" : U > 0 && O && (ee = 1), r[U] = {
                type: "align",
                align: Q,
                pregap: ee,
                postgap: 0
              };
            }
            return f.colSeparationType = O ? "align" : "alignat", f;
          };
          Ut({
            type: "array",
            names: ["array", "darray"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = Xr(t[0]), n = r ? [t[0]] : ye(t[0], "ordgroup").body, s = n.map(function(g) {
                var w = qn(g), x = w.text;
                if ("lcr".indexOf(x) !== -1)
                  return {
                    type: "align",
                    align: x
                  };
                if (x === "|")
                  return {
                    type: "separator",
                    separator: "|"
                  };
                if (x === ":")
                  return {
                    type: "separator",
                    separator: ":"
                  };
                throw new c("Unknown column alignment: " + x, g);
              }), f = {
                cols: s,
                hskipBeforeAndAfter: !0,
                // \@preamble in lttab.dtx
                maxNumCols: s.length
              };
              return g0(e.parser, f, Jn(e.envName));
            },
            htmlBuilder: Gt,
            mathmlBuilder: Vt
          }), Ut({
            type: "array",
            names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var t = {
                matrix: null,
                pmatrix: ["(", ")"],
                bmatrix: ["[", "]"],
                Bmatrix: ["\\{", "\\}"],
                vmatrix: ["|", "|"],
                Vmatrix: ["\\Vert", "\\Vert"]
              }[e.envName.replace("*", "")], r = "c", n = {
                hskipBeforeAndAfter: !1,
                cols: [{
                  type: "align",
                  align: r
                }]
              };
              if (e.envName.charAt(e.envName.length - 1) === "*") {
                var s = e.parser;
                if (s.consumeSpaces(), s.fetch().text === "[") {
                  if (s.consume(), s.consumeSpaces(), r = s.fetch().text, "lcr".indexOf(r) === -1)
                    throw new c("Expected l or c or r", s.nextToken);
                  s.consume(), s.consumeSpaces(), s.expect("]"), s.consume(), n.cols = [{
                    type: "align",
                    align: r
                  }];
                }
              }
              var f = g0(e.parser, n, Jn(e.envName)), g = Math.max.apply(Math, [0].concat(f.body.map(function(w) {
                return w.length;
              })));
              return f.cols = new Array(g).fill({
                type: "align",
                align: r
              }), t ? {
                type: "leftright",
                mode: e.mode,
                body: [f],
                left: t[0],
                right: t[1],
                rightColor: void 0
                // \right uninfluenced by \color in array
              } : f;
            },
            htmlBuilder: Gt,
            mathmlBuilder: Vt
          }), Ut({
            type: "array",
            names: ["smallmatrix"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var t = {
                arraystretch: 0.5
              }, r = g0(e.parser, t, "script");
              return r.colSeparationType = "small", r;
            },
            htmlBuilder: Gt,
            mathmlBuilder: Vt
          }), Ut({
            type: "array",
            names: ["subarray"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = Xr(t[0]), n = r ? [t[0]] : ye(t[0], "ordgroup").body, s = n.map(function(g) {
                var w = qn(g), x = w.text;
                if ("lc".indexOf(x) !== -1)
                  return {
                    type: "align",
                    align: x
                  };
                throw new c("Unknown column alignment: " + x, g);
              });
              if (s.length > 1)
                throw new c("{subarray} can contain only one column");
              var f = {
                cols: s,
                hskipBeforeAndAfter: !1,
                arraystretch: 0.5
              };
              if (f = g0(e.parser, f, "script"), f.body.length > 0 && f.body[0].length > 1)
                throw new c("{subarray} can contain only one column");
              return f;
            },
            htmlBuilder: Gt,
            mathmlBuilder: Vt
          }), Ut({
            type: "array",
            names: ["cases", "dcases", "rcases", "drcases"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var t = {
                arraystretch: 1.2,
                cols: [{
                  type: "align",
                  align: "l",
                  pregap: 0,
                  // TODO(kevinb) get the current style.
                  // For now we use the metrics for TEXT style which is what we were
                  // doing before.  Before attempting to get the current style we
                  // should look at TeX's behavior especially for \over and matrices.
                  postgap: 1
                  /* 1em quad */
                }, {
                  type: "align",
                  align: "l",
                  pregap: 0,
                  postgap: 0
                }]
              }, r = g0(e.parser, t, Jn(e.envName));
              return {
                type: "leftright",
                mode: e.mode,
                body: [r],
                left: e.envName.indexOf("r") > -1 ? "." : "\\{",
                right: e.envName.indexOf("r") > -1 ? "\\}" : ".",
                rightColor: void 0
              };
            },
            htmlBuilder: Gt,
            mathmlBuilder: Vt
          }), Ut({
            type: "array",
            names: ["align", "align*", "aligned", "split"],
            props: {
              numArgs: 0
            },
            handler: Si,
            htmlBuilder: Gt,
            mathmlBuilder: Vt
          }), Ut({
            type: "array",
            names: ["gathered", "gather", "gather*"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              L.contains(["gather", "gather*"], e.envName) && Jr(e);
              var t = {
                cols: [{
                  type: "align",
                  align: "c"
                }],
                addJot: !0,
                colSeparationType: "gather",
                autoTag: Qn(e.envName),
                emptySingleRow: !0,
                leqno: e.parser.settings.leqno
              };
              return g0(e.parser, t, "display");
            },
            htmlBuilder: Gt,
            mathmlBuilder: Vt
          }), Ut({
            type: "array",
            names: ["alignat", "alignat*", "alignedat"],
            props: {
              numArgs: 1
            },
            handler: Si,
            htmlBuilder: Gt,
            mathmlBuilder: Vt
          }), Ut({
            type: "array",
            names: ["equation", "equation*"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              Jr(e);
              var t = {
                autoTag: Qn(e.envName),
                emptySingleRow: !0,
                singleRow: !0,
                maxNumCols: 1,
                leqno: e.parser.settings.leqno
              };
              return g0(e.parser, t, "display");
            },
            htmlBuilder: Gt,
            mathmlBuilder: Vt
          }), Ut({
            type: "array",
            names: ["CD"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              return Jr(e), Go(e.parser);
            },
            htmlBuilder: Gt,
            mathmlBuilder: Vt
          }), k("\\nonumber", "\\gdef\\@eqnsw{0}"), k("\\notag", "\\nonumber"), ne({
            type: "text",
            // Doesn't matter what this is.
            names: ["\\hline", "\\hdashline"],
            props: {
              numArgs: 0,
              allowedInText: !0,
              allowedInMath: !0
            },
            handler: function(e, t) {
              throw new c(e.funcName + " valid only within array environment");
            }
          });
          var au = Di, Fi = au;
          ne({
            type: "environment",
            names: ["\\begin", "\\end"],
            props: {
              numArgs: 1,
              argTypes: ["text"]
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = t[0];
              if (s.type !== "ordgroup")
                throw new c("Invalid environment name", s);
              for (var f = "", g = 0; g < s.body.length; ++g)
                f += ye(s.body[g], "textord").text;
              if (n === "\\begin") {
                if (!Fi.hasOwnProperty(f))
                  throw new c("No such environment: " + f, s);
                var w = Fi[f], x = r.parseArguments("\\begin{" + f + "}", w), E = x.args, z = x.optArgs, q = {
                  mode: r.mode,
                  envName: f,
                  parser: r
                }, O = w.handler(q, E, z);
                r.expect("\\end", !1);
                var U = r.nextToken, Q = ye(r.parseFunction(), "environment");
                if (Q.name !== f)
                  throw new c("Mismatch: \\begin{" + f + "} matched by \\end{" + Q.name + "}", U);
                return O;
              }
              return {
                type: "environment",
                mode: r.mode,
                name: f,
                nameGroup: s
              };
            }
          });
          var Ei = function(e, t) {
            var r = e.font, n = t.withFont(r);
            return Se(e.body, n);
          }, Ci = function(e, t) {
            var r = e.font, n = t.withFont(r);
            return Oe(e.body, n);
          }, Ti = {
            "\\Bbb": "\\mathbb",
            "\\bold": "\\mathbf",
            "\\frak": "\\mathfrak",
            "\\bm": "\\boldsymbol"
          };
          ne({
            type: "font",
            names: [
              // styles, except \boldsymbol defined below
              "\\mathrm",
              "\\mathit",
              "\\mathbf",
              "\\mathnormal",
              // families
              "\\mathbb",
              "\\mathcal",
              "\\mathfrak",
              "\\mathscr",
              "\\mathsf",
              "\\mathtt",
              // aliases, except \bm defined below
              "\\Bbb",
              "\\bold",
              "\\frak"
            ],
            props: {
              numArgs: 1,
              allowedInArgument: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = Wr(t[0]), f = n;
              return f in Ti && (f = Ti[f]), {
                type: "font",
                mode: r.mode,
                font: f.slice(1),
                body: s
              };
            },
            htmlBuilder: Ei,
            mathmlBuilder: Ci
          }), ne({
            type: "mclass",
            names: ["\\boldsymbol", "\\bm"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = e.parser, n = t[0], s = L.isCharacterBox(n);
              return {
                type: "mclass",
                mode: r.mode,
                mclass: Zr(n),
                body: [{
                  type: "font",
                  mode: r.mode,
                  font: "boldsymbol",
                  body: n
                }],
                isCharacterBox: s
              };
            }
          }), ne({
            type: "font",
            names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
            props: {
              numArgs: 0,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = e.breakOnTokenText, f = r.mode, g = r.parseExpression(!0, s), w = "math" + n.slice(1);
              return {
                type: "font",
                mode: f,
                font: w,
                body: {
                  type: "ordgroup",
                  mode: r.mode,
                  body: g
                }
              };
            },
            htmlBuilder: Ei,
            mathmlBuilder: Ci
          });
          var Bi = function(e, t) {
            var r = t;
            return e === "display" ? r = r.id >= K.SCRIPT.id ? r.text() : K.DISPLAY : e === "text" && r.size === K.DISPLAY.size ? r = K.TEXT : e === "script" ? r = K.SCRIPT : e === "scriptscript" && (r = K.SCRIPTSCRIPT), r;
          }, $n = function(e, t) {
            var r = Bi(e.size, t.style), n = r.fracNum(), s = r.fracDen(), f;
            f = t.havingStyle(n);
            var g = Se(e.numer, f, t);
            if (e.continued) {
              var w = 8.5 / t.fontMetrics().ptPerEm, x = 3.5 / t.fontMetrics().ptPerEm;
              g.height = g.height < w ? w : g.height, g.depth = g.depth < x ? x : g.depth;
            }
            f = t.havingStyle(s);
            var E = Se(e.denom, f, t), z, q, O;
            e.hasBarLine ? (e.barSize ? (q = Ie(e.barSize, t), z = N.makeLineSpan("frac-line", t, q)) : z = N.makeLineSpan("frac-line", t), q = z.height, O = z.height) : (z = null, q = 0, O = t.fontMetrics().defaultRuleThickness);
            var U, Q, ee;
            r.size === K.DISPLAY.size || e.size === "display" ? (U = t.fontMetrics().num1, q > 0 ? Q = 3 * O : Q = 7 * O, ee = t.fontMetrics().denom1) : (q > 0 ? (U = t.fontMetrics().num2, Q = O) : (U = t.fontMetrics().num3, Q = 3 * O), ee = t.fontMetrics().denom2);
            var ce;
            if (z) {
              var pe = t.fontMetrics().axisHeight;
              U - g.depth - (pe + 0.5 * q) < Q && (U += Q - (U - g.depth - (pe + 0.5 * q))), pe - 0.5 * q - (E.height - ee) < Q && (ee += Q - (pe - 0.5 * q - (E.height - ee)));
              var Ce = -(pe - 0.5 * q);
              ce = N.makeVList({
                positionType: "individualShift",
                children: [{
                  type: "elem",
                  elem: E,
                  shift: ee
                }, {
                  type: "elem",
                  elem: z,
                  shift: Ce
                }, {
                  type: "elem",
                  elem: g,
                  shift: -U
                }]
              }, t);
            } else {
              var me = U - g.depth - (E.height - ee);
              me < Q && (U += 0.5 * (Q - me), ee += 0.5 * (Q - me)), ce = N.makeVList({
                positionType: "individualShift",
                children: [{
                  type: "elem",
                  elem: E,
                  shift: ee
                }, {
                  type: "elem",
                  elem: g,
                  shift: -U
                }]
              }, t);
            }
            f = t.havingStyle(r), ce.height *= f.sizeMultiplier / t.sizeMultiplier, ce.depth *= f.sizeMultiplier / t.sizeMultiplier;
            var we;
            r.size === K.DISPLAY.size ? we = t.fontMetrics().delim1 : r.size === K.SCRIPTSCRIPT.size ? we = t.havingStyle(K.SCRIPT).fontMetrics().delim2 : we = t.fontMetrics().delim2;
            var Me, Fe;
            return e.leftDelim == null ? Me = pr(t, ["mopen"]) : Me = r0.customSizedDelim(e.leftDelim, we, !0, t.havingStyle(r), e.mode, ["mopen"]), e.continued ? Fe = N.makeSpan([]) : e.rightDelim == null ? Fe = pr(t, ["mclose"]) : Fe = r0.customSizedDelim(e.rightDelim, we, !0, t.havingStyle(r), e.mode, ["mclose"]), N.makeSpan(["mord"].concat(f.sizingClasses(t)), [Me, N.makeSpan(["mfrac"], [ce]), Fe], t);
          }, ea = function(e, t) {
            var r = new Y.MathNode("mfrac", [Oe(e.numer, t), Oe(e.denom, t)]);
            if (!e.hasBarLine)
              r.setAttribute("linethickness", "0px");
            else if (e.barSize) {
              var n = Ie(e.barSize, t);
              r.setAttribute("linethickness", J(n));
            }
            var s = Bi(e.size, t.style);
            if (s.size !== t.style.size) {
              r = new Y.MathNode("mstyle", [r]);
              var f = s.size === K.DISPLAY.size ? "true" : "false";
              r.setAttribute("displaystyle", f), r.setAttribute("scriptlevel", "0");
            }
            if (e.leftDelim != null || e.rightDelim != null) {
              var g = [];
              if (e.leftDelim != null) {
                var w = new Y.MathNode("mo", [new Y.TextNode(e.leftDelim.replace("\\", ""))]);
                w.setAttribute("fence", "true"), g.push(w);
              }
              if (g.push(r), e.rightDelim != null) {
                var x = new Y.MathNode("mo", [new Y.TextNode(e.rightDelim.replace("\\", ""))]);
                x.setAttribute("fence", "true"), g.push(x);
              }
              return Ln(g);
            }
            return r;
          };
          ne({
            type: "genfrac",
            names: [
              "\\dfrac",
              "\\frac",
              "\\tfrac",
              "\\dbinom",
              "\\binom",
              "\\tbinom",
              "\\\\atopfrac",
              // can’t be entered directly
              "\\\\bracefrac",
              "\\\\brackfrac"
              // ditto
            ],
            props: {
              numArgs: 2,
              allowedInArgument: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = t[0], f = t[1], g, w = null, x = null, E = "auto";
              switch (n) {
                case "\\dfrac":
                case "\\frac":
                case "\\tfrac":
                  g = !0;
                  break;
                case "\\\\atopfrac":
                  g = !1;
                  break;
                case "\\dbinom":
                case "\\binom":
                case "\\tbinom":
                  g = !1, w = "(", x = ")";
                  break;
                case "\\\\bracefrac":
                  g = !1, w = "\\{", x = "\\}";
                  break;
                case "\\\\brackfrac":
                  g = !1, w = "[", x = "]";
                  break;
                default:
                  throw new Error("Unrecognized genfrac command");
              }
              switch (n) {
                case "\\dfrac":
                case "\\dbinom":
                  E = "display";
                  break;
                case "\\tfrac":
                case "\\tbinom":
                  E = "text";
                  break;
              }
              return {
                type: "genfrac",
                mode: r.mode,
                continued: !1,
                numer: s,
                denom: f,
                hasBarLine: g,
                leftDelim: w,
                rightDelim: x,
                size: E,
                barSize: null
              };
            },
            htmlBuilder: $n,
            mathmlBuilder: ea
          }), ne({
            type: "genfrac",
            names: ["\\cfrac"],
            props: {
              numArgs: 2
            },
            handler: function(e, t) {
              var r = e.parser;
              e.funcName;
              var n = t[0], s = t[1];
              return {
                type: "genfrac",
                mode: r.mode,
                continued: !0,
                numer: n,
                denom: s,
                hasBarLine: !0,
                leftDelim: null,
                rightDelim: null,
                size: "display",
                barSize: null
              };
            }
          }), ne({
            type: "infix",
            names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
            props: {
              numArgs: 0,
              infix: !0
            },
            handler: function(e) {
              var t = e.parser, r = e.funcName, n = e.token, s;
              switch (r) {
                case "\\over":
                  s = "\\frac";
                  break;
                case "\\choose":
                  s = "\\binom";
                  break;
                case "\\atop":
                  s = "\\\\atopfrac";
                  break;
                case "\\brace":
                  s = "\\\\bracefrac";
                  break;
                case "\\brack":
                  s = "\\\\brackfrac";
                  break;
                default:
                  throw new Error("Unrecognized infix genfrac command");
              }
              return {
                type: "infix",
                mode: t.mode,
                replaceWith: s,
                token: n
              };
            }
          });
          var Mi = ["display", "text", "script", "scriptscript"], zi = function(e) {
            var t = null;
            return e.length > 0 && (t = e, t = t === "." ? null : t), t;
          };
          ne({
            type: "genfrac",
            names: ["\\genfrac"],
            props: {
              numArgs: 6,
              allowedInArgument: !0,
              argTypes: ["math", "math", "size", "text", "math", "math"]
            },
            handler: function(e, t) {
              var r = e.parser, n = t[4], s = t[5], f = Wr(t[0]), g = f.type === "atom" && f.family === "open" ? zi(f.text) : null, w = Wr(t[1]), x = w.type === "atom" && w.family === "close" ? zi(w.text) : null, E = ye(t[2], "size"), z, q = null;
              E.isBlank ? z = !0 : (q = E.value, z = q.number > 0);
              var O = "auto", U = t[3];
              if (U.type === "ordgroup") {
                if (U.body.length > 0) {
                  var Q = ye(U.body[0], "textord");
                  O = Mi[Number(Q.text)];
                }
              } else
                U = ye(U, "textord"), O = Mi[Number(U.text)];
              return {
                type: "genfrac",
                mode: r.mode,
                numer: n,
                denom: s,
                continued: !1,
                hasBarLine: z,
                barSize: q,
                leftDelim: g,
                rightDelim: x,
                size: O
              };
            },
            htmlBuilder: $n,
            mathmlBuilder: ea
          }), ne({
            type: "infix",
            names: ["\\above"],
            props: {
              numArgs: 1,
              argTypes: ["size"],
              infix: !0
            },
            handler: function(e, t) {
              var r = e.parser;
              e.funcName;
              var n = e.token;
              return {
                type: "infix",
                mode: r.mode,
                replaceWith: "\\\\abovefrac",
                size: ye(t[0], "size").value,
                token: n
              };
            }
          }), ne({
            type: "genfrac",
            names: ["\\\\abovefrac"],
            props: {
              numArgs: 3,
              argTypes: ["math", "size", "math"]
            },
            handler: function(e, t) {
              var r = e.parser;
              e.funcName;
              var n = t[0], s = oe(ye(t[1], "infix").size), f = t[2], g = s.number > 0;
              return {
                type: "genfrac",
                mode: r.mode,
                numer: n,
                denom: f,
                continued: !1,
                hasBarLine: g,
                barSize: s,
                leftDelim: null,
                rightDelim: null,
                size: "auto"
              };
            },
            htmlBuilder: $n,
            mathmlBuilder: ea
          });
          var Ni = function(e, t) {
            var r = t.style, n, s;
            e.type === "supsub" ? (n = e.sup ? Se(e.sup, t.havingStyle(r.sup()), t) : Se(e.sub, t.havingStyle(r.sub()), t), s = ye(e.base, "horizBrace")) : s = ye(e, "horizBrace");
            var f = Se(s.base, t.havingBaseStyle(K.DISPLAY)), g = t0.svgSpan(s, t), w;
            if (s.isOver ? (w = N.makeVList({
              positionType: "firstBaseline",
              children: [{
                type: "elem",
                elem: f
              }, {
                type: "kern",
                size: 0.1
              }, {
                type: "elem",
                elem: g
              }]
            }, t), w.children[0].children[0].children[1].classes.push("svg-align")) : (w = N.makeVList({
              positionType: "bottom",
              positionData: f.depth + 0.1 + g.height,
              children: [{
                type: "elem",
                elem: g
              }, {
                type: "kern",
                size: 0.1
              }, {
                type: "elem",
                elem: f
              }]
            }, t), w.children[0].children[0].children[0].classes.push("svg-align")), n) {
              var x = N.makeSpan(["mord", s.isOver ? "mover" : "munder"], [w], t);
              s.isOver ? w = N.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: x
                }, {
                  type: "kern",
                  size: 0.2
                }, {
                  type: "elem",
                  elem: n
                }]
              }, t) : w = N.makeVList({
                positionType: "bottom",
                positionData: x.depth + 0.2 + n.height + n.depth,
                children: [{
                  type: "elem",
                  elem: n
                }, {
                  type: "kern",
                  size: 0.2
                }, {
                  type: "elem",
                  elem: x
                }]
              }, t);
            }
            return N.makeSpan(["mord", s.isOver ? "mover" : "munder"], [w], t);
          }, iu = function(e, t) {
            var r = t0.mathMLnode(e.label);
            return new Y.MathNode(e.isOver ? "mover" : "munder", [Oe(e.base, t), r]);
          };
          ne({
            type: "horizBrace",
            names: ["\\overbrace", "\\underbrace"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName;
              return {
                type: "horizBrace",
                mode: r.mode,
                label: n,
                isOver: /^\\over/.test(n),
                base: t[0]
              };
            },
            htmlBuilder: Ni,
            mathmlBuilder: iu
          }), ne({
            type: "href",
            names: ["\\href"],
            props: {
              numArgs: 2,
              argTypes: ["url", "original"],
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = t[1], s = ye(t[0], "url").url;
              return r.settings.isTrusted({
                command: "\\href",
                url: s
              }) ? {
                type: "href",
                mode: r.mode,
                href: s,
                body: Ze(n)
              } : r.formatUnsupportedCmd("\\href");
            },
            htmlBuilder: function(e, t) {
              var r = $e(e.body, t, !1);
              return N.makeAnchor(e.href, [], r, t);
            },
            mathmlBuilder: function(e, t) {
              var r = d0(e.body, t);
              return r instanceof _t || (r = new _t("mrow", [r])), r.setAttribute("href", e.href), r;
            }
          }), ne({
            type: "href",
            names: ["\\url"],
            props: {
              numArgs: 1,
              argTypes: ["url"],
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = ye(t[0], "url").url;
              if (!r.settings.isTrusted({
                command: "\\url",
                url: n
              }))
                return r.formatUnsupportedCmd("\\url");
              for (var s = [], f = 0; f < n.length; f++) {
                var g = n[f];
                g === "~" && (g = "\\textasciitilde"), s.push({
                  type: "textord",
                  mode: "text",
                  text: g
                });
              }
              var w = {
                type: "text",
                mode: r.mode,
                font: "\\texttt",
                body: s
              };
              return {
                type: "href",
                mode: r.mode,
                href: n,
                body: Ze(w)
              };
            }
          }), ne({
            type: "hbox",
            names: ["\\hbox"],
            props: {
              numArgs: 1,
              argTypes: ["text"],
              allowedInText: !0,
              primitive: !0
            },
            handler: function(e, t) {
              var r = e.parser;
              return {
                type: "hbox",
                mode: r.mode,
                body: Ze(t[0])
              };
            },
            htmlBuilder: function(e, t) {
              var r = $e(e.body, t, !1);
              return N.makeFragment(r);
            },
            mathmlBuilder: function(e, t) {
              return new Y.MathNode("mrow", ft(e.body, t));
            }
          }), ne({
            type: "html",
            names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
            props: {
              numArgs: 2,
              argTypes: ["raw", "original"],
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName;
              e.token;
              var s = ye(t[0], "raw").string, f = t[1];
              r.settings.strict && r.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
              var g, w = {};
              switch (n) {
                case "\\htmlClass":
                  w.class = s, g = {
                    command: "\\htmlClass",
                    class: s
                  };
                  break;
                case "\\htmlId":
                  w.id = s, g = {
                    command: "\\htmlId",
                    id: s
                  };
                  break;
                case "\\htmlStyle":
                  w.style = s, g = {
                    command: "\\htmlStyle",
                    style: s
                  };
                  break;
                case "\\htmlData": {
                  for (var x = s.split(","), E = 0; E < x.length; E++) {
                    var z = x[E].split("=");
                    if (z.length !== 2)
                      throw new c("Error parsing key-value for \\htmlData");
                    w["data-" + z[0].trim()] = z[1].trim();
                  }
                  g = {
                    command: "\\htmlData",
                    attributes: w
                  };
                  break;
                }
                default:
                  throw new Error("Unrecognized html command");
              }
              return r.settings.isTrusted(g) ? {
                type: "html",
                mode: r.mode,
                attributes: w,
                body: Ze(f)
              } : r.formatUnsupportedCmd(n);
            },
            htmlBuilder: function(e, t) {
              var r = $e(e.body, t, !1), n = ["enclosing"];
              e.attributes.class && n.push.apply(n, e.attributes.class.trim().split(/\s+/));
              var s = N.makeSpan(n, r, t);
              for (var f in e.attributes)
                f !== "class" && e.attributes.hasOwnProperty(f) && s.setAttribute(f, e.attributes[f]);
              return s;
            },
            mathmlBuilder: function(e, t) {
              return d0(e.body, t);
            }
          }), ne({
            type: "htmlmathml",
            names: ["\\html@mathml"],
            props: {
              numArgs: 2,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser;
              return {
                type: "htmlmathml",
                mode: r.mode,
                html: Ze(t[0]),
                mathml: Ze(t[1])
              };
            },
            htmlBuilder: function(e, t) {
              var r = $e(e.html, t, !1);
              return N.makeFragment(r);
            },
            mathmlBuilder: function(e, t) {
              return d0(e.mathml, t);
            }
          });
          var ta = function(e) {
            if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
              return {
                number: +e,
                unit: "bp"
              };
            var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
            if (!t)
              throw new c("Invalid size: '" + e + "' in \\includegraphics");
            var r = {
              number: +(t[1] + t[2]),
              // sign + magnitude, cast to number
              unit: t[3]
            };
            if (!X0(r))
              throw new c("Invalid unit: '" + r.unit + "' in \\includegraphics.");
            return r;
          };
          ne({
            type: "includegraphics",
            names: ["\\includegraphics"],
            props: {
              numArgs: 1,
              numOptionalArgs: 1,
              argTypes: ["raw", "url"],
              allowedInText: !1
            },
            handler: function(e, t, r) {
              var n = e.parser, s = {
                number: 0,
                unit: "em"
              }, f = {
                number: 0.9,
                unit: "em"
              }, g = {
                number: 0,
                unit: "em"
              }, w = "";
              if (r[0])
                for (var x = ye(r[0], "raw").string, E = x.split(","), z = 0; z < E.length; z++) {
                  var q = E[z].split("=");
                  if (q.length === 2) {
                    var O = q[1].trim();
                    switch (q[0].trim()) {
                      case "alt":
                        w = O;
                        break;
                      case "width":
                        s = ta(O);
                        break;
                      case "height":
                        f = ta(O);
                        break;
                      case "totalheight":
                        g = ta(O);
                        break;
                      default:
                        throw new c("Invalid key: '" + q[0] + "' in \\includegraphics.");
                    }
                  }
                }
              var U = ye(t[0], "url").url;
              return w === "" && (w = U, w = w.replace(/^.*[\\/]/, ""), w = w.substring(0, w.lastIndexOf("."))), n.settings.isTrusted({
                command: "\\includegraphics",
                url: U
              }) ? {
                type: "includegraphics",
                mode: n.mode,
                alt: w,
                width: s,
                height: f,
                totalheight: g,
                src: U
              } : n.formatUnsupportedCmd("\\includegraphics");
            },
            htmlBuilder: function(e, t) {
              var r = Ie(e.height, t), n = 0;
              e.totalheight.number > 0 && (n = Ie(e.totalheight, t) - r);
              var s = 0;
              e.width.number > 0 && (s = Ie(e.width, t));
              var f = {
                height: J(r + n)
              };
              s > 0 && (f.width = J(s)), n > 0 && (f.verticalAlign = J(-n));
              var g = new Ir(e.src, e.alt, f);
              return g.height = r, g.depth = n, g;
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mglyph", []);
              r.setAttribute("alt", e.alt);
              var n = Ie(e.height, t), s = 0;
              if (e.totalheight.number > 0 && (s = Ie(e.totalheight, t) - n, r.setAttribute("valign", J(-s))), r.setAttribute("height", J(n + s)), e.width.number > 0) {
                var f = Ie(e.width, t);
                r.setAttribute("width", J(f));
              }
              return r.setAttribute("src", e.src), r;
            }
          }), ne({
            type: "kern",
            names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
            props: {
              numArgs: 1,
              argTypes: ["size"],
              primitive: !0,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = ye(t[0], "size");
              if (r.settings.strict) {
                var f = n[1] === "m", g = s.value.unit === "mu";
                f ? (g || r.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + n + " supports only mu units, " + ("not " + s.value.unit + " units")), r.mode !== "math" && r.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + n + " works only in math mode")) : g && r.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + n + " doesn't support mu units");
              }
              return {
                type: "kern",
                mode: r.mode,
                dimension: s.value
              };
            },
            htmlBuilder: function(e, t) {
              return N.makeGlue(e.dimension, t);
            },
            mathmlBuilder: function(e, t) {
              var r = Ie(e.dimension, t);
              return new Y.SpaceNode(r);
            }
          }), ne({
            type: "lap",
            names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = t[0];
              return {
                type: "lap",
                mode: r.mode,
                alignment: n.slice(5),
                body: s
              };
            },
            htmlBuilder: function(e, t) {
              var r;
              e.alignment === "clap" ? (r = N.makeSpan([], [Se(e.body, t)]), r = N.makeSpan(["inner"], [r], t)) : r = N.makeSpan(["inner"], [Se(e.body, t)]);
              var n = N.makeSpan(["fix"], []), s = N.makeSpan([e.alignment], [r, n], t), f = N.makeSpan(["strut"]);
              return f.style.height = J(s.height + s.depth), s.depth && (f.style.verticalAlign = J(-s.depth)), s.children.unshift(f), s = N.makeSpan(["thinbox"], [s], t), N.makeSpan(["mord", "vbox"], [s], t);
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mpadded", [Oe(e.body, t)]);
              if (e.alignment !== "rlap") {
                var n = e.alignment === "llap" ? "-1" : "-0.5";
                r.setAttribute("lspace", n + "width");
              }
              return r.setAttribute("width", "0px"), r;
            }
          }), ne({
            type: "styling",
            names: ["\\(", "$"],
            props: {
              numArgs: 0,
              allowedInText: !0,
              allowedInMath: !1
            },
            handler: function(e, t) {
              var r = e.funcName, n = e.parser, s = n.mode;
              n.switchMode("math");
              var f = r === "\\(" ? "\\)" : "$", g = n.parseExpression(!1, f);
              return n.expect(f), n.switchMode(s), {
                type: "styling",
                mode: n.mode,
                style: "text",
                body: g
              };
            }
          }), ne({
            type: "text",
            // Doesn't matter what this is.
            names: ["\\)", "\\]"],
            props: {
              numArgs: 0,
              allowedInText: !0,
              allowedInMath: !1
            },
            handler: function(e, t) {
              throw new c("Mismatched " + e.funcName);
            }
          });
          var Ri = function(e, t) {
            switch (t.style.size) {
              case K.DISPLAY.size:
                return e.display;
              case K.TEXT.size:
                return e.text;
              case K.SCRIPT.size:
                return e.script;
              case K.SCRIPTSCRIPT.size:
                return e.scriptscript;
              default:
                return e.text;
            }
          };
          ne({
            type: "mathchoice",
            names: ["\\mathchoice"],
            props: {
              numArgs: 4,
              primitive: !0
            },
            handler: function(e, t) {
              var r = e.parser;
              return {
                type: "mathchoice",
                mode: r.mode,
                display: Ze(t[0]),
                text: Ze(t[1]),
                script: Ze(t[2]),
                scriptscript: Ze(t[3])
              };
            },
            htmlBuilder: function(e, t) {
              var r = Ri(e, t), n = $e(r, t, !1);
              return N.makeFragment(n);
            },
            mathmlBuilder: function(e, t) {
              var r = Ri(e, t);
              return d0(r, t);
            }
          });
          var Ii = function(e, t, r, n, s, f, g) {
            e = N.makeSpan([], [e]);
            var w = r && L.isCharacterBox(r), x, E;
            if (t) {
              var z = Se(t, n.havingStyle(s.sup()), n);
              E = {
                elem: z,
                kern: Math.max(n.fontMetrics().bigOpSpacing1, n.fontMetrics().bigOpSpacing3 - z.depth)
              };
            }
            if (r) {
              var q = Se(r, n.havingStyle(s.sub()), n);
              x = {
                elem: q,
                kern: Math.max(n.fontMetrics().bigOpSpacing2, n.fontMetrics().bigOpSpacing4 - q.height)
              };
            }
            var O;
            if (E && x) {
              var U = n.fontMetrics().bigOpSpacing5 + x.elem.height + x.elem.depth + x.kern + e.depth + g;
              O = N.makeVList({
                positionType: "bottom",
                positionData: U,
                children: [{
                  type: "kern",
                  size: n.fontMetrics().bigOpSpacing5
                }, {
                  type: "elem",
                  elem: x.elem,
                  marginLeft: J(-f)
                }, {
                  type: "kern",
                  size: x.kern
                }, {
                  type: "elem",
                  elem: e
                }, {
                  type: "kern",
                  size: E.kern
                }, {
                  type: "elem",
                  elem: E.elem,
                  marginLeft: J(f)
                }, {
                  type: "kern",
                  size: n.fontMetrics().bigOpSpacing5
                }]
              }, n);
            } else if (x) {
              var Q = e.height - g;
              O = N.makeVList({
                positionType: "top",
                positionData: Q,
                children: [{
                  type: "kern",
                  size: n.fontMetrics().bigOpSpacing5
                }, {
                  type: "elem",
                  elem: x.elem,
                  marginLeft: J(-f)
                }, {
                  type: "kern",
                  size: x.kern
                }, {
                  type: "elem",
                  elem: e
                }]
              }, n);
            } else if (E) {
              var ee = e.depth + g;
              O = N.makeVList({
                positionType: "bottom",
                positionData: ee,
                children: [{
                  type: "elem",
                  elem: e
                }, {
                  type: "kern",
                  size: E.kern
                }, {
                  type: "elem",
                  elem: E.elem,
                  marginLeft: J(f)
                }, {
                  type: "kern",
                  size: n.fontMetrics().bigOpSpacing5
                }]
              }, n);
            } else
              return e;
            var ce = [O];
            if (x && f !== 0 && !w) {
              var me = N.makeSpan(["mspace"], [], n);
              me.style.marginRight = J(f), ce.unshift(me);
            }
            return N.makeSpan(["mop", "op-limits"], ce, n);
          }, Li = ["\\smallint"], Z0 = function(e, t) {
            var r, n, s = !1, f;
            e.type === "supsub" ? (r = e.sup, n = e.sub, f = ye(e.base, "op"), s = !0) : f = ye(e, "op");
            var g = t.style, w = !1;
            g.size === K.DISPLAY.size && f.symbol && !L.contains(Li, f.name) && (w = !0);
            var x;
            if (f.symbol) {
              var E = w ? "Size2-Regular" : "Size1-Regular", z = "";
              if ((f.name === "\\oiint" || f.name === "\\oiiint") && (z = f.name.slice(1), f.name = z === "oiint" ? "\\iint" : "\\iiint"), x = N.makeSymbol(f.name, E, "math", t, ["mop", "op-symbol", w ? "large-op" : "small-op"]), z.length > 0) {
                var q = x.italic, O = N.staticSvg(z + "Size" + (w ? "2" : "1"), t);
                x = N.makeVList({
                  positionType: "individualShift",
                  children: [{
                    type: "elem",
                    elem: x,
                    shift: 0
                  }, {
                    type: "elem",
                    elem: O,
                    shift: w ? 0.08 : 0
                  }]
                }, t), f.name = "\\" + z, x.classes.unshift("mop"), x.italic = q;
              }
            } else if (f.body) {
              var U = $e(f.body, t, !0);
              U.length === 1 && U[0] instanceof it ? (x = U[0], x.classes[0] = "mop") : x = N.makeSpan(["mop"], U, t);
            } else {
              for (var Q = [], ee = 1; ee < f.name.length; ee++)
                Q.push(N.mathsym(f.name[ee], f.mode, t));
              x = N.makeSpan(["mop"], Q, t);
            }
            var ce = 0, me = 0;
            return (x instanceof it || f.name === "\\oiint" || f.name === "\\oiiint") && !f.suppressBaseShift && (ce = (x.height - x.depth) / 2 - t.fontMetrics().axisHeight, me = x.italic), s ? Ii(x, r, n, t, g, me, ce) : (ce && (x.style.position = "relative", x.style.top = J(ce)), x);
          }, yr = function(e, t) {
            var r;
            if (e.symbol)
              r = new _t("mo", [St(e.name, e.mode)]), L.contains(Li, e.name) && r.setAttribute("largeop", "false");
            else if (e.body)
              r = new _t("mo", ft(e.body, t));
            else {
              r = new _t("mi", [new gr(e.name.slice(1))]);
              var n = new _t("mo", [St("⁡", "text")]);
              e.parentIsSupSub ? r = new _t("mrow", [r, n]) : r = ei([r, n]);
            }
            return r;
          }, lu = {
            "∏": "\\prod",
            "∐": "\\coprod",
            "∑": "\\sum",
            "⋀": "\\bigwedge",
            "⋁": "\\bigvee",
            "⋂": "\\bigcap",
            "⋃": "\\bigcup",
            "⨀": "\\bigodot",
            "⨁": "\\bigoplus",
            "⨂": "\\bigotimes",
            "⨄": "\\biguplus",
            "⨆": "\\bigsqcup"
          };
          ne({
            type: "op",
            names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
            props: {
              numArgs: 0
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = n;
              return s.length === 1 && (s = lu[s]), {
                type: "op",
                mode: r.mode,
                limits: !0,
                parentIsSupSub: !1,
                symbol: !0,
                name: s
              };
            },
            htmlBuilder: Z0,
            mathmlBuilder: yr
          }), ne({
            type: "op",
            names: ["\\mathop"],
            props: {
              numArgs: 1,
              primitive: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = t[0];
              return {
                type: "op",
                mode: r.mode,
                limits: !1,
                parentIsSupSub: !1,
                symbol: !1,
                body: Ze(n)
              };
            },
            htmlBuilder: Z0,
            mathmlBuilder: yr
          });
          var su = {
            "∫": "\\int",
            "∬": "\\iint",
            "∭": "\\iiint",
            "∮": "\\oint",
            "∯": "\\oiint",
            "∰": "\\oiiint"
          };
          ne({
            type: "op",
            names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var t = e.parser, r = e.funcName;
              return {
                type: "op",
                mode: t.mode,
                limits: !1,
                parentIsSupSub: !1,
                symbol: !1,
                name: r
              };
            },
            htmlBuilder: Z0,
            mathmlBuilder: yr
          }), ne({
            type: "op",
            names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var t = e.parser, r = e.funcName;
              return {
                type: "op",
                mode: t.mode,
                limits: !0,
                parentIsSupSub: !1,
                symbol: !1,
                name: r
              };
            },
            htmlBuilder: Z0,
            mathmlBuilder: yr
          }), ne({
            type: "op",
            names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var t = e.parser, r = e.funcName, n = r;
              return n.length === 1 && (n = su[n]), {
                type: "op",
                mode: t.mode,
                limits: !1,
                parentIsSupSub: !1,
                symbol: !0,
                name: n
              };
            },
            htmlBuilder: Z0,
            mathmlBuilder: yr
          });
          var Oi = function(e, t) {
            var r, n, s = !1, f;
            e.type === "supsub" ? (r = e.sup, n = e.sub, f = ye(e.base, "operatorname"), s = !0) : f = ye(e, "operatorname");
            var g;
            if (f.body.length > 0) {
              for (var w = f.body.map(function(q) {
                var O = q.text;
                return typeof O == "string" ? {
                  type: "textord",
                  mode: q.mode,
                  text: O
                } : q;
              }), x = $e(w, t.withFont("mathrm"), !0), E = 0; E < x.length; E++) {
                var z = x[E];
                z instanceof it && (z.text = z.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
              }
              g = N.makeSpan(["mop"], x, t);
            } else
              g = N.makeSpan(["mop"], [], t);
            return s ? Ii(g, r, n, t, t.style, 0, 0) : g;
          }, ou = function(e, t) {
            for (var r = ft(e.body, t.withFont("mathrm")), n = !0, s = 0; s < r.length; s++) {
              var f = r[s];
              if (!(f instanceof Y.SpaceNode))
                if (f instanceof Y.MathNode)
                  switch (f.type) {
                    case "mi":
                    case "mn":
                    case "ms":
                    case "mspace":
                    case "mtext":
                      break;
                    case "mo": {
                      var g = f.children[0];
                      f.children.length === 1 && g instanceof Y.TextNode ? g.text = g.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : n = !1;
                      break;
                    }
                    default:
                      n = !1;
                  }
                else
                  n = !1;
            }
            if (n) {
              var w = r.map(function(z) {
                return z.toText();
              }).join("");
              r = [new Y.TextNode(w)];
            }
            var x = new Y.MathNode("mi", r);
            x.setAttribute("mathvariant", "normal");
            var E = new Y.MathNode("mo", [St("⁡", "text")]);
            return e.parentIsSupSub ? new Y.MathNode("mrow", [x, E]) : Y.newDocumentFragment([x, E]);
          };
          ne({
            type: "operatorname",
            names: ["\\operatorname@", "\\operatornamewithlimits"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = t[0];
              return {
                type: "operatorname",
                mode: r.mode,
                body: Ze(s),
                alwaysHandleSupSub: n === "\\operatornamewithlimits",
                limits: !1,
                parentIsSupSub: !1
              };
            },
            htmlBuilder: Oi,
            mathmlBuilder: ou
          }), k("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@"), O0({
            type: "ordgroup",
            htmlBuilder: function(e, t) {
              return e.semisimple ? N.makeFragment($e(e.body, t, !1)) : N.makeSpan(["mord"], $e(e.body, t, !0), t);
            },
            mathmlBuilder: function(e, t) {
              return d0(e.body, t, !0);
            }
          }), ne({
            type: "overline",
            names: ["\\overline"],
            props: {
              numArgs: 1
            },
            handler: function(e, t) {
              var r = e.parser, n = t[0];
              return {
                type: "overline",
                mode: r.mode,
                body: n
              };
            },
            htmlBuilder: function(e, t) {
              var r = Se(e.body, t.havingCrampedStyle()), n = N.makeLineSpan("overline-line", t), s = t.fontMetrics().defaultRuleThickness, f = N.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: r
                }, {
                  type: "kern",
                  size: 3 * s
                }, {
                  type: "elem",
                  elem: n
                }, {
                  type: "kern",
                  size: s
                }]
              }, t);
              return N.makeSpan(["mord", "overline"], [f], t);
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mo", [new Y.TextNode("‾")]);
              r.setAttribute("stretchy", "true");
              var n = new Y.MathNode("mover", [Oe(e.body, t), r]);
              return n.setAttribute("accent", "true"), n;
            }
          }), ne({
            type: "phantom",
            names: ["\\phantom"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = t[0];
              return {
                type: "phantom",
                mode: r.mode,
                body: Ze(n)
              };
            },
            htmlBuilder: function(e, t) {
              var r = $e(e.body, t.withPhantom(), !1);
              return N.makeFragment(r);
            },
            mathmlBuilder: function(e, t) {
              var r = ft(e.body, t);
              return new Y.MathNode("mphantom", r);
            }
          }), ne({
            type: "hphantom",
            names: ["\\hphantom"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = t[0];
              return {
                type: "hphantom",
                mode: r.mode,
                body: n
              };
            },
            htmlBuilder: function(e, t) {
              var r = N.makeSpan([], [Se(e.body, t.withPhantom())]);
              if (r.height = 0, r.depth = 0, r.children)
                for (var n = 0; n < r.children.length; n++)
                  r.children[n].height = 0, r.children[n].depth = 0;
              return r = N.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: r
                }]
              }, t), N.makeSpan(["mord"], [r], t);
            },
            mathmlBuilder: function(e, t) {
              var r = ft(Ze(e.body), t), n = new Y.MathNode("mphantom", r), s = new Y.MathNode("mpadded", [n]);
              return s.setAttribute("height", "0px"), s.setAttribute("depth", "0px"), s;
            }
          }), ne({
            type: "vphantom",
            names: ["\\vphantom"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = t[0];
              return {
                type: "vphantom",
                mode: r.mode,
                body: n
              };
            },
            htmlBuilder: function(e, t) {
              var r = N.makeSpan(["inner"], [Se(e.body, t.withPhantom())]), n = N.makeSpan(["fix"], []);
              return N.makeSpan(["mord", "rlap"], [r, n], t);
            },
            mathmlBuilder: function(e, t) {
              var r = ft(Ze(e.body), t), n = new Y.MathNode("mphantom", r), s = new Y.MathNode("mpadded", [n]);
              return s.setAttribute("width", "0px"), s;
            }
          }), ne({
            type: "raisebox",
            names: ["\\raisebox"],
            props: {
              numArgs: 2,
              argTypes: ["size", "hbox"],
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = ye(t[0], "size").value, s = t[1];
              return {
                type: "raisebox",
                mode: r.mode,
                dy: n,
                body: s
              };
            },
            htmlBuilder: function(e, t) {
              var r = Se(e.body, t), n = Ie(e.dy, t);
              return N.makeVList({
                positionType: "shift",
                positionData: -n,
                children: [{
                  type: "elem",
                  elem: r
                }]
              }, t);
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mpadded", [Oe(e.body, t)]), n = e.dy.number + e.dy.unit;
              return r.setAttribute("voffset", n), r;
            }
          }), ne({
            type: "internal",
            names: ["\\relax"],
            props: {
              numArgs: 0,
              allowedInText: !0
            },
            handler: function(e) {
              var t = e.parser;
              return {
                type: "internal",
                mode: t.mode
              };
            }
          }), ne({
            type: "rule",
            names: ["\\rule"],
            props: {
              numArgs: 2,
              numOptionalArgs: 1,
              argTypes: ["size", "size", "size"]
            },
            handler: function(e, t, r) {
              var n = e.parser, s = r[0], f = ye(t[0], "size"), g = ye(t[1], "size");
              return {
                type: "rule",
                mode: n.mode,
                shift: s && ye(s, "size").value,
                width: f.value,
                height: g.value
              };
            },
            htmlBuilder: function(e, t) {
              var r = N.makeSpan(["mord", "rule"], [], t), n = Ie(e.width, t), s = Ie(e.height, t), f = e.shift ? Ie(e.shift, t) : 0;
              return r.style.borderRightWidth = J(n), r.style.borderTopWidth = J(s), r.style.bottom = J(f), r.width = n, r.height = s + f, r.depth = -f, r.maxFontSize = s * 1.125 * t.sizeMultiplier, r;
            },
            mathmlBuilder: function(e, t) {
              var r = Ie(e.width, t), n = Ie(e.height, t), s = e.shift ? Ie(e.shift, t) : 0, f = t.color && t.getColor() || "black", g = new Y.MathNode("mspace");
              g.setAttribute("mathbackground", f), g.setAttribute("width", J(r)), g.setAttribute("height", J(n));
              var w = new Y.MathNode("mpadded", [g]);
              return s >= 0 ? w.setAttribute("height", J(s)) : (w.setAttribute("height", J(s)), w.setAttribute("depth", J(-s))), w.setAttribute("voffset", J(s)), w;
            }
          });
          function qi(h, e, t) {
            for (var r = $e(h, e, !1), n = e.sizeMultiplier / t.sizeMultiplier, s = 0; s < r.length; s++) {
              var f = r[s].classes.indexOf("sizing");
              f < 0 ? Array.prototype.push.apply(r[s].classes, e.sizingClasses(t)) : r[s].classes[f + 1] === "reset-size" + e.size && (r[s].classes[f + 1] = "reset-size" + t.size), r[s].height *= n, r[s].depth *= n;
            }
            return N.makeFragment(r);
          }
          var Pi = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], uu = function(e, t) {
            var r = t.havingSize(e.size);
            return qi(e.body, r, t);
          };
          ne({
            type: "sizing",
            names: Pi,
            props: {
              numArgs: 0,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.breakOnTokenText, n = e.funcName, s = e.parser, f = s.parseExpression(!1, r);
              return {
                type: "sizing",
                mode: s.mode,
                // Figure out what size to use based on the list of functions above
                size: Pi.indexOf(n) + 1,
                body: f
              };
            },
            htmlBuilder: uu,
            mathmlBuilder: function(e, t) {
              var r = t.havingSize(e.size), n = ft(e.body, r), s = new Y.MathNode("mstyle", n);
              return s.setAttribute("mathsize", J(r.sizeMultiplier)), s;
            }
          }), ne({
            type: "smash",
            names: ["\\smash"],
            props: {
              numArgs: 1,
              numOptionalArgs: 1,
              allowedInText: !0
            },
            handler: function(e, t, r) {
              var n = e.parser, s = !1, f = !1, g = r[0] && ye(r[0], "ordgroup");
              if (g)
                for (var w = "", x = 0; x < g.body.length; ++x) {
                  var E = g.body[x];
                  if (w = E.text, w === "t")
                    s = !0;
                  else if (w === "b")
                    f = !0;
                  else {
                    s = !1, f = !1;
                    break;
                  }
                }
              else
                s = !0, f = !0;
              var z = t[0];
              return {
                type: "smash",
                mode: n.mode,
                body: z,
                smashHeight: s,
                smashDepth: f
              };
            },
            htmlBuilder: function(e, t) {
              var r = N.makeSpan([], [Se(e.body, t)]);
              if (!e.smashHeight && !e.smashDepth)
                return r;
              if (e.smashHeight && (r.height = 0, r.children))
                for (var n = 0; n < r.children.length; n++)
                  r.children[n].height = 0;
              if (e.smashDepth && (r.depth = 0, r.children))
                for (var s = 0; s < r.children.length; s++)
                  r.children[s].depth = 0;
              var f = N.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: r
                }]
              }, t);
              return N.makeSpan(["mord"], [f], t);
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mpadded", [Oe(e.body, t)]);
              return e.smashHeight && r.setAttribute("height", "0px"), e.smashDepth && r.setAttribute("depth", "0px"), r;
            }
          }), ne({
            type: "sqrt",
            names: ["\\sqrt"],
            props: {
              numArgs: 1,
              numOptionalArgs: 1
            },
            handler: function(e, t, r) {
              var n = e.parser, s = r[0], f = t[0];
              return {
                type: "sqrt",
                mode: n.mode,
                body: f,
                index: s
              };
            },
            htmlBuilder: function(e, t) {
              var r = Se(e.body, t.havingCrampedStyle());
              r.height === 0 && (r.height = t.fontMetrics().xHeight), r = N.wrapFragment(r, t);
              var n = t.fontMetrics(), s = n.defaultRuleThickness, f = s;
              t.style.id < K.TEXT.id && (f = t.fontMetrics().xHeight);
              var g = s + f / 4, w = r.height + r.depth + g + s, x = r0.sqrtImage(w, t), E = x.span, z = x.ruleWidth, q = x.advanceWidth, O = E.height - z;
              O > r.height + r.depth + g && (g = (g + O - r.height - r.depth) / 2);
              var U = E.height - r.height - g - z;
              r.style.paddingLeft = J(q);
              var Q = N.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: r,
                  wrapperClasses: ["svg-align"]
                }, {
                  type: "kern",
                  size: -(r.height + U)
                }, {
                  type: "elem",
                  elem: E
                }, {
                  type: "kern",
                  size: z
                }]
              }, t);
              if (e.index) {
                var ee = t.havingStyle(K.SCRIPTSCRIPT), ce = Se(e.index, ee, t), me = 0.6 * (Q.height - Q.depth), pe = N.makeVList({
                  positionType: "shift",
                  positionData: -me,
                  children: [{
                    type: "elem",
                    elem: ce
                  }]
                }, t), Ce = N.makeSpan(["root"], [pe]);
                return N.makeSpan(["mord", "sqrt"], [Ce, Q], t);
              } else
                return N.makeSpan(["mord", "sqrt"], [Q], t);
            },
            mathmlBuilder: function(e, t) {
              var r = e.body, n = e.index;
              return n ? new Y.MathNode("mroot", [Oe(r, t), Oe(n, t)]) : new Y.MathNode("msqrt", [Oe(r, t)]);
            }
          });
          var Hi = {
            display: K.DISPLAY,
            text: K.TEXT,
            script: K.SCRIPT,
            scriptscript: K.SCRIPTSCRIPT
          };
          ne({
            type: "styling",
            names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
            props: {
              numArgs: 0,
              allowedInText: !0,
              primitive: !0
            },
            handler: function(e, t) {
              var r = e.breakOnTokenText, n = e.funcName, s = e.parser, f = s.parseExpression(!0, r), g = n.slice(1, n.length - 5);
              return {
                type: "styling",
                mode: s.mode,
                // Figure out what style to use by pulling out the style from
                // the function name
                style: g,
                body: f
              };
            },
            htmlBuilder: function(e, t) {
              var r = Hi[e.style], n = t.havingStyle(r).withFont("");
              return qi(e.body, n, t);
            },
            mathmlBuilder: function(e, t) {
              var r = Hi[e.style], n = t.havingStyle(r), s = ft(e.body, n), f = new Y.MathNode("mstyle", s), g = {
                display: ["0", "true"],
                text: ["0", "false"],
                script: ["1", "false"],
                scriptscript: ["2", "false"]
              }, w = g[e.style];
              return f.setAttribute("scriptlevel", w[0]), f.setAttribute("displaystyle", w[1]), f;
            }
          });
          var cu = function(e, t) {
            var r = e.base;
            if (r)
              if (r.type === "op") {
                var n = r.limits && (t.style.size === K.DISPLAY.size || r.alwaysHandleSupSub);
                return n ? Z0 : null;
              } else if (r.type === "operatorname") {
                var s = r.alwaysHandleSupSub && (t.style.size === K.DISPLAY.size || r.limits);
                return s ? Oi : null;
              } else {
                if (r.type === "accent")
                  return L.isCharacterBox(r.base) ? Pn : null;
                if (r.type === "horizBrace") {
                  var f = !e.sub;
                  return f === r.isOver ? Ni : null;
                } else
                  return null;
              }
            else
              return null;
          };
          O0({
            type: "supsub",
            htmlBuilder: function(e, t) {
              var r = cu(e, t);
              if (r)
                return r(e, t);
              var n = e.base, s = e.sup, f = e.sub, g = Se(n, t), w, x, E = t.fontMetrics(), z = 0, q = 0, O = n && L.isCharacterBox(n);
              if (s) {
                var U = t.havingStyle(t.style.sup());
                w = Se(s, U, t), O || (z = g.height - U.fontMetrics().supDrop * U.sizeMultiplier / t.sizeMultiplier);
              }
              if (f) {
                var Q = t.havingStyle(t.style.sub());
                x = Se(f, Q, t), O || (q = g.depth + Q.fontMetrics().subDrop * Q.sizeMultiplier / t.sizeMultiplier);
              }
              var ee;
              t.style === K.DISPLAY ? ee = E.sup1 : t.style.cramped ? ee = E.sup3 : ee = E.sup2;
              var ce = t.sizeMultiplier, me = J(0.5 / E.ptPerEm / ce), pe = null;
              if (x) {
                var Ce = e.base && e.base.type === "op" && e.base.name && (e.base.name === "\\oiint" || e.base.name === "\\oiiint");
                (g instanceof it || Ce) && (pe = J(-g.italic));
              }
              var we;
              if (w && x) {
                z = Math.max(z, ee, w.depth + 0.25 * E.xHeight), q = Math.max(q, E.sub2);
                var Me = E.defaultRuleThickness, Fe = 4 * Me;
                if (z - w.depth - (x.height - q) < Fe) {
                  q = Fe - (z - w.depth) + x.height;
                  var ze = 0.8 * E.xHeight - (z - w.depth);
                  ze > 0 && (z += ze, q -= ze);
                }
                var He = [{
                  type: "elem",
                  elem: x,
                  shift: q,
                  marginRight: me,
                  marginLeft: pe
                }, {
                  type: "elem",
                  elem: w,
                  shift: -z,
                  marginRight: me
                }];
                we = N.makeVList({
                  positionType: "individualShift",
                  children: He
                }, t);
              } else if (x) {
                q = Math.max(q, E.sub1, x.height - 0.8 * E.xHeight);
                var rt = [{
                  type: "elem",
                  elem: x,
                  marginLeft: pe,
                  marginRight: me
                }];
                we = N.makeVList({
                  positionType: "shift",
                  positionData: q,
                  children: rt
                }, t);
              } else if (w)
                z = Math.max(z, ee, w.depth + 0.25 * E.xHeight), we = N.makeVList({
                  positionType: "shift",
                  positionData: -z,
                  children: [{
                    type: "elem",
                    elem: w,
                    marginRight: me
                  }]
                }, t);
              else
                throw new Error("supsub must have either sup or sub.");
              var dt = Rn(g, "right") || "mord";
              return N.makeSpan([dt], [g, N.makeSpan(["msupsub"], [we])], t);
            },
            mathmlBuilder: function(e, t) {
              var r = !1, n, s;
              e.base && e.base.type === "horizBrace" && (s = !!e.sup, s === e.base.isOver && (r = !0, n = e.base.isOver)), e.base && (e.base.type === "op" || e.base.type === "operatorname") && (e.base.parentIsSupSub = !0);
              var f = [Oe(e.base, t)];
              e.sub && f.push(Oe(e.sub, t)), e.sup && f.push(Oe(e.sup, t));
              var g;
              if (r)
                g = n ? "mover" : "munder";
              else if (e.sub)
                if (e.sup) {
                  var E = e.base;
                  E && E.type === "op" && E.limits && t.style === K.DISPLAY || E && E.type === "operatorname" && E.alwaysHandleSupSub && (t.style === K.DISPLAY || E.limits) ? g = "munderover" : g = "msubsup";
                } else {
                  var x = e.base;
                  x && x.type === "op" && x.limits && (t.style === K.DISPLAY || x.alwaysHandleSupSub) || x && x.type === "operatorname" && x.alwaysHandleSupSub && (x.limits || t.style === K.DISPLAY) ? g = "munder" : g = "msub";
                }
              else {
                var w = e.base;
                w && w.type === "op" && w.limits && (t.style === K.DISPLAY || w.alwaysHandleSupSub) || w && w.type === "operatorname" && w.alwaysHandleSupSub && (w.limits || t.style === K.DISPLAY) ? g = "mover" : g = "msup";
              }
              return new Y.MathNode(g, f);
            }
          }), O0({
            type: "atom",
            htmlBuilder: function(e, t) {
              return N.mathsym(e.text, e.mode, t, ["m" + e.family]);
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mo", [St(e.text, e.mode)]);
              if (e.family === "bin") {
                var n = On(e, t);
                n === "bold-italic" && r.setAttribute("mathvariant", n);
              } else
                e.family === "punct" ? r.setAttribute("separator", "true") : (e.family === "open" || e.family === "close") && r.setAttribute("stretchy", "false");
              return r;
            }
          });
          var Ui = {
            mi: "italic",
            mn: "normal",
            mtext: "normal"
          };
          O0({
            type: "mathord",
            htmlBuilder: function(e, t) {
              return N.makeOrd(e, t, "mathord");
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mi", [St(e.text, e.mode, t)]), n = On(e, t) || "italic";
              return n !== Ui[r.type] && r.setAttribute("mathvariant", n), r;
            }
          }), O0({
            type: "textord",
            htmlBuilder: function(e, t) {
              return N.makeOrd(e, t, "textord");
            },
            mathmlBuilder: function(e, t) {
              var r = St(e.text, e.mode, t), n = On(e, t) || "normal", s;
              return e.mode === "text" ? s = new Y.MathNode("mtext", [r]) : /[0-9]/.test(e.text) ? s = new Y.MathNode("mn", [r]) : e.text === "\\prime" ? s = new Y.MathNode("mo", [r]) : s = new Y.MathNode("mi", [r]), n !== Ui[s.type] && s.setAttribute("mathvariant", n), s;
            }
          });
          var ra = {
            "\\nobreak": "nobreak",
            "\\allowbreak": "allowbreak"
          }, na = {
            " ": {},
            "\\ ": {},
            "~": {
              className: "nobreak"
            },
            "\\space": {},
            "\\nobreakspace": {
              className: "nobreak"
            }
          };
          O0({
            type: "spacing",
            htmlBuilder: function(e, t) {
              if (na.hasOwnProperty(e.text)) {
                var r = na[e.text].className || "";
                if (e.mode === "text") {
                  var n = N.makeOrd(e, t, "textord");
                  return n.classes.push(r), n;
                } else
                  return N.makeSpan(["mspace", r], [N.mathsym(e.text, e.mode, t)], t);
              } else {
                if (ra.hasOwnProperty(e.text))
                  return N.makeSpan(["mspace", ra[e.text]], [], t);
                throw new c('Unknown type of space "' + e.text + '"');
              }
            },
            mathmlBuilder: function(e, t) {
              var r;
              if (na.hasOwnProperty(e.text))
                r = new Y.MathNode("mtext", [new Y.TextNode(" ")]);
              else {
                if (ra.hasOwnProperty(e.text))
                  return new Y.MathNode("mspace");
                throw new c('Unknown type of space "' + e.text + '"');
              }
              return r;
            }
          });
          var Gi = function() {
            var e = new Y.MathNode("mtd", []);
            return e.setAttribute("width", "50%"), e;
          };
          O0({
            type: "tag",
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mtable", [new Y.MathNode("mtr", [Gi(), new Y.MathNode("mtd", [d0(e.body, t)]), Gi(), new Y.MathNode("mtd", [d0(e.tag, t)])])]);
              return r.setAttribute("width", "100%"), r;
            }
          });
          var Vi = {
            "\\text": void 0,
            "\\textrm": "textrm",
            "\\textsf": "textsf",
            "\\texttt": "texttt",
            "\\textnormal": "textrm"
          }, Wi = {
            "\\textbf": "textbf",
            "\\textmd": "textmd"
          }, hu = {
            "\\textit": "textit",
            "\\textup": "textup"
          }, Yi = function(e, t) {
            var r = e.font;
            return r ? Vi[r] ? t.withTextFontFamily(Vi[r]) : Wi[r] ? t.withTextFontWeight(Wi[r]) : t.withTextFontShape(hu[r]) : t;
          };
          ne({
            type: "text",
            names: [
              // Font families
              "\\text",
              "\\textrm",
              "\\textsf",
              "\\texttt",
              "\\textnormal",
              // Font weights
              "\\textbf",
              "\\textmd",
              // Font Shapes
              "\\textit",
              "\\textup"
            ],
            props: {
              numArgs: 1,
              argTypes: ["text"],
              allowedInArgument: !0,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser, n = e.funcName, s = t[0];
              return {
                type: "text",
                mode: r.mode,
                body: Ze(s),
                font: n
              };
            },
            htmlBuilder: function(e, t) {
              var r = Yi(e, t), n = $e(e.body, r, !0);
              return N.makeSpan(["mord", "text"], n, r);
            },
            mathmlBuilder: function(e, t) {
              var r = Yi(e, t);
              return d0(e.body, r);
            }
          }), ne({
            type: "underline",
            names: ["\\underline"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, t) {
              var r = e.parser;
              return {
                type: "underline",
                mode: r.mode,
                body: t[0]
              };
            },
            htmlBuilder: function(e, t) {
              var r = Se(e.body, t), n = N.makeLineSpan("underline-line", t), s = t.fontMetrics().defaultRuleThickness, f = N.makeVList({
                positionType: "top",
                positionData: r.height,
                children: [{
                  type: "kern",
                  size: s
                }, {
                  type: "elem",
                  elem: n
                }, {
                  type: "kern",
                  size: 3 * s
                }, {
                  type: "elem",
                  elem: r
                }]
              }, t);
              return N.makeSpan(["mord", "underline"], [f], t);
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.MathNode("mo", [new Y.TextNode("‾")]);
              r.setAttribute("stretchy", "true");
              var n = new Y.MathNode("munder", [Oe(e.body, t), r]);
              return n.setAttribute("accentunder", "true"), n;
            }
          }), ne({
            type: "vcenter",
            names: ["\\vcenter"],
            props: {
              numArgs: 1,
              argTypes: ["original"],
              // In LaTeX, \vcenter can act only on a box.
              allowedInText: !1
            },
            handler: function(e, t) {
              var r = e.parser;
              return {
                type: "vcenter",
                mode: r.mode,
                body: t[0]
              };
            },
            htmlBuilder: function(e, t) {
              var r = Se(e.body, t), n = t.fontMetrics().axisHeight, s = 0.5 * (r.height - n - (r.depth + n));
              return N.makeVList({
                positionType: "shift",
                positionData: s,
                children: [{
                  type: "elem",
                  elem: r
                }]
              }, t);
            },
            mathmlBuilder: function(e, t) {
              return new Y.MathNode("mpadded", [Oe(e.body, t)], ["vcenter"]);
            }
          }), ne({
            type: "verb",
            names: ["\\verb"],
            props: {
              numArgs: 0,
              allowedInText: !0
            },
            handler: function(e, t, r) {
              throw new c("\\verb ended by end of line instead of matching delimiter");
            },
            htmlBuilder: function(e, t) {
              for (var r = Xi(e), n = [], s = t.havingStyle(t.style.text()), f = 0; f < r.length; f++) {
                var g = r[f];
                g === "~" && (g = "\\textasciitilde"), n.push(N.makeSymbol(g, "Typewriter-Regular", e.mode, s, ["mord", "texttt"]));
              }
              return N.makeSpan(["mord", "text"].concat(s.sizingClasses(t)), N.tryCombineChars(n), s);
            },
            mathmlBuilder: function(e, t) {
              var r = new Y.TextNode(Xi(e)), n = new Y.MathNode("mtext", [r]);
              return n.setAttribute("mathvariant", "monospace"), n;
            }
          });
          var Xi = function(e) {
            return e.body.replace(/ /g, e.star ? "␣" : " ");
          }, fu = Qa, v0 = fu, ji = `[ \r
	]`, mu = "\\\\[a-zA-Z@]+", du = "\\\\[^\uD800-\uDFFF]", pu = "(" + mu + ")" + ji + "*", gu = `\\\\(
|[ \r	]+
?)[ \r	]*`, aa = "[̀-ͯ]", vu = new RegExp(aa + "+$"), bu = "(" + ji + "+)|" + // whitespace
          (gu + "|") + // \whitespace
          "([!-\\[\\]-‧‪-퟿豈-￿]" + // single codepoint
          (aa + "*") + // ...plus accents
          "|[\uD800-\uDBFF][\uDC00-\uDFFF]" + // surrogate pair
          (aa + "*") + // ...plus accents
          "|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + // \verb unstarred
          ("|" + pu) + // \macroName + spaces
          ("|" + du + ")"), Zi = /* @__PURE__ */ function() {
            function h(t, r) {
              this.input = void 0, this.settings = void 0, this.tokenRegex = void 0, this.catcodes = void 0, this.input = t, this.settings = r, this.tokenRegex = new RegExp(bu, "g"), this.catcodes = {
                "%": 14,
                // comment character
                "~": 13
                // active character
              };
            }
            var e = h.prototype;
            return e.setCatcode = function(r, n) {
              this.catcodes[r] = n;
            }, e.lex = function() {
              var r = this.input, n = this.tokenRegex.lastIndex;
              if (n === r.length)
                return new p0("EOF", new Nt(this, n, n));
              var s = this.tokenRegex.exec(r);
              if (s === null || s.index !== n)
                throw new c("Unexpected character: '" + r[n] + "'", new p0(r[n], new Nt(this, n, n + 1)));
              var f = s[6] || s[3] || (s[2] ? "\\ " : " ");
              if (this.catcodes[f] === 14) {
                var g = r.indexOf(`
`, this.tokenRegex.lastIndex);
                return g === -1 ? (this.tokenRegex.lastIndex = r.length, this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)")) : this.tokenRegex.lastIndex = g + 1, this.lex();
              }
              return new p0(f, new Nt(this, n, this.tokenRegex.lastIndex));
            }, h;
          }(), yu = /* @__PURE__ */ function() {
            function h(t, r) {
              t === void 0 && (t = {}), r === void 0 && (r = {}), this.current = void 0, this.builtins = void 0, this.undefStack = void 0, this.current = r, this.builtins = t, this.undefStack = [];
            }
            var e = h.prototype;
            return e.beginGroup = function() {
              this.undefStack.push({});
            }, e.endGroup = function() {
              if (this.undefStack.length === 0)
                throw new c("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
              var r = this.undefStack.pop();
              for (var n in r)
                r.hasOwnProperty(n) && (r[n] == null ? delete this.current[n] : this.current[n] = r[n]);
            }, e.endGroups = function() {
              for (; this.undefStack.length > 0; )
                this.endGroup();
            }, e.has = function(r) {
              return this.current.hasOwnProperty(r) || this.builtins.hasOwnProperty(r);
            }, e.get = function(r) {
              return this.current.hasOwnProperty(r) ? this.current[r] : this.builtins[r];
            }, e.set = function(r, n, s) {
              if (s === void 0 && (s = !1), s) {
                for (var f = 0; f < this.undefStack.length; f++)
                  delete this.undefStack[f][r];
                this.undefStack.length > 0 && (this.undefStack[this.undefStack.length - 1][r] = n);
              } else {
                var g = this.undefStack[this.undefStack.length - 1];
                g && !g.hasOwnProperty(r) && (g[r] = this.current[r]);
              }
              n == null ? delete this.current[r] : this.current[r] = n;
            }, h;
          }(), wu = Ai, ku = wu;
          k("\\noexpand", function(h) {
            var e = h.popToken();
            return h.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
              tokens: [e],
              numArgs: 0
            };
          }), k("\\expandafter", function(h) {
            var e = h.popToken();
            return h.expandOnce(!0), {
              tokens: [e],
              numArgs: 0
            };
          }), k("\\@firstoftwo", function(h) {
            var e = h.consumeArgs(2);
            return {
              tokens: e[0],
              numArgs: 0
            };
          }), k("\\@secondoftwo", function(h) {
            var e = h.consumeArgs(2);
            return {
              tokens: e[1],
              numArgs: 0
            };
          }), k("\\@ifnextchar", function(h) {
            var e = h.consumeArgs(3);
            h.consumeSpaces();
            var t = h.future();
            return e[0].length === 1 && e[0][0].text === t.text ? {
              tokens: e[1],
              numArgs: 0
            } : {
              tokens: e[2],
              numArgs: 0
            };
          }), k("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}"), k("\\TextOrMath", function(h) {
            var e = h.consumeArgs(2);
            return h.mode === "text" ? {
              tokens: e[0],
              numArgs: 0
            } : {
              tokens: e[1],
              numArgs: 0
            };
          });
          var Ki = {
            0: 0,
            1: 1,
            2: 2,
            3: 3,
            4: 4,
            5: 5,
            6: 6,
            7: 7,
            8: 8,
            9: 9,
            a: 10,
            A: 10,
            b: 11,
            B: 11,
            c: 12,
            C: 12,
            d: 13,
            D: 13,
            e: 14,
            E: 14,
            f: 15,
            F: 15
          };
          k("\\char", function(h) {
            var e = h.popToken(), t, r = "";
            if (e.text === "'")
              t = 8, e = h.popToken();
            else if (e.text === '"')
              t = 16, e = h.popToken();
            else if (e.text === "`")
              if (e = h.popToken(), e.text[0] === "\\")
                r = e.text.charCodeAt(1);
              else {
                if (e.text === "EOF")
                  throw new c("\\char` missing argument");
                r = e.text.charCodeAt(0);
              }
            else
              t = 10;
            if (t) {
              if (r = Ki[e.text], r == null || r >= t)
                throw new c("Invalid base-" + t + " digit " + e.text);
              for (var n; (n = Ki[h.future().text]) != null && n < t; )
                r *= t, r += n, h.popToken();
            }
            return "\\@char{" + r + "}";
          });
          var ia = function(e, t, r) {
            var n = e.consumeArg().tokens;
            if (n.length !== 1)
              throw new c("\\newcommand's first argument must be a macro name");
            var s = n[0].text, f = e.isDefined(s);
            if (f && !t)
              throw new c("\\newcommand{" + s + "} attempting to redefine " + (s + "; use \\renewcommand"));
            if (!f && !r)
              throw new c("\\renewcommand{" + s + "} when command " + s + " does not yet exist; use \\newcommand");
            var g = 0;
            if (n = e.consumeArg().tokens, n.length === 1 && n[0].text === "[") {
              for (var w = "", x = e.expandNextToken(); x.text !== "]" && x.text !== "EOF"; )
                w += x.text, x = e.expandNextToken();
              if (!w.match(/^\s*[0-9]+\s*$/))
                throw new c("Invalid number of arguments: " + w);
              g = parseInt(w), n = e.consumeArg().tokens;
            }
            return e.macros.set(s, {
              tokens: n,
              numArgs: g
            }), "";
          };
          k("\\newcommand", function(h) {
            return ia(h, !1, !0);
          }), k("\\renewcommand", function(h) {
            return ia(h, !0, !1);
          }), k("\\providecommand", function(h) {
            return ia(h, !0, !0);
          }), k("\\message", function(h) {
            var e = h.consumeArgs(1)[0];
            return console.log(e.reverse().map(function(t) {
              return t.text;
            }).join("")), "";
          }), k("\\errmessage", function(h) {
            var e = h.consumeArgs(1)[0];
            return console.error(e.reverse().map(function(t) {
              return t.text;
            }).join("")), "";
          }), k("\\show", function(h) {
            var e = h.popToken(), t = e.text;
            return console.log(e, h.macros.get(t), v0[t], qe.math[t], qe.text[t]), "";
          }), k("\\bgroup", "{"), k("\\egroup", "}"), k("~", "\\nobreakspace"), k("\\lq", "`"), k("\\rq", "'"), k("\\aa", "\\r a"), k("\\AA", "\\r A"), k("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}"), k("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}"), k("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}"), k("ℬ", "\\mathscr{B}"), k("ℰ", "\\mathscr{E}"), k("ℱ", "\\mathscr{F}"), k("ℋ", "\\mathscr{H}"), k("ℐ", "\\mathscr{I}"), k("ℒ", "\\mathscr{L}"), k("ℳ", "\\mathscr{M}"), k("ℛ", "\\mathscr{R}"), k("ℭ", "\\mathfrak{C}"), k("ℌ", "\\mathfrak{H}"), k("ℨ", "\\mathfrak{Z}"), k("\\Bbbk", "\\Bbb{k}"), k("·", "\\cdotp"), k("\\llap", "\\mathllap{\\textrm{#1}}"), k("\\rlap", "\\mathrlap{\\textrm{#1}}"), k("\\clap", "\\mathclap{\\textrm{#1}}"), k("\\mathstrut", "\\vphantom{(}"), k("\\underbar", "\\underline{\\text{#1}}"), k("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}'), k("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}"), k("\\ne", "\\neq"), k("≠", "\\neq"), k("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}"), k("∉", "\\notin"), k("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}"), k("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}"), k("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}"), k("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}"), k("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}"), k("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}"), k("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}"), k("⟂", "\\perp"), k("‼", "\\mathclose{!\\mkern-0.8mu!}"), k("∌", "\\notni"), k("⌜", "\\ulcorner"), k("⌝", "\\urcorner"), k("⌞", "\\llcorner"), k("⌟", "\\lrcorner"), k("©", "\\copyright"), k("®", "\\textregistered"), k("️", "\\textregistered"), k("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}'), k("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}'), k("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}'), k("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}'), k("\\vdots", "\\mathord{\\varvdots\\rule{0pt}{15pt}}"), k("⋮", "\\vdots"), k("\\varGamma", "\\mathit{\\Gamma}"), k("\\varDelta", "\\mathit{\\Delta}"), k("\\varTheta", "\\mathit{\\Theta}"), k("\\varLambda", "\\mathit{\\Lambda}"), k("\\varXi", "\\mathit{\\Xi}"), k("\\varPi", "\\mathit{\\Pi}"), k("\\varSigma", "\\mathit{\\Sigma}"), k("\\varUpsilon", "\\mathit{\\Upsilon}"), k("\\varPhi", "\\mathit{\\Phi}"), k("\\varPsi", "\\mathit{\\Psi}"), k("\\varOmega", "\\mathit{\\Omega}"), k("\\substack", "\\begin{subarray}{c}#1\\end{subarray}"), k("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax"), k("\\boxed", "\\fbox{$\\displaystyle{#1}$}"), k("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;"), k("\\implies", "\\DOTSB\\;\\Longrightarrow\\;"), k("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
          var Qi = {
            ",": "\\dotsc",
            "\\not": "\\dotsb",
            // \keybin@ checks for the following:
            "+": "\\dotsb",
            "=": "\\dotsb",
            "<": "\\dotsb",
            ">": "\\dotsb",
            "-": "\\dotsb",
            "*": "\\dotsb",
            ":": "\\dotsb",
            // Symbols whose definition starts with \DOTSB:
            "\\DOTSB": "\\dotsb",
            "\\coprod": "\\dotsb",
            "\\bigvee": "\\dotsb",
            "\\bigwedge": "\\dotsb",
            "\\biguplus": "\\dotsb",
            "\\bigcap": "\\dotsb",
            "\\bigcup": "\\dotsb",
            "\\prod": "\\dotsb",
            "\\sum": "\\dotsb",
            "\\bigotimes": "\\dotsb",
            "\\bigoplus": "\\dotsb",
            "\\bigodot": "\\dotsb",
            "\\bigsqcup": "\\dotsb",
            "\\And": "\\dotsb",
            "\\longrightarrow": "\\dotsb",
            "\\Longrightarrow": "\\dotsb",
            "\\longleftarrow": "\\dotsb",
            "\\Longleftarrow": "\\dotsb",
            "\\longleftrightarrow": "\\dotsb",
            "\\Longleftrightarrow": "\\dotsb",
            "\\mapsto": "\\dotsb",
            "\\longmapsto": "\\dotsb",
            "\\hookrightarrow": "\\dotsb",
            "\\doteq": "\\dotsb",
            // Symbols whose definition starts with \mathbin:
            "\\mathbin": "\\dotsb",
            // Symbols whose definition starts with \mathrel:
            "\\mathrel": "\\dotsb",
            "\\relbar": "\\dotsb",
            "\\Relbar": "\\dotsb",
            "\\xrightarrow": "\\dotsb",
            "\\xleftarrow": "\\dotsb",
            // Symbols whose definition starts with \DOTSI:
            "\\DOTSI": "\\dotsi",
            "\\int": "\\dotsi",
            "\\oint": "\\dotsi",
            "\\iint": "\\dotsi",
            "\\iiint": "\\dotsi",
            "\\iiiint": "\\dotsi",
            "\\idotsint": "\\dotsi",
            // Symbols whose definition starts with \DOTSX:
            "\\DOTSX": "\\dotsx"
          };
          k("\\dots", function(h) {
            var e = "\\dotso", t = h.expandAfterFuture().text;
            return t in Qi ? e = Qi[t] : (t.slice(0, 4) === "\\not" || t in qe.math && L.contains(["bin", "rel"], qe.math[t].group)) && (e = "\\dotsb"), e;
          });
          var la = {
            // \rightdelim@ checks for the following:
            ")": !0,
            "]": !0,
            "\\rbrack": !0,
            "\\}": !0,
            "\\rbrace": !0,
            "\\rangle": !0,
            "\\rceil": !0,
            "\\rfloor": !0,
            "\\rgroup": !0,
            "\\rmoustache": !0,
            "\\right": !0,
            "\\bigr": !0,
            "\\biggr": !0,
            "\\Bigr": !0,
            "\\Biggr": !0,
            // \extra@ also tests for the following:
            $: !0,
            // \extrap@ checks for the following:
            ";": !0,
            ".": !0,
            ",": !0
          };
          k("\\dotso", function(h) {
            var e = h.future().text;
            return e in la ? "\\ldots\\," : "\\ldots";
          }), k("\\dotsc", function(h) {
            var e = h.future().text;
            return e in la && e !== "," ? "\\ldots\\," : "\\ldots";
          }), k("\\cdots", function(h) {
            var e = h.future().text;
            return e in la ? "\\@cdots\\," : "\\@cdots";
          }), k("\\dotsb", "\\cdots"), k("\\dotsm", "\\cdots"), k("\\dotsi", "\\!\\cdots"), k("\\dotsx", "\\ldots\\,"), k("\\DOTSI", "\\relax"), k("\\DOTSB", "\\relax"), k("\\DOTSX", "\\relax"), k("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax"), k("\\,", "\\tmspace+{3mu}{.1667em}"), k("\\thinspace", "\\,"), k("\\>", "\\mskip{4mu}"), k("\\:", "\\tmspace+{4mu}{.2222em}"), k("\\medspace", "\\:"), k("\\;", "\\tmspace+{5mu}{.2777em}"), k("\\thickspace", "\\;"), k("\\!", "\\tmspace-{3mu}{.1667em}"), k("\\negthinspace", "\\!"), k("\\negmedspace", "\\tmspace-{4mu}{.2222em}"), k("\\negthickspace", "\\tmspace-{5mu}{.277em}"), k("\\enspace", "\\kern.5em "), k("\\enskip", "\\hskip.5em\\relax"), k("\\quad", "\\hskip1em\\relax"), k("\\qquad", "\\hskip2em\\relax"), k("\\tag", "\\@ifstar\\tag@literal\\tag@paren"), k("\\tag@paren", "\\tag@literal{({#1})}"), k("\\tag@literal", function(h) {
            if (h.macros.get("\\df@tag"))
              throw new c("Multiple \\tag");
            return "\\gdef\\df@tag{\\text{#1}}";
          }), k("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}"), k("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)"), k("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}"), k("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1"), k("\\newline", "\\\\\\relax"), k("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
          var Ji = J(xt["Main-Regular"]["T".charCodeAt(0)][1] - 0.7 * xt["Main-Regular"]["A".charCodeAt(0)][1]);
          k("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + Ji + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}"), k("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + Ji + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}"), k("\\hspace", "\\@ifstar\\@hspacer\\@hspace"), k("\\@hspace", "\\hskip #1\\relax"), k("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax"), k("\\ordinarycolon", ":"), k("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}"), k("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}'), k("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}'), k("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}'), k("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}'), k("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}'), k("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}'), k("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}'), k("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}'), k("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}'), k("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}'), k("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}'), k("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}'), k("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}'), k("∷", "\\dblcolon"), k("∹", "\\eqcolon"), k("≔", "\\coloneqq"), k("≕", "\\eqqcolon"), k("⩴", "\\Coloneqq"), k("\\ratio", "\\vcentcolon"), k("\\coloncolon", "\\dblcolon"), k("\\colonequals", "\\coloneqq"), k("\\coloncolonequals", "\\Coloneqq"), k("\\equalscolon", "\\eqqcolon"), k("\\equalscoloncolon", "\\Eqqcolon"), k("\\colonminus", "\\coloneq"), k("\\coloncolonminus", "\\Coloneq"), k("\\minuscolon", "\\eqcolon"), k("\\minuscoloncolon", "\\Eqcolon"), k("\\coloncolonapprox", "\\Colonapprox"), k("\\coloncolonsim", "\\Colonsim"), k("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}"), k("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}"), k("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}"), k("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}"), k("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}"), k("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}"), k("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}"), k("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}"), k("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}"), k("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}"), k("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}"), k("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}"), k("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}"), k("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}"), k("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}"), k("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}"), k("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}"), k("\\nleqq", "\\html@mathml{\\@nleqq}{≰}"), k("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}"), k("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}"), k("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}"), k("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}"), k("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}"), k("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}"), k("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}"), k("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}"), k("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}"), k("\\imath", "\\html@mathml{\\@imath}{ı}"), k("\\jmath", "\\html@mathml{\\@jmath}{ȷ}"), k("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}"), k("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}"), k("⟦", "\\llbracket"), k("⟧", "\\rrbracket"), k("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}"), k("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}"), k("⦃", "\\lBrace"), k("⦄", "\\rBrace"), k("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}"), k("⦵", "\\minuso"), k("\\darr", "\\downarrow"), k("\\dArr", "\\Downarrow"), k("\\Darr", "\\Downarrow"), k("\\lang", "\\langle"), k("\\rang", "\\rangle"), k("\\uarr", "\\uparrow"), k("\\uArr", "\\Uparrow"), k("\\Uarr", "\\Uparrow"), k("\\N", "\\mathbb{N}"), k("\\R", "\\mathbb{R}"), k("\\Z", "\\mathbb{Z}"), k("\\alef", "\\aleph"), k("\\alefsym", "\\aleph"), k("\\Alpha", "\\mathrm{A}"), k("\\Beta", "\\mathrm{B}"), k("\\bull", "\\bullet"), k("\\Chi", "\\mathrm{X}"), k("\\clubs", "\\clubsuit"), k("\\cnums", "\\mathbb{C}"), k("\\Complex", "\\mathbb{C}"), k("\\Dagger", "\\ddagger"), k("\\diamonds", "\\diamondsuit"), k("\\empty", "\\emptyset"), k("\\Epsilon", "\\mathrm{E}"), k("\\Eta", "\\mathrm{H}"), k("\\exist", "\\exists"), k("\\harr", "\\leftrightarrow"), k("\\hArr", "\\Leftrightarrow"), k("\\Harr", "\\Leftrightarrow"), k("\\hearts", "\\heartsuit"), k("\\image", "\\Im"), k("\\infin", "\\infty"), k("\\Iota", "\\mathrm{I}"), k("\\isin", "\\in"), k("\\Kappa", "\\mathrm{K}"), k("\\larr", "\\leftarrow"), k("\\lArr", "\\Leftarrow"), k("\\Larr", "\\Leftarrow"), k("\\lrarr", "\\leftrightarrow"), k("\\lrArr", "\\Leftrightarrow"), k("\\Lrarr", "\\Leftrightarrow"), k("\\Mu", "\\mathrm{M}"), k("\\natnums", "\\mathbb{N}"), k("\\Nu", "\\mathrm{N}"), k("\\Omicron", "\\mathrm{O}"), k("\\plusmn", "\\pm"), k("\\rarr", "\\rightarrow"), k("\\rArr", "\\Rightarrow"), k("\\Rarr", "\\Rightarrow"), k("\\real", "\\Re"), k("\\reals", "\\mathbb{R}"), k("\\Reals", "\\mathbb{R}"), k("\\Rho", "\\mathrm{P}"), k("\\sdot", "\\cdot"), k("\\sect", "\\S"), k("\\spades", "\\spadesuit"), k("\\sub", "\\subset"), k("\\sube", "\\subseteq"), k("\\supe", "\\supseteq"), k("\\Tau", "\\mathrm{T}"), k("\\thetasym", "\\vartheta"), k("\\weierp", "\\wp"), k("\\Zeta", "\\mathrm{Z}"), k("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}"), k("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}"), k("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits"), k("\\bra", "\\mathinner{\\langle{#1}|}"), k("\\ket", "\\mathinner{|{#1}\\rangle}"), k("\\braket", "\\mathinner{\\langle{#1}\\rangle}"), k("\\Bra", "\\left\\langle#1\\right|"), k("\\Ket", "\\left|#1\\right\\rangle");
          var $i = function(e) {
            return function(t) {
              var r = t.consumeArg().tokens, n = t.consumeArg().tokens, s = t.consumeArg().tokens, f = t.consumeArg().tokens, g = t.macros.get("|"), w = t.macros.get("\\|");
              t.macros.beginGroup();
              var x = function(O) {
                return function(U) {
                  e && (U.macros.set("|", g), s.length && U.macros.set("\\|", w));
                  var Q = O;
                  if (!O && s.length) {
                    var ee = U.future();
                    ee.text === "|" && (U.popToken(), Q = !0);
                  }
                  return {
                    tokens: Q ? s : n,
                    numArgs: 0
                  };
                };
              };
              t.macros.set("|", x(!1)), s.length && t.macros.set("\\|", x(!0));
              var E = t.consumeArg().tokens, z = t.expandTokens([].concat(f, E, r));
              return t.macros.endGroup(), {
                tokens: z.reverse(),
                numArgs: 0
              };
            };
          };
          k("\\bra@ket", $i(!1)), k("\\bra@set", $i(!0)), k("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}"), k("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}"), k("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}"), k("\\angln", "{\\angl n}"), k("\\blue", "\\textcolor{##6495ed}{#1}"), k("\\orange", "\\textcolor{##ffa500}{#1}"), k("\\pink", "\\textcolor{##ff00af}{#1}"), k("\\red", "\\textcolor{##df0030}{#1}"), k("\\green", "\\textcolor{##28ae7b}{#1}"), k("\\gray", "\\textcolor{gray}{#1}"), k("\\purple", "\\textcolor{##9d38bd}{#1}"), k("\\blueA", "\\textcolor{##ccfaff}{#1}"), k("\\blueB", "\\textcolor{##80f6ff}{#1}"), k("\\blueC", "\\textcolor{##63d9ea}{#1}"), k("\\blueD", "\\textcolor{##11accd}{#1}"), k("\\blueE", "\\textcolor{##0c7f99}{#1}"), k("\\tealA", "\\textcolor{##94fff5}{#1}"), k("\\tealB", "\\textcolor{##26edd5}{#1}"), k("\\tealC", "\\textcolor{##01d1c1}{#1}"), k("\\tealD", "\\textcolor{##01a995}{#1}"), k("\\tealE", "\\textcolor{##208170}{#1}"), k("\\greenA", "\\textcolor{##b6ffb0}{#1}"), k("\\greenB", "\\textcolor{##8af281}{#1}"), k("\\greenC", "\\textcolor{##74cf70}{#1}"), k("\\greenD", "\\textcolor{##1fab54}{#1}"), k("\\greenE", "\\textcolor{##0d923f}{#1}"), k("\\goldA", "\\textcolor{##ffd0a9}{#1}"), k("\\goldB", "\\textcolor{##ffbb71}{#1}"), k("\\goldC", "\\textcolor{##ff9c39}{#1}"), k("\\goldD", "\\textcolor{##e07d10}{#1}"), k("\\goldE", "\\textcolor{##a75a05}{#1}"), k("\\redA", "\\textcolor{##fca9a9}{#1}"), k("\\redB", "\\textcolor{##ff8482}{#1}"), k("\\redC", "\\textcolor{##f9685d}{#1}"), k("\\redD", "\\textcolor{##e84d39}{#1}"), k("\\redE", "\\textcolor{##bc2612}{#1}"), k("\\maroonA", "\\textcolor{##ffbde0}{#1}"), k("\\maroonB", "\\textcolor{##ff92c6}{#1}"), k("\\maroonC", "\\textcolor{##ed5fa6}{#1}"), k("\\maroonD", "\\textcolor{##ca337c}{#1}"), k("\\maroonE", "\\textcolor{##9e034e}{#1}"), k("\\purpleA", "\\textcolor{##ddd7ff}{#1}"), k("\\purpleB", "\\textcolor{##c6b9fc}{#1}"), k("\\purpleC", "\\textcolor{##aa87ff}{#1}"), k("\\purpleD", "\\textcolor{##7854ab}{#1}"), k("\\purpleE", "\\textcolor{##543b78}{#1}"), k("\\mintA", "\\textcolor{##f5f9e8}{#1}"), k("\\mintB", "\\textcolor{##edf2df}{#1}"), k("\\mintC", "\\textcolor{##e0e5cc}{#1}"), k("\\grayA", "\\textcolor{##f6f7f7}{#1}"), k("\\grayB", "\\textcolor{##f0f1f2}{#1}"), k("\\grayC", "\\textcolor{##e3e5e6}{#1}"), k("\\grayD", "\\textcolor{##d6d8da}{#1}"), k("\\grayE", "\\textcolor{##babec2}{#1}"), k("\\grayF", "\\textcolor{##888d93}{#1}"), k("\\grayG", "\\textcolor{##626569}{#1}"), k("\\grayH", "\\textcolor{##3b3e40}{#1}"), k("\\grayI", "\\textcolor{##21242c}{#1}"), k("\\kaBlue", "\\textcolor{##314453}{#1}"), k("\\kaGreen", "\\textcolor{##71B307}{#1}");
          var el = {
            "^": !0,
            // Parser.js
            _: !0,
            // Parser.js
            "\\limits": !0,
            // Parser.js
            "\\nolimits": !0
            // Parser.js
          }, xu = /* @__PURE__ */ function() {
            function h(t, r, n) {
              this.settings = void 0, this.expansionCount = void 0, this.lexer = void 0, this.macros = void 0, this.stack = void 0, this.mode = void 0, this.settings = r, this.expansionCount = 0, this.feed(t), this.macros = new yu(ku, r.macros), this.mode = n, this.stack = [];
            }
            var e = h.prototype;
            return e.feed = function(r) {
              this.lexer = new Zi(r, this.settings);
            }, e.switchMode = function(r) {
              this.mode = r;
            }, e.beginGroup = function() {
              this.macros.beginGroup();
            }, e.endGroup = function() {
              this.macros.endGroup();
            }, e.endGroups = function() {
              this.macros.endGroups();
            }, e.future = function() {
              return this.stack.length === 0 && this.pushToken(this.lexer.lex()), this.stack[this.stack.length - 1];
            }, e.popToken = function() {
              return this.future(), this.stack.pop();
            }, e.pushToken = function(r) {
              this.stack.push(r);
            }, e.pushTokens = function(r) {
              var n;
              (n = this.stack).push.apply(n, r);
            }, e.scanArgument = function(r) {
              var n, s, f;
              if (r) {
                if (this.consumeSpaces(), this.future().text !== "[")
                  return null;
                n = this.popToken();
                var g = this.consumeArg(["]"]);
                f = g.tokens, s = g.end;
              } else {
                var w = this.consumeArg();
                f = w.tokens, n = w.start, s = w.end;
              }
              return this.pushToken(new p0("EOF", s.loc)), this.pushTokens(f), n.range(s, "");
            }, e.consumeSpaces = function() {
              for (; ; ) {
                var r = this.future();
                if (r.text === " ")
                  this.stack.pop();
                else
                  break;
              }
            }, e.consumeArg = function(r) {
              var n = [], s = r && r.length > 0;
              s || this.consumeSpaces();
              var f = this.future(), g, w = 0, x = 0;
              do {
                if (g = this.popToken(), n.push(g), g.text === "{")
                  ++w;
                else if (g.text === "}") {
                  if (--w, w === -1)
                    throw new c("Extra }", g);
                } else if (g.text === "EOF")
                  throw new c("Unexpected end of input in a macro argument, expected '" + (r && s ? r[x] : "}") + "'", g);
                if (r && s)
                  if ((w === 0 || w === 1 && r[x] === "{") && g.text === r[x]) {
                    if (++x, x === r.length) {
                      n.splice(-x, x);
                      break;
                    }
                  } else
                    x = 0;
              } while (w !== 0 || s);
              return f.text === "{" && n[n.length - 1].text === "}" && (n.pop(), n.shift()), n.reverse(), {
                tokens: n,
                start: f,
                end: g
              };
            }, e.consumeArgs = function(r, n) {
              if (n) {
                if (n.length !== r + 1)
                  throw new c("The length of delimiters doesn't match the number of args!");
                for (var s = n[0], f = 0; f < s.length; f++) {
                  var g = this.popToken();
                  if (s[f] !== g.text)
                    throw new c("Use of the macro doesn't match its definition", g);
                }
              }
              for (var w = [], x = 0; x < r; x++)
                w.push(this.consumeArg(n && n[x + 1]).tokens);
              return w;
            }, e.expandOnce = function(r) {
              var n = this.popToken(), s = n.text, f = n.noexpand ? null : this._getExpansion(s);
              if (f == null || r && f.unexpandable) {
                if (r && f == null && s[0] === "\\" && !this.isDefined(s))
                  throw new c("Undefined control sequence: " + s);
                return this.pushToken(n), !1;
              }
              if (this.expansionCount++, this.expansionCount > this.settings.maxExpand)
                throw new c("Too many expansions: infinite loop or need to increase maxExpand setting");
              var g = f.tokens, w = this.consumeArgs(f.numArgs, f.delimiters);
              if (f.numArgs) {
                g = g.slice();
                for (var x = g.length - 1; x >= 0; --x) {
                  var E = g[x];
                  if (E.text === "#") {
                    if (x === 0)
                      throw new c("Incomplete placeholder at end of macro body", E);
                    if (E = g[--x], E.text === "#")
                      g.splice(x + 1, 1);
                    else if (/^[1-9]$/.test(E.text)) {
                      var z;
                      (z = g).splice.apply(z, [x, 2].concat(w[+E.text - 1]));
                    } else
                      throw new c("Not a valid argument number", E);
                  }
                }
              }
              return this.pushTokens(g), g.length;
            }, e.expandAfterFuture = function() {
              return this.expandOnce(), this.future();
            }, e.expandNextToken = function() {
              for (; ; )
                if (this.expandOnce() === !1) {
                  var r = this.stack.pop();
                  return r.treatAsRelax && (r.text = "\\relax"), r;
                }
              throw new Error();
            }, e.expandMacro = function(r) {
              return this.macros.has(r) ? this.expandTokens([new p0(r)]) : void 0;
            }, e.expandTokens = function(r) {
              var n = [], s = this.stack.length;
              for (this.pushTokens(r); this.stack.length > s; )
                if (this.expandOnce(!0) === !1) {
                  var f = this.stack.pop();
                  f.treatAsRelax && (f.noexpand = !1, f.treatAsRelax = !1), n.push(f);
                }
              return n;
            }, e.expandMacroAsText = function(r) {
              var n = this.expandMacro(r);
              return n && n.map(function(s) {
                return s.text;
              }).join("");
            }, e._getExpansion = function(r) {
              var n = this.macros.get(r);
              if (n == null)
                return n;
              if (r.length === 1) {
                var s = this.lexer.catcodes[r];
                if (s != null && s !== 13)
                  return;
              }
              var f = typeof n == "function" ? n(this) : n;
              if (typeof f == "string") {
                var g = 0;
                if (f.indexOf("#") !== -1)
                  for (var w = f.replace(/##/g, ""); w.indexOf("#" + (g + 1)) !== -1; )
                    ++g;
                for (var x = new Zi(f, this.settings), E = [], z = x.lex(); z.text !== "EOF"; )
                  E.push(z), z = x.lex();
                E.reverse();
                var q = {
                  tokens: E,
                  numArgs: g
                };
                return q;
              }
              return f;
            }, e.isDefined = function(r) {
              return this.macros.has(r) || v0.hasOwnProperty(r) || qe.math.hasOwnProperty(r) || qe.text.hasOwnProperty(r) || el.hasOwnProperty(r);
            }, e.isExpandable = function(r) {
              var n = this.macros.get(r);
              return n != null ? typeof n == "string" || typeof n == "function" || !n.unexpandable : v0.hasOwnProperty(r) && !v0[r].primitive;
            }, h;
          }(), tl = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/, $r = Object.freeze({
            "₊": "+",
            "₋": "-",
            "₌": "=",
            "₍": "(",
            "₎": ")",
            "₀": "0",
            "₁": "1",
            "₂": "2",
            "₃": "3",
            "₄": "4",
            "₅": "5",
            "₆": "6",
            "₇": "7",
            "₈": "8",
            "₉": "9",
            "ₐ": "a",
            "ₑ": "e",
            "ₕ": "h",
            "ᵢ": "i",
            "ⱼ": "j",
            "ₖ": "k",
            "ₗ": "l",
            "ₘ": "m",
            "ₙ": "n",
            "ₒ": "o",
            "ₚ": "p",
            "ᵣ": "r",
            "ₛ": "s",
            "ₜ": "t",
            "ᵤ": "u",
            "ᵥ": "v",
            "ₓ": "x",
            "ᵦ": "β",
            "ᵧ": "γ",
            "ᵨ": "ρ",
            "ᵩ": "ϕ",
            "ᵪ": "χ",
            "⁺": "+",
            "⁻": "-",
            "⁼": "=",
            "⁽": "(",
            "⁾": ")",
            "⁰": "0",
            "¹": "1",
            "²": "2",
            "³": "3",
            "⁴": "4",
            "⁵": "5",
            "⁶": "6",
            "⁷": "7",
            "⁸": "8",
            "⁹": "9",
            "ᴬ": "A",
            "ᴮ": "B",
            "ᴰ": "D",
            "ᴱ": "E",
            "ᴳ": "G",
            "ᴴ": "H",
            "ᴵ": "I",
            "ᴶ": "J",
            "ᴷ": "K",
            "ᴸ": "L",
            "ᴹ": "M",
            "ᴺ": "N",
            "ᴼ": "O",
            "ᴾ": "P",
            "ᴿ": "R",
            "ᵀ": "T",
            "ᵁ": "U",
            "ⱽ": "V",
            "ᵂ": "W",
            "ᵃ": "a",
            "ᵇ": "b",
            "ᶜ": "c",
            "ᵈ": "d",
            "ᵉ": "e",
            "ᶠ": "f",
            "ᵍ": "g",
            ʰ: "h",
            "ⁱ": "i",
            ʲ: "j",
            "ᵏ": "k",
            ˡ: "l",
            "ᵐ": "m",
            ⁿ: "n",
            "ᵒ": "o",
            "ᵖ": "p",
            ʳ: "r",
            ˢ: "s",
            "ᵗ": "t",
            "ᵘ": "u",
            "ᵛ": "v",
            ʷ: "w",
            ˣ: "x",
            ʸ: "y",
            "ᶻ": "z",
            "ᵝ": "β",
            "ᵞ": "γ",
            "ᵟ": "δ",
            "ᵠ": "ϕ",
            "ᵡ": "χ",
            "ᶿ": "θ"
          }), sa = {
            "́": {
              text: "\\'",
              math: "\\acute"
            },
            "̀": {
              text: "\\`",
              math: "\\grave"
            },
            "̈": {
              text: '\\"',
              math: "\\ddot"
            },
            "̃": {
              text: "\\~",
              math: "\\tilde"
            },
            "̄": {
              text: "\\=",
              math: "\\bar"
            },
            "̆": {
              text: "\\u",
              math: "\\breve"
            },
            "̌": {
              text: "\\v",
              math: "\\check"
            },
            "̂": {
              text: "\\^",
              math: "\\hat"
            },
            "̇": {
              text: "\\.",
              math: "\\dot"
            },
            "̊": {
              text: "\\r",
              math: "\\mathring"
            },
            "̋": {
              text: "\\H"
            },
            "̧": {
              text: "\\c"
            }
          }, rl = {
            á: "á",
            à: "à",
            ä: "ä",
            ǟ: "ǟ",
            ã: "ã",
            ā: "ā",
            ă: "ă",
            ắ: "ắ",
            ằ: "ằ",
            ẵ: "ẵ",
            ǎ: "ǎ",
            â: "â",
            ấ: "ấ",
            ầ: "ầ",
            ẫ: "ẫ",
            ȧ: "ȧ",
            ǡ: "ǡ",
            å: "å",
            ǻ: "ǻ",
            ḃ: "ḃ",
            ć: "ć",
            ḉ: "ḉ",
            č: "č",
            ĉ: "ĉ",
            ċ: "ċ",
            ç: "ç",
            ď: "ď",
            ḋ: "ḋ",
            ḑ: "ḑ",
            é: "é",
            è: "è",
            ë: "ë",
            ẽ: "ẽ",
            ē: "ē",
            ḗ: "ḗ",
            ḕ: "ḕ",
            ĕ: "ĕ",
            ḝ: "ḝ",
            ě: "ě",
            ê: "ê",
            ế: "ế",
            ề: "ề",
            ễ: "ễ",
            ė: "ė",
            ȩ: "ȩ",
            ḟ: "ḟ",
            ǵ: "ǵ",
            ḡ: "ḡ",
            ğ: "ğ",
            ǧ: "ǧ",
            ĝ: "ĝ",
            ġ: "ġ",
            ģ: "ģ",
            ḧ: "ḧ",
            ȟ: "ȟ",
            ĥ: "ĥ",
            ḣ: "ḣ",
            ḩ: "ḩ",
            í: "í",
            ì: "ì",
            ï: "ï",
            ḯ: "ḯ",
            ĩ: "ĩ",
            ī: "ī",
            ĭ: "ĭ",
            ǐ: "ǐ",
            î: "î",
            ǰ: "ǰ",
            ĵ: "ĵ",
            ḱ: "ḱ",
            ǩ: "ǩ",
            ķ: "ķ",
            ĺ: "ĺ",
            ľ: "ľ",
            ļ: "ļ",
            ḿ: "ḿ",
            ṁ: "ṁ",
            ń: "ń",
            ǹ: "ǹ",
            ñ: "ñ",
            ň: "ň",
            ṅ: "ṅ",
            ņ: "ņ",
            ó: "ó",
            ò: "ò",
            ö: "ö",
            ȫ: "ȫ",
            õ: "õ",
            ṍ: "ṍ",
            ṏ: "ṏ",
            ȭ: "ȭ",
            ō: "ō",
            ṓ: "ṓ",
            ṑ: "ṑ",
            ŏ: "ŏ",
            ǒ: "ǒ",
            ô: "ô",
            ố: "ố",
            ồ: "ồ",
            ỗ: "ỗ",
            ȯ: "ȯ",
            ȱ: "ȱ",
            ő: "ő",
            ṕ: "ṕ",
            ṗ: "ṗ",
            ŕ: "ŕ",
            ř: "ř",
            ṙ: "ṙ",
            ŗ: "ŗ",
            ś: "ś",
            ṥ: "ṥ",
            š: "š",
            ṧ: "ṧ",
            ŝ: "ŝ",
            ṡ: "ṡ",
            ş: "ş",
            ẗ: "ẗ",
            ť: "ť",
            ṫ: "ṫ",
            ţ: "ţ",
            ú: "ú",
            ù: "ù",
            ü: "ü",
            ǘ: "ǘ",
            ǜ: "ǜ",
            ǖ: "ǖ",
            ǚ: "ǚ",
            ũ: "ũ",
            ṹ: "ṹ",
            ū: "ū",
            ṻ: "ṻ",
            ŭ: "ŭ",
            ǔ: "ǔ",
            û: "û",
            ů: "ů",
            ű: "ű",
            ṽ: "ṽ",
            ẃ: "ẃ",
            ẁ: "ẁ",
            ẅ: "ẅ",
            ŵ: "ŵ",
            ẇ: "ẇ",
            ẘ: "ẘ",
            ẍ: "ẍ",
            ẋ: "ẋ",
            ý: "ý",
            ỳ: "ỳ",
            ÿ: "ÿ",
            ỹ: "ỹ",
            ȳ: "ȳ",
            ŷ: "ŷ",
            ẏ: "ẏ",
            ẙ: "ẙ",
            ź: "ź",
            ž: "ž",
            ẑ: "ẑ",
            ż: "ż",
            Á: "Á",
            À: "À",
            Ä: "Ä",
            Ǟ: "Ǟ",
            Ã: "Ã",
            Ā: "Ā",
            Ă: "Ă",
            Ắ: "Ắ",
            Ằ: "Ằ",
            Ẵ: "Ẵ",
            Ǎ: "Ǎ",
            Â: "Â",
            Ấ: "Ấ",
            Ầ: "Ầ",
            Ẫ: "Ẫ",
            Ȧ: "Ȧ",
            Ǡ: "Ǡ",
            Å: "Å",
            Ǻ: "Ǻ",
            Ḃ: "Ḃ",
            Ć: "Ć",
            Ḉ: "Ḉ",
            Č: "Č",
            Ĉ: "Ĉ",
            Ċ: "Ċ",
            Ç: "Ç",
            Ď: "Ď",
            Ḋ: "Ḋ",
            Ḑ: "Ḑ",
            É: "É",
            È: "È",
            Ë: "Ë",
            Ẽ: "Ẽ",
            Ē: "Ē",
            Ḗ: "Ḗ",
            Ḕ: "Ḕ",
            Ĕ: "Ĕ",
            Ḝ: "Ḝ",
            Ě: "Ě",
            Ê: "Ê",
            Ế: "Ế",
            Ề: "Ề",
            Ễ: "Ễ",
            Ė: "Ė",
            Ȩ: "Ȩ",
            Ḟ: "Ḟ",
            Ǵ: "Ǵ",
            Ḡ: "Ḡ",
            Ğ: "Ğ",
            Ǧ: "Ǧ",
            Ĝ: "Ĝ",
            Ġ: "Ġ",
            Ģ: "Ģ",
            Ḧ: "Ḧ",
            Ȟ: "Ȟ",
            Ĥ: "Ĥ",
            Ḣ: "Ḣ",
            Ḩ: "Ḩ",
            Í: "Í",
            Ì: "Ì",
            Ï: "Ï",
            Ḯ: "Ḯ",
            Ĩ: "Ĩ",
            Ī: "Ī",
            Ĭ: "Ĭ",
            Ǐ: "Ǐ",
            Î: "Î",
            İ: "İ",
            Ĵ: "Ĵ",
            Ḱ: "Ḱ",
            Ǩ: "Ǩ",
            Ķ: "Ķ",
            Ĺ: "Ĺ",
            Ľ: "Ľ",
            Ļ: "Ļ",
            Ḿ: "Ḿ",
            Ṁ: "Ṁ",
            Ń: "Ń",
            Ǹ: "Ǹ",
            Ñ: "Ñ",
            Ň: "Ň",
            Ṅ: "Ṅ",
            Ņ: "Ņ",
            Ó: "Ó",
            Ò: "Ò",
            Ö: "Ö",
            Ȫ: "Ȫ",
            Õ: "Õ",
            Ṍ: "Ṍ",
            Ṏ: "Ṏ",
            Ȭ: "Ȭ",
            Ō: "Ō",
            Ṓ: "Ṓ",
            Ṑ: "Ṑ",
            Ŏ: "Ŏ",
            Ǒ: "Ǒ",
            Ô: "Ô",
            Ố: "Ố",
            Ồ: "Ồ",
            Ỗ: "Ỗ",
            Ȯ: "Ȯ",
            Ȱ: "Ȱ",
            Ő: "Ő",
            Ṕ: "Ṕ",
            Ṗ: "Ṗ",
            Ŕ: "Ŕ",
            Ř: "Ř",
            Ṙ: "Ṙ",
            Ŗ: "Ŗ",
            Ś: "Ś",
            Ṥ: "Ṥ",
            Š: "Š",
            Ṧ: "Ṧ",
            Ŝ: "Ŝ",
            Ṡ: "Ṡ",
            Ş: "Ş",
            Ť: "Ť",
            Ṫ: "Ṫ",
            Ţ: "Ţ",
            Ú: "Ú",
            Ù: "Ù",
            Ü: "Ü",
            Ǘ: "Ǘ",
            Ǜ: "Ǜ",
            Ǖ: "Ǖ",
            Ǚ: "Ǚ",
            Ũ: "Ũ",
            Ṹ: "Ṹ",
            Ū: "Ū",
            Ṻ: "Ṻ",
            Ŭ: "Ŭ",
            Ǔ: "Ǔ",
            Û: "Û",
            Ů: "Ů",
            Ű: "Ű",
            Ṽ: "Ṽ",
            Ẃ: "Ẃ",
            Ẁ: "Ẁ",
            Ẅ: "Ẅ",
            Ŵ: "Ŵ",
            Ẇ: "Ẇ",
            Ẍ: "Ẍ",
            Ẋ: "Ẋ",
            Ý: "Ý",
            Ỳ: "Ỳ",
            Ÿ: "Ÿ",
            Ỹ: "Ỹ",
            Ȳ: "Ȳ",
            Ŷ: "Ŷ",
            Ẏ: "Ẏ",
            Ź: "Ź",
            Ž: "Ž",
            Ẑ: "Ẑ",
            Ż: "Ż",
            ά: "ά",
            ὰ: "ὰ",
            ᾱ: "ᾱ",
            ᾰ: "ᾰ",
            έ: "έ",
            ὲ: "ὲ",
            ή: "ή",
            ὴ: "ὴ",
            ί: "ί",
            ὶ: "ὶ",
            ϊ: "ϊ",
            ΐ: "ΐ",
            ῒ: "ῒ",
            ῑ: "ῑ",
            ῐ: "ῐ",
            ό: "ό",
            ὸ: "ὸ",
            ύ: "ύ",
            ὺ: "ὺ",
            ϋ: "ϋ",
            ΰ: "ΰ",
            ῢ: "ῢ",
            ῡ: "ῡ",
            ῠ: "ῠ",
            ώ: "ώ",
            ὼ: "ὼ",
            Ύ: "Ύ",
            Ὺ: "Ὺ",
            Ϋ: "Ϋ",
            Ῡ: "Ῡ",
            Ῠ: "Ῠ",
            Ώ: "Ώ",
            Ὼ: "Ὼ"
          }, nl = /* @__PURE__ */ function() {
            function h(t, r) {
              this.mode = void 0, this.gullet = void 0, this.settings = void 0, this.leftrightDepth = void 0, this.nextToken = void 0, this.mode = "math", this.gullet = new xu(t, r, this.mode), this.settings = r, this.leftrightDepth = 0;
            }
            var e = h.prototype;
            return e.expect = function(r, n) {
              if (n === void 0 && (n = !0), this.fetch().text !== r)
                throw new c("Expected '" + r + "', got '" + this.fetch().text + "'", this.fetch());
              n && this.consume();
            }, e.consume = function() {
              this.nextToken = null;
            }, e.fetch = function() {
              return this.nextToken == null && (this.nextToken = this.gullet.expandNextToken()), this.nextToken;
            }, e.switchMode = function(r) {
              this.mode = r, this.gullet.switchMode(r);
            }, e.parse = function() {
              this.settings.globalGroup || this.gullet.beginGroup(), this.settings.colorIsTextColor && this.gullet.macros.set("\\color", "\\textcolor");
              try {
                var r = this.parseExpression(!1);
                return this.expect("EOF"), this.settings.globalGroup || this.gullet.endGroup(), r;
              } finally {
                this.gullet.endGroups();
              }
            }, e.subparse = function(r) {
              var n = this.nextToken;
              this.consume(), this.gullet.pushToken(new p0("}")), this.gullet.pushTokens(r);
              var s = this.parseExpression(!1);
              return this.expect("}"), this.nextToken = n, s;
            }, e.parseExpression = function(r, n) {
              for (var s = []; ; ) {
                this.mode === "math" && this.consumeSpaces();
                var f = this.fetch();
                if (h.endOfExpression.indexOf(f.text) !== -1 || n && f.text === n || r && v0[f.text] && v0[f.text].infix)
                  break;
                var g = this.parseAtom(n);
                if (g) {
                  if (g.type === "internal")
                    continue;
                } else
                  break;
                s.push(g);
              }
              return this.mode === "text" && this.formLigatures(s), this.handleInfixNodes(s);
            }, e.handleInfixNodes = function(r) {
              for (var n = -1, s, f = 0; f < r.length; f++)
                if (r[f].type === "infix") {
                  if (n !== -1)
                    throw new c("only one infix operator per group", r[f].token);
                  n = f, s = r[f].replaceWith;
                }
              if (n !== -1 && s) {
                var g, w, x = r.slice(0, n), E = r.slice(n + 1);
                x.length === 1 && x[0].type === "ordgroup" ? g = x[0] : g = {
                  type: "ordgroup",
                  mode: this.mode,
                  body: x
                }, E.length === 1 && E[0].type === "ordgroup" ? w = E[0] : w = {
                  type: "ordgroup",
                  mode: this.mode,
                  body: E
                };
                var z;
                return s === "\\\\abovefrac" ? z = this.callFunction(s, [g, r[n], w], []) : z = this.callFunction(s, [g, w], []), [z];
              } else
                return r;
            }, e.handleSupSubscript = function(r) {
              var n = this.fetch(), s = n.text;
              this.consume(), this.consumeSpaces();
              var f = this.parseGroup(r);
              if (!f)
                throw new c("Expected group after '" + s + "'", n);
              return f;
            }, e.formatUnsupportedCmd = function(r) {
              for (var n = [], s = 0; s < r.length; s++)
                n.push({
                  type: "textord",
                  mode: "text",
                  text: r[s]
                });
              var f = {
                type: "text",
                mode: this.mode,
                body: n
              }, g = {
                type: "color",
                mode: this.mode,
                color: this.settings.errorColor,
                body: [f]
              };
              return g;
            }, e.parseAtom = function(r) {
              var n = this.parseGroup("atom", r);
              if (this.mode === "text")
                return n;
              for (var s, f; ; ) {
                this.consumeSpaces();
                var g = this.fetch();
                if (g.text === "\\limits" || g.text === "\\nolimits") {
                  if (n && n.type === "op") {
                    var w = g.text === "\\limits";
                    n.limits = w, n.alwaysHandleSupSub = !0;
                  } else if (n && n.type === "operatorname")
                    n.alwaysHandleSupSub && (n.limits = g.text === "\\limits");
                  else
                    throw new c("Limit controls must follow a math operator", g);
                  this.consume();
                } else if (g.text === "^") {
                  if (s)
                    throw new c("Double superscript", g);
                  s = this.handleSupSubscript("superscript");
                } else if (g.text === "_") {
                  if (f)
                    throw new c("Double subscript", g);
                  f = this.handleSupSubscript("subscript");
                } else if (g.text === "'") {
                  if (s)
                    throw new c("Double superscript", g);
                  var x = {
                    type: "textord",
                    mode: this.mode,
                    text: "\\prime"
                  }, E = [x];
                  for (this.consume(); this.fetch().text === "'"; )
                    E.push(x), this.consume();
                  this.fetch().text === "^" && E.push(this.handleSupSubscript("superscript")), s = {
                    type: "ordgroup",
                    mode: this.mode,
                    body: E
                  };
                } else if ($r[g.text]) {
                  var z = $r[g.text], q = tl.test(g.text);
                  for (this.consume(); ; ) {
                    var O = this.fetch().text;
                    if (!$r[O] || tl.test(O) !== q)
                      break;
                    this.consume(), z += $r[O];
                  }
                  var U = new h(z, this.settings).parse();
                  q ? f = {
                    type: "ordgroup",
                    mode: "math",
                    body: U
                  } : s = {
                    type: "ordgroup",
                    mode: "math",
                    body: U
                  };
                } else
                  break;
              }
              return s || f ? {
                type: "supsub",
                mode: this.mode,
                base: n,
                sup: s,
                sub: f
              } : n;
            }, e.parseFunction = function(r, n) {
              var s = this.fetch(), f = s.text, g = v0[f];
              if (!g)
                return null;
              if (this.consume(), n && n !== "atom" && !g.allowedInArgument)
                throw new c("Got function '" + f + "' with no arguments" + (n ? " as " + n : ""), s);
              if (this.mode === "text" && !g.allowedInText)
                throw new c("Can't use function '" + f + "' in text mode", s);
              if (this.mode === "math" && g.allowedInMath === !1)
                throw new c("Can't use function '" + f + "' in math mode", s);
              var w = this.parseArguments(f, g), x = w.args, E = w.optArgs;
              return this.callFunction(f, x, E, s, r);
            }, e.callFunction = function(r, n, s, f, g) {
              var w = {
                funcName: r,
                parser: this,
                token: f,
                breakOnTokenText: g
              }, x = v0[r];
              if (x && x.handler)
                return x.handler(w, n, s);
              throw new c("No function handler for " + r);
            }, e.parseArguments = function(r, n) {
              var s = n.numArgs + n.numOptionalArgs;
              if (s === 0)
                return {
                  args: [],
                  optArgs: []
                };
              for (var f = [], g = [], w = 0; w < s; w++) {
                var x = n.argTypes && n.argTypes[w], E = w < n.numOptionalArgs;
                (n.primitive && x == null || // \sqrt expands into primitive if optional argument doesn't exist
                n.type === "sqrt" && w === 1 && g[0] == null) && (x = "primitive");
                var z = this.parseGroupOfType("argument to '" + r + "'", x, E);
                if (E)
                  g.push(z);
                else if (z != null)
                  f.push(z);
                else
                  throw new c("Null argument, please report this as a bug");
              }
              return {
                args: f,
                optArgs: g
              };
            }, e.parseGroupOfType = function(r, n, s) {
              switch (n) {
                case "color":
                  return this.parseColorGroup(s);
                case "size":
                  return this.parseSizeGroup(s);
                case "url":
                  return this.parseUrlGroup(s);
                case "math":
                case "text":
                  return this.parseArgumentGroup(s, n);
                case "hbox": {
                  var f = this.parseArgumentGroup(s, "text");
                  return f != null ? {
                    type: "styling",
                    mode: f.mode,
                    body: [f],
                    style: "text"
                    // simulate \textstyle
                  } : null;
                }
                case "raw": {
                  var g = this.parseStringGroup("raw", s);
                  return g != null ? {
                    type: "raw",
                    mode: "text",
                    string: g.text
                  } : null;
                }
                case "primitive": {
                  if (s)
                    throw new c("A primitive argument cannot be optional");
                  var w = this.parseGroup(r);
                  if (w == null)
                    throw new c("Expected group as " + r, this.fetch());
                  return w;
                }
                case "original":
                case null:
                case void 0:
                  return this.parseArgumentGroup(s);
                default:
                  throw new c("Unknown group type as " + r, this.fetch());
              }
            }, e.consumeSpaces = function() {
              for (; this.fetch().text === " "; )
                this.consume();
            }, e.parseStringGroup = function(r, n) {
              var s = this.gullet.scanArgument(n);
              if (s == null)
                return null;
              for (var f = "", g; (g = this.fetch()).text !== "EOF"; )
                f += g.text, this.consume();
              return this.consume(), s.text = f, s;
            }, e.parseRegexGroup = function(r, n) {
              for (var s = this.fetch(), f = s, g = "", w; (w = this.fetch()).text !== "EOF" && r.test(g + w.text); )
                f = w, g += f.text, this.consume();
              if (g === "")
                throw new c("Invalid " + n + ": '" + s.text + "'", s);
              return s.range(f, g);
            }, e.parseColorGroup = function(r) {
              var n = this.parseStringGroup("color", r);
              if (n == null)
                return null;
              var s = /^(#[a-f0-9]{3}|#?[a-f0-9]{6}|[a-z]+)$/i.exec(n.text);
              if (!s)
                throw new c("Invalid color: '" + n.text + "'", n);
              var f = s[0];
              return /^[0-9a-f]{6}$/i.test(f) && (f = "#" + f), {
                type: "color-token",
                mode: this.mode,
                color: f
              };
            }, e.parseSizeGroup = function(r) {
              var n, s = !1;
              if (this.gullet.consumeSpaces(), !r && this.gullet.future().text !== "{" ? n = this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size") : n = this.parseStringGroup("size", r), !n)
                return null;
              !r && n.text.length === 0 && (n.text = "0pt", s = !0);
              var f = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(n.text);
              if (!f)
                throw new c("Invalid size: '" + n.text + "'", n);
              var g = {
                number: +(f[1] + f[2]),
                // sign + magnitude, cast to number
                unit: f[3]
              };
              if (!X0(g))
                throw new c("Invalid unit: '" + g.unit + "'", n);
              return {
                type: "size",
                mode: this.mode,
                value: g,
                isBlank: s
              };
            }, e.parseUrlGroup = function(r) {
              this.gullet.lexer.setCatcode("%", 13), this.gullet.lexer.setCatcode("~", 12);
              var n = this.parseStringGroup("url", r);
              if (this.gullet.lexer.setCatcode("%", 14), this.gullet.lexer.setCatcode("~", 13), n == null)
                return null;
              var s = n.text.replace(/\\([#$%&~_^{}])/g, "$1");
              return {
                type: "url",
                mode: this.mode,
                url: s
              };
            }, e.parseArgumentGroup = function(r, n) {
              var s = this.gullet.scanArgument(r);
              if (s == null)
                return null;
              var f = this.mode;
              n && this.switchMode(n), this.gullet.beginGroup();
              var g = this.parseExpression(!1, "EOF");
              this.expect("EOF"), this.gullet.endGroup();
              var w = {
                type: "ordgroup",
                mode: this.mode,
                loc: s.loc,
                body: g
              };
              return n && this.switchMode(f), w;
            }, e.parseGroup = function(r, n) {
              var s = this.fetch(), f = s.text, g;
              if (f === "{" || f === "\\begingroup") {
                this.consume();
                var w = f === "{" ? "}" : "\\endgroup";
                this.gullet.beginGroup();
                var x = this.parseExpression(!1, w), E = this.fetch();
                this.expect(w), this.gullet.endGroup(), g = {
                  type: "ordgroup",
                  mode: this.mode,
                  loc: Nt.range(s, E),
                  body: x,
                  // A group formed by \begingroup...\endgroup is a semi-simple group
                  // which doesn't affect spacing in math mode, i.e., is transparent.
                  // https://tex.stackexchange.com/questions/1930/when-should-one-
                  // use-begingroup-instead-of-bgroup
                  semisimple: f === "\\begingroup" || void 0
                };
              } else if (g = this.parseFunction(n, r) || this.parseSymbol(), g == null && f[0] === "\\" && !el.hasOwnProperty(f)) {
                if (this.settings.throwOnError)
                  throw new c("Undefined control sequence: " + f, s);
                g = this.formatUnsupportedCmd(f), this.consume();
              }
              return g;
            }, e.formLigatures = function(r) {
              for (var n = r.length - 1, s = 0; s < n; ++s) {
                var f = r[s], g = f.text;
                g === "-" && r[s + 1].text === "-" && (s + 1 < n && r[s + 2].text === "-" ? (r.splice(s, 3, {
                  type: "textord",
                  mode: "text",
                  loc: Nt.range(f, r[s + 2]),
                  text: "---"
                }), n -= 2) : (r.splice(s, 2, {
                  type: "textord",
                  mode: "text",
                  loc: Nt.range(f, r[s + 1]),
                  text: "--"
                }), n -= 1)), (g === "'" || g === "`") && r[s + 1].text === g && (r.splice(s, 2, {
                  type: "textord",
                  mode: "text",
                  loc: Nt.range(f, r[s + 1]),
                  text: g + g
                }), n -= 1);
              }
            }, e.parseSymbol = function() {
              var r = this.fetch(), n = r.text;
              if (/^\\verb[^a-zA-Z]/.test(n)) {
                this.consume();
                var s = n.slice(5), f = s.charAt(0) === "*";
                if (f && (s = s.slice(1)), s.length < 2 || s.charAt(0) !== s.slice(-1))
                  throw new c(`\\verb assertion failed --
                    please report what input caused this bug`);
                return s = s.slice(1, -1), {
                  type: "verb",
                  mode: "text",
                  body: s,
                  star: f
                };
              }
              rl.hasOwnProperty(n[0]) && !qe[this.mode][n[0]] && (this.settings.strict && this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Accented Unicode text character "' + n[0] + '" used in math mode', r), n = rl[n[0]] + n.slice(1));
              var g = vu.exec(n);
              g && (n = n.substring(0, g.index), n === "i" ? n = "ı" : n === "j" && (n = "ȷ"));
              var w;
              if (qe[this.mode][n]) {
                this.settings.strict && this.mode === "math" && Mn.indexOf(n) >= 0 && this.settings.reportNonstrict("unicodeTextInMathMode", 'Latin-1/Unicode text character "' + n[0] + '" used in math mode', r);
                var x = qe[this.mode][n].group, E = Nt.range(r), z;
                if (Jt.hasOwnProperty(x)) {
                  var q = x;
                  z = {
                    type: "atom",
                    mode: this.mode,
                    family: q,
                    loc: E,
                    text: n
                  };
                } else
                  z = {
                    type: x,
                    mode: this.mode,
                    loc: E,
                    text: n
                  };
                w = z;
              } else if (n.charCodeAt(0) >= 128)
                this.settings.strict && (wt(n.charCodeAt(0)) ? this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Unicode text character "' + n[0] + '" used in math mode', r) : this.settings.reportNonstrict("unknownSymbol", 'Unrecognized Unicode character "' + n[0] + '"' + (" (" + n.charCodeAt(0) + ")"), r)), w = {
                  type: "textord",
                  mode: "text",
                  loc: Nt.range(r),
                  text: n
                };
              else
                return null;
              if (this.consume(), g)
                for (var O = 0; O < g[0].length; O++) {
                  var U = g[0][O];
                  if (!sa[U])
                    throw new c("Unknown accent ' " + U + "'", r);
                  var Q = sa[U][this.mode] || sa[U].text;
                  if (!Q)
                    throw new c("Accent " + U + " unsupported in " + this.mode + " mode", r);
                  w = {
                    type: "accent",
                    mode: this.mode,
                    loc: Nt.range(r),
                    label: Q,
                    isStretchy: !1,
                    isShifty: !0,
                    // $FlowFixMe
                    base: w
                  };
                }
              return w;
            }, h;
          }();
          nl.endOfExpression = ["}", "\\endgroup", "\\end", "\\right", "&"];
          var Du = function(e, t) {
            if (!(typeof e == "string" || e instanceof String))
              throw new TypeError("KaTeX can only parse string typed expression");
            var r = new nl(e, t);
            delete r.gullet.macros.current["\\df@tag"];
            var n = r.parse();
            if (delete r.gullet.macros.current["\\current@color"], delete r.gullet.macros.current["\\color"], r.gullet.macros.get("\\df@tag")) {
              if (!t.displayMode)
                throw new c("\\tag works only in display equations");
              n = [{
                type: "tag",
                mode: "text",
                body: n,
                tag: r.subparse([new p0("\\df@tag")])
              }];
            }
            return n;
          }, oa = Du, al = function(e, t, r) {
            t.textContent = "";
            var n = ua(e, r).toNode();
            t.appendChild(n);
          };
          typeof document < "u" && document.compatMode !== "CSS1Compat" && (typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype."), al = function() {
            throw new c("KaTeX doesn't work in quirks mode.");
          });
          var Au = function(e, t) {
            var r = ua(e, t).toMarkup();
            return r;
          }, _u = function(e, t) {
            var r = new R(t);
            return oa(e, r);
          }, il = function(e, t, r) {
            if (r.throwOnError || !(e instanceof c))
              throw e;
            var n = N.makeSpan(["katex-error"], [new it(t)]);
            return n.setAttribute("title", e.toString()), n.setAttribute("style", "color:" + r.errorColor), n;
          }, ua = function(e, t) {
            var r = new R(t);
            try {
              var n = oa(e, r);
              return To(n, e, r);
            } catch (s) {
              return il(s, e, r);
            }
          }, Su = function(e, t) {
            var r = new R(t);
            try {
              var n = oa(e, r);
              return Bo(n, e, r);
            } catch (s) {
              return il(s, e, r);
            }
          }, Fu = {
            /**
             * Current KaTeX version
             */
            version: "0.16.9",
            /**
             * Renders the given LaTeX into an HTML+MathML combination, and adds
             * it as a child to the specified DOM node.
             */
            render: al,
            /**
             * Renders the given LaTeX into an HTML+MathML combination string,
             * for sending to the client.
             */
            renderToString: Au,
            /**
             * KaTeX error, usually during parsing.
             */
            ParseError: c,
            /**
             * The shema of Settings
             */
            SETTINGS_SCHEMA: B,
            /**
             * Parses the given LaTeX into KaTeX's internal parse tree structure,
             * without rendering to HTML or MathML.
             *
             * NOTE: This method is not currently recommended for public use.
             * The internal tree representation is unstable and is very likely
             * to change. Use at your own risk.
             */
            __parse: _u,
            /**
             * Renders the given LaTeX into an HTML+MathML internal DOM tree
             * representation, without flattening that representation to a string.
             *
             * NOTE: This method is not currently recommended for public use.
             * The internal tree representation is unstable and is very likely
             * to change. Use at your own risk.
             */
            __renderToDomTree: ua,
            /**
             * Renders the given LaTeX into an HTML internal DOM tree representation,
             * without MathML and without flattening that representation to a string.
             *
             * NOTE: This method is not currently recommended for public use.
             * The internal tree representation is unstable and is very likely
             * to change. Use at your own risk.
             */
            __renderToHTMLTree: Su,
            /**
             * extends internal font metrics object with a new object
             * each key in the new object represents a font name
            */
            __setFontMetrics: u0,
            /**
             * adds a new symbol to builtin symbols table
             */
            __defineSymbol: o,
            /**
             * adds a new function to builtin function list,
             * which directly produce parse tree elements
             * and have their own html/mathml builders
             */
            __defineFunction: ne,
            /**
             * adds a new macro to builtin macro list
             */
            __defineMacro: k,
            /**
             * Expose the dom tree node types, which can be useful for type checking nodes.
             *
             * NOTE: This method is not currently recommended for public use.
             * The internal tree representation is unstable and is very likely
             * to change. Use at your own risk.
             */
            __domTree: {
              Span: Dt,
              Anchor: cr,
              SymbolNode: it,
              SvgNode: At,
              PathNode: Pt,
              LineNode: h0
            }
          }, Eu = Fu;
          return l = l.default, l;
        }()
      );
    });
  }(wa)), wa.exports;
}
(function(u, a) {
  (function(l, m) {
    u.exports = m(r1());
  })(typeof self < "u" ? self : vn, function(i) {
    return (
      /******/
      function() {
        var l = {
          /***/
          771: (
            /***/
            function(v) {
              v.exports = i;
            }
          )
          /******/
        }, m = {};
        function c(v) {
          var y = m[v];
          if (y !== void 0)
            return y.exports;
          var D = m[v] = {
            /******/
            // no module.id needed
            /******/
            // no module.loaded needed
            /******/
            exports: {}
            /******/
          };
          return l[v](D, D.exports, c), D.exports;
        }
        (function() {
          c.n = function(v) {
            var y = v && v.__esModule ? (
              /******/
              function() {
                return v.default;
              }
            ) : (
              /******/
              function() {
                return v;
              }
            );
            return c.d(y, { a: y }), y;
          };
        })(), function() {
          c.d = function(v, y) {
            for (var D in y)
              c.o(y, D) && !c.o(v, D) && Object.defineProperty(v, D, { enumerable: !0, get: y[D] });
          };
        }(), function() {
          c.o = function(v, y) {
            return Object.prototype.hasOwnProperty.call(v, y);
          };
        }();
        var p = {};
        return function() {
          c.d(p, {
            default: function() {
              return (
                /* binding */
                L
              );
            }
          });
          var v = c(771), y = /* @__PURE__ */ c.n(v), D = function(S, R, I) {
            for (var M = I, X = 0, $ = S.length; M < R.length; ) {
              var j = R[M];
              if (X <= 0 && R.slice(M, M + $) === S)
                return M;
              j === "\\" ? M++ : j === "{" ? X++ : j === "}" && X--, M++;
            }
            return -1;
          }, C = function(S) {
            return S.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
          }, P = /^\\begin{/, H = function(S, R) {
            for (var I, M = [], X = new RegExp("(" + R.map(function(ie) {
              return C(ie.left);
            }).join("|") + ")"); I = S.search(X), I !== -1; ) {
              I > 0 && (M.push({
                type: "text",
                data: S.slice(0, I)
              }), S = S.slice(I));
              var $ = R.findIndex(function(ie) {
                return S.startsWith(ie.left);
              });
              if (I = D(R[$].right, S, R[$].left.length), I === -1)
                break;
              var j = S.slice(0, I + R[$].right.length), he = P.test(j) ? j : S.slice(R[$].left.length, I);
              M.push({
                type: "math",
                data: he,
                rawData: j,
                display: R[$].display
              }), S = S.slice(I + R[$].right.length);
            }
            return S !== "" && M.push({
              type: "text",
              data: S
            }), M;
          }, W = H, se = function(S, R) {
            var I = W(S, R.delimiters);
            if (I.length === 1 && I[0].type === "text")
              return null;
            for (var M = document.createDocumentFragment(), X = 0; X < I.length; X++)
              if (I[X].type === "text")
                M.appendChild(document.createTextNode(I[X].data));
              else {
                var $ = document.createElement("span"), j = I[X].data;
                R.displayMode = I[X].display;
                try {
                  R.preProcess && (j = R.preProcess(j)), y().render(j, $, R);
                } catch (he) {
                  if (!(he instanceof y().ParseError))
                    throw he;
                  R.errorCallback("KaTeX auto-render: Failed to parse `" + I[X].data + "` with ", he), M.appendChild(document.createTextNode(I[X].rawData));
                  continue;
                }
                M.appendChild($);
              }
            return M;
          }, oe = function B(S, R) {
            for (var I = 0; I < S.childNodes.length; I++) {
              var M = S.childNodes[I];
              if (M.nodeType === 3) {
                for (var X = M.textContent, $ = M.nextSibling, j = 0; $ && $.nodeType === Node.TEXT_NODE; )
                  X += $.textContent, $ = $.nextSibling, j++;
                var he = se(X, R);
                if (he) {
                  for (var ie = 0; ie < j; ie++)
                    M.nextSibling.remove();
                  I += he.childNodes.length - 1, S.replaceChild(he, M);
                } else
                  I += j;
              } else
                M.nodeType === 1 && function() {
                  var de = " " + M.className + " ", be = R.ignoredTags.indexOf(M.nodeName.toLowerCase()) === -1 && R.ignoredClasses.every(function(Te) {
                    return de.indexOf(" " + Te + " ") === -1;
                  });
                  be && B(M, R);
                }();
            }
          }, ae = function(S, R) {
            if (!S)
              throw new Error("No element provided to render");
            var I = {};
            for (var M in R)
              R.hasOwnProperty(M) && (I[M] = R[M]);
            I.delimiters = I.delimiters || [
              {
                left: "$$",
                right: "$$",
                display: !0
              },
              {
                left: "\\(",
                right: "\\)",
                display: !1
              },
              // LaTeX uses $…$, but it ruins the display of normal `$` in text:
              // {left: "$", right: "$", display: false},
              // $ must come after $$
              // Render AMS environments even if outside $$…$$ delimiters.
              {
                left: "\\begin{equation}",
                right: "\\end{equation}",
                display: !0
              },
              {
                left: "\\begin{align}",
                right: "\\end{align}",
                display: !0
              },
              {
                left: "\\begin{alignat}",
                right: "\\end{alignat}",
                display: !0
              },
              {
                left: "\\begin{gather}",
                right: "\\end{gather}",
                display: !0
              },
              {
                left: "\\begin{CD}",
                right: "\\end{CD}",
                display: !0
              },
              {
                left: "\\[",
                right: "\\]",
                display: !0
              }
            ], I.ignoredTags = I.ignoredTags || ["script", "noscript", "style", "textarea", "pre", "code", "option"], I.ignoredClasses = I.ignoredClasses || [], I.errorCallback = I.errorCallback || console.error, I.macros = I.macros || {}, oe(S, I);
          }, L = ae;
        }(), p = p.default, p;
      }()
    );
  });
})(Ts);
var n1 = Ts.exports;
const a1 = /* @__PURE__ */ Cs(n1);
function Ra() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let U0 = Ra();
function Bs(u) {
  U0 = u;
}
const Ms = /[&<>"']/, i1 = new RegExp(Ms.source, "g"), zs = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, l1 = new RegExp(zs.source, "g"), s1 = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, wl = (u) => s1[u];
function bt(u, a) {
  if (a) {
    if (Ms.test(u))
      return u.replace(i1, wl);
  } else if (zs.test(u))
    return u.replace(l1, wl);
  return u;
}
const o1 = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function u1(u) {
  return u.replace(o1, (a, i) => (i = i.toLowerCase(), i === "colon" ? ":" : i.charAt(0) === "#" ? i.charAt(1) === "x" ? String.fromCharCode(parseInt(i.substring(2), 16)) : String.fromCharCode(+i.substring(1)) : ""));
}
const c1 = /(^|[^\[])\^/g;
function Re(u, a) {
  let i = typeof u == "string" ? u : u.source;
  a = a || "";
  const l = {
    replace: (m, c) => {
      let p = typeof c == "string" ? c : c.source;
      return p = p.replace(c1, "$1"), i = i.replace(m, p), l;
    },
    getRegex: () => new RegExp(i, a)
  };
  return l;
}
function kl(u) {
  try {
    u = encodeURI(u).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return u;
}
const Sr = { exec: () => null };
function xl(u, a) {
  const i = u.replace(/\|/g, (c, p, v) => {
    let y = !1, D = p;
    for (; --D >= 0 && v[D] === "\\"; )
      y = !y;
    return y ? "|" : " |";
  }), l = i.split(/ \|/);
  let m = 0;
  if (l[0].trim() || l.shift(), l.length > 0 && !l[l.length - 1].trim() && l.pop(), a)
    if (l.length > a)
      l.splice(a);
    else
      for (; l.length < a; )
        l.push("");
  for (; m < l.length; m++)
    l[m] = l[m].trim().replace(/\\\|/g, "|");
  return l;
}
function un(u, a, i) {
  const l = u.length;
  if (l === 0)
    return "";
  let m = 0;
  for (; m < l; ) {
    const c = u.charAt(l - m - 1);
    if (c === a && !i)
      m++;
    else if (c !== a && i)
      m++;
    else
      break;
  }
  return u.slice(0, l - m);
}
function h1(u, a) {
  if (u.indexOf(a[1]) === -1)
    return -1;
  let i = 0;
  for (let l = 0; l < u.length; l++)
    if (u[l] === "\\")
      l++;
    else if (u[l] === a[0])
      i++;
    else if (u[l] === a[1] && (i--, i < 0))
      return l;
  return -1;
}
function Dl(u, a, i, l) {
  const m = a.href, c = a.title ? bt(a.title) : null, p = u[1].replace(/\\([\[\]])/g, "$1");
  if (u[0].charAt(0) !== "!") {
    l.state.inLink = !0;
    const v = {
      type: "link",
      raw: i,
      href: m,
      title: c,
      text: p,
      tokens: l.inlineTokens(p)
    };
    return l.state.inLink = !1, v;
  }
  return {
    type: "image",
    raw: i,
    href: m,
    title: c,
    text: bt(p)
  };
}
function f1(u, a) {
  const i = u.match(/^(\s+)(?:```)/);
  if (i === null)
    return a;
  const l = i[1];
  return a.split(`
`).map((m) => {
    const c = m.match(/^\s+/);
    if (c === null)
      return m;
    const [p] = c;
    return p.length >= l.length ? m.slice(l.length) : m;
  }).join(`
`);
}
class bn {
  // set by the lexer
  constructor(a) {
    Ue(this, "options");
    Ue(this, "rules");
    // set by the lexer
    Ue(this, "lexer");
    this.options = a || U0;
  }
  space(a) {
    const i = this.rules.block.newline.exec(a);
    if (i && i[0].length > 0)
      return {
        type: "space",
        raw: i[0]
      };
  }
  code(a) {
    const i = this.rules.block.code.exec(a);
    if (i) {
      const l = i[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: i[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? l : un(l, `
`)
      };
    }
  }
  fences(a) {
    const i = this.rules.block.fences.exec(a);
    if (i) {
      const l = i[0], m = f1(l, i[3] || "");
      return {
        type: "code",
        raw: l,
        lang: i[2] ? i[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : i[2],
        text: m
      };
    }
  }
  heading(a) {
    const i = this.rules.block.heading.exec(a);
    if (i) {
      let l = i[2].trim();
      if (/#$/.test(l)) {
        const m = un(l, "#");
        (this.options.pedantic || !m || / $/.test(m)) && (l = m.trim());
      }
      return {
        type: "heading",
        raw: i[0],
        depth: i[1].length,
        text: l,
        tokens: this.lexer.inline(l)
      };
    }
  }
  hr(a) {
    const i = this.rules.block.hr.exec(a);
    if (i)
      return {
        type: "hr",
        raw: i[0]
      };
  }
  blockquote(a) {
    const i = this.rules.block.blockquote.exec(a);
    if (i) {
      const l = un(i[0].replace(/^ *>[ \t]?/gm, ""), `
`), m = this.lexer.state.top;
      this.lexer.state.top = !0;
      const c = this.lexer.blockTokens(l);
      return this.lexer.state.top = m, {
        type: "blockquote",
        raw: i[0],
        tokens: c,
        text: l
      };
    }
  }
  list(a) {
    let i = this.rules.block.list.exec(a);
    if (i) {
      let l = i[1].trim();
      const m = l.length > 1, c = {
        type: "list",
        raw: "",
        ordered: m,
        start: m ? +l.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      l = m ? `\\d{1,9}\\${l.slice(-1)}` : `\\${l}`, this.options.pedantic && (l = m ? l : "[*+-]");
      const p = new RegExp(`^( {0,3}${l})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let v = "", y = "", D = !1;
      for (; a; ) {
        let C = !1;
        if (!(i = p.exec(a)) || this.rules.block.hr.test(a))
          break;
        v = i[0], a = a.substring(v.length);
        let P = i[2].split(`
`, 1)[0].replace(/^\t+/, (L) => " ".repeat(3 * L.length)), H = a.split(`
`, 1)[0], W = 0;
        this.options.pedantic ? (W = 2, y = P.trimStart()) : (W = i[2].search(/[^ ]/), W = W > 4 ? 1 : W, y = P.slice(W), W += i[1].length);
        let se = !1;
        if (!P && /^ *$/.test(H) && (v += H + `
`, a = a.substring(H.length + 1), C = !0), !C) {
          const L = new RegExp(`^ {0,${Math.min(3, W - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), B = new RegExp(`^ {0,${Math.min(3, W - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), S = new RegExp(`^ {0,${Math.min(3, W - 1)}}(?:\`\`\`|~~~)`), R = new RegExp(`^ {0,${Math.min(3, W - 1)}}#`);
          for (; a; ) {
            const I = a.split(`
`, 1)[0];
            if (H = I, this.options.pedantic && (H = H.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), S.test(H) || R.test(H) || L.test(H) || B.test(a))
              break;
            if (H.search(/[^ ]/) >= W || !H.trim())
              y += `
` + H.slice(W);
            else {
              if (se || P.search(/[^ ]/) >= 4 || S.test(P) || R.test(P) || B.test(P))
                break;
              y += `
` + H;
            }
            !se && !H.trim() && (se = !0), v += I + `
`, a = a.substring(I.length + 1), P = H.slice(W);
          }
        }
        c.loose || (D ? c.loose = !0 : /\n *\n *$/.test(v) && (D = !0));
        let oe = null, ae;
        this.options.gfm && (oe = /^\[[ xX]\] /.exec(y), oe && (ae = oe[0] !== "[ ] ", y = y.replace(/^\[[ xX]\] +/, ""))), c.items.push({
          type: "list_item",
          raw: v,
          task: !!oe,
          checked: ae,
          loose: !1,
          text: y,
          tokens: []
        }), c.raw += v;
      }
      c.items[c.items.length - 1].raw = v.trimEnd(), c.items[c.items.length - 1].text = y.trimEnd(), c.raw = c.raw.trimEnd();
      for (let C = 0; C < c.items.length; C++)
        if (this.lexer.state.top = !1, c.items[C].tokens = this.lexer.blockTokens(c.items[C].text, []), !c.loose) {
          const P = c.items[C].tokens.filter((W) => W.type === "space"), H = P.length > 0 && P.some((W) => /\n.*\n/.test(W.raw));
          c.loose = H;
        }
      if (c.loose)
        for (let C = 0; C < c.items.length; C++)
          c.items[C].loose = !0;
      return c;
    }
  }
  html(a) {
    const i = this.rules.block.html.exec(a);
    if (i)
      return {
        type: "html",
        block: !0,
        raw: i[0],
        pre: i[1] === "pre" || i[1] === "script" || i[1] === "style",
        text: i[0]
      };
  }
  def(a) {
    const i = this.rules.block.def.exec(a);
    if (i) {
      const l = i[1].toLowerCase().replace(/\s+/g, " "), m = i[2] ? i[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", c = i[3] ? i[3].substring(1, i[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : i[3];
      return {
        type: "def",
        tag: l,
        raw: i[0],
        href: m,
        title: c
      };
    }
  }
  table(a) {
    const i = this.rules.block.table.exec(a);
    if (!i || !/[:|]/.test(i[2]))
      return;
    const l = xl(i[1]), m = i[2].replace(/^\||\| *$/g, "").split("|"), c = i[3] && i[3].trim() ? i[3].replace(/\n[ \t]*$/, "").split(`
`) : [], p = {
      type: "table",
      raw: i[0],
      header: [],
      align: [],
      rows: []
    };
    if (l.length === m.length) {
      for (const v of m)
        /^ *-+: *$/.test(v) ? p.align.push("right") : /^ *:-+: *$/.test(v) ? p.align.push("center") : /^ *:-+ *$/.test(v) ? p.align.push("left") : p.align.push(null);
      for (const v of l)
        p.header.push({
          text: v,
          tokens: this.lexer.inline(v)
        });
      for (const v of c)
        p.rows.push(xl(v, p.header.length).map((y) => ({
          text: y,
          tokens: this.lexer.inline(y)
        })));
      return p;
    }
  }
  lheading(a) {
    const i = this.rules.block.lheading.exec(a);
    if (i)
      return {
        type: "heading",
        raw: i[0],
        depth: i[2].charAt(0) === "=" ? 1 : 2,
        text: i[1],
        tokens: this.lexer.inline(i[1])
      };
  }
  paragraph(a) {
    const i = this.rules.block.paragraph.exec(a);
    if (i) {
      const l = i[1].charAt(i[1].length - 1) === `
` ? i[1].slice(0, -1) : i[1];
      return {
        type: "paragraph",
        raw: i[0],
        text: l,
        tokens: this.lexer.inline(l)
      };
    }
  }
  text(a) {
    const i = this.rules.block.text.exec(a);
    if (i)
      return {
        type: "text",
        raw: i[0],
        text: i[0],
        tokens: this.lexer.inline(i[0])
      };
  }
  escape(a) {
    const i = this.rules.inline.escape.exec(a);
    if (i)
      return {
        type: "escape",
        raw: i[0],
        text: bt(i[1])
      };
  }
  tag(a) {
    const i = this.rules.inline.tag.exec(a);
    if (i)
      return !this.lexer.state.inLink && /^<a /i.test(i[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(i[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(i[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(i[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: i[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: i[0]
      };
  }
  link(a) {
    const i = this.rules.inline.link.exec(a);
    if (i) {
      const l = i[2].trim();
      if (!this.options.pedantic && /^</.test(l)) {
        if (!/>$/.test(l))
          return;
        const p = un(l.slice(0, -1), "\\");
        if ((l.length - p.length) % 2 === 0)
          return;
      } else {
        const p = h1(i[2], "()");
        if (p > -1) {
          const y = (i[0].indexOf("!") === 0 ? 5 : 4) + i[1].length + p;
          i[2] = i[2].substring(0, p), i[0] = i[0].substring(0, y).trim(), i[3] = "";
        }
      }
      let m = i[2], c = "";
      if (this.options.pedantic) {
        const p = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(m);
        p && (m = p[1], c = p[3]);
      } else
        c = i[3] ? i[3].slice(1, -1) : "";
      return m = m.trim(), /^</.test(m) && (this.options.pedantic && !/>$/.test(l) ? m = m.slice(1) : m = m.slice(1, -1)), Dl(i, {
        href: m && m.replace(this.rules.inline.anyPunctuation, "$1"),
        title: c && c.replace(this.rules.inline.anyPunctuation, "$1")
      }, i[0], this.lexer);
    }
  }
  reflink(a, i) {
    let l;
    if ((l = this.rules.inline.reflink.exec(a)) || (l = this.rules.inline.nolink.exec(a))) {
      const m = (l[2] || l[1]).replace(/\s+/g, " "), c = i[m.toLowerCase()];
      if (!c) {
        const p = l[0].charAt(0);
        return {
          type: "text",
          raw: p,
          text: p
        };
      }
      return Dl(l, c, l[0], this.lexer);
    }
  }
  emStrong(a, i, l = "") {
    let m = this.rules.inline.emStrongLDelim.exec(a);
    if (!m || m[3] && l.match(/[\p{L}\p{N}]/u))
      return;
    if (!(m[1] || m[2] || "") || !l || this.rules.inline.punctuation.exec(l)) {
      const p = [...m[0]].length - 1;
      let v, y, D = p, C = 0;
      const P = m[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (P.lastIndex = 0, i = i.slice(-1 * a.length + p); (m = P.exec(i)) != null; ) {
        if (v = m[1] || m[2] || m[3] || m[4] || m[5] || m[6], !v)
          continue;
        if (y = [...v].length, m[3] || m[4]) {
          D += y;
          continue;
        } else if ((m[5] || m[6]) && p % 3 && !((p + y) % 3)) {
          C += y;
          continue;
        }
        if (D -= y, D > 0)
          continue;
        y = Math.min(y, y + D + C);
        const H = [...m[0]][0].length, W = a.slice(0, p + m.index + H + y);
        if (Math.min(p, y) % 2) {
          const oe = W.slice(1, -1);
          return {
            type: "em",
            raw: W,
            text: oe,
            tokens: this.lexer.inlineTokens(oe)
          };
        }
        const se = W.slice(2, -2);
        return {
          type: "strong",
          raw: W,
          text: se,
          tokens: this.lexer.inlineTokens(se)
        };
      }
    }
  }
  codespan(a) {
    const i = this.rules.inline.code.exec(a);
    if (i) {
      let l = i[2].replace(/\n/g, " ");
      const m = /[^ ]/.test(l), c = /^ /.test(l) && / $/.test(l);
      return m && c && (l = l.substring(1, l.length - 1)), l = bt(l, !0), {
        type: "codespan",
        raw: i[0],
        text: l
      };
    }
  }
  br(a) {
    const i = this.rules.inline.br.exec(a);
    if (i)
      return {
        type: "br",
        raw: i[0]
      };
  }
  del(a) {
    const i = this.rules.inline.del.exec(a);
    if (i)
      return {
        type: "del",
        raw: i[0],
        text: i[2],
        tokens: this.lexer.inlineTokens(i[2])
      };
  }
  autolink(a) {
    const i = this.rules.inline.autolink.exec(a);
    if (i) {
      let l, m;
      return i[2] === "@" ? (l = bt(i[1]), m = "mailto:" + l) : (l = bt(i[1]), m = l), {
        type: "link",
        raw: i[0],
        text: l,
        href: m,
        tokens: [
          {
            type: "text",
            raw: l,
            text: l
          }
        ]
      };
    }
  }
  url(a) {
    var l;
    let i;
    if (i = this.rules.inline.url.exec(a)) {
      let m, c;
      if (i[2] === "@")
        m = bt(i[0]), c = "mailto:" + m;
      else {
        let p;
        do
          p = i[0], i[0] = ((l = this.rules.inline._backpedal.exec(i[0])) == null ? void 0 : l[0]) ?? "";
        while (p !== i[0]);
        m = bt(i[0]), i[1] === "www." ? c = "http://" + i[0] : c = i[0];
      }
      return {
        type: "link",
        raw: i[0],
        text: m,
        href: c,
        tokens: [
          {
            type: "text",
            raw: m,
            text: m
          }
        ]
      };
    }
  }
  inlineText(a) {
    const i = this.rules.inline.text.exec(a);
    if (i) {
      let l;
      return this.lexer.state.inRawBlock ? l = i[0] : l = bt(i[0]), {
        type: "text",
        raw: i[0],
        text: l
      };
    }
  }
}
const m1 = /^(?: *(?:\n|$))+/, d1 = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, p1 = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Cr = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, g1 = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Ns = /(?:[*+-]|\d{1,9}[.)])/, Rs = Re(/^(?!bull )((?:.|\n(?!\s*?\n|bull ))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Ns).getRegex(), Ia = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, v1 = /^[^\n]+/, La = /(?!\s*\])(?:\\.|[^\[\]\\])+/, b1 = Re(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", La).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), y1 = Re(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Ns).getRegex(), _n = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Oa = /<!--(?!-?>)[\s\S]*?(?:-->|$)/, w1 = Re("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Oa).replace("tag", _n).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Is = Re(Ia).replace("hr", Cr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _n).getRegex(), k1 = Re(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Is).getRegex(), qa = {
  blockquote: k1,
  code: d1,
  def: b1,
  fences: p1,
  heading: g1,
  hr: Cr,
  html: w1,
  lheading: Rs,
  list: y1,
  newline: m1,
  paragraph: Is,
  table: Sr,
  text: v1
}, Al = Re("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Cr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _n).getRegex(), x1 = {
  ...qa,
  table: Al,
  paragraph: Re(Ia).replace("hr", Cr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Al).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _n).getRegex()
}, D1 = {
  ...qa,
  html: Re(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Oa).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Sr,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: Re(Ia).replace("hr", Cr).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Rs).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Ls = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, A1 = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Os = /^( {2,}|\\)\n(?!\s*$)/, _1 = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Tr = "\\p{P}$+<=>`^|~", S1 = Re(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Tr).getRegex(), F1 = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, E1 = Re(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Tr).getRegex(), C1 = Re("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Tr).getRegex(), T1 = Re("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Tr).getRegex(), B1 = Re(/\\([punct])/, "gu").replace(/punct/g, Tr).getRegex(), M1 = Re(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), z1 = Re(Oa).replace("(?:-->|$)", "-->").getRegex(), N1 = Re("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", z1).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), yn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, R1 = Re(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", yn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), qs = Re(/^!?\[(label)\]\[(ref)\]/).replace("label", yn).replace("ref", La).getRegex(), Ps = Re(/^!?\[(ref)\](?:\[\])?/).replace("ref", La).getRegex(), I1 = Re("reflink|nolink(?!\\()", "g").replace("reflink", qs).replace("nolink", Ps).getRegex(), Pa = {
  _backpedal: Sr,
  // only used for GFM url
  anyPunctuation: B1,
  autolink: M1,
  blockSkip: F1,
  br: Os,
  code: A1,
  del: Sr,
  emStrongLDelim: E1,
  emStrongRDelimAst: C1,
  emStrongRDelimUnd: T1,
  escape: Ls,
  link: R1,
  nolink: Ps,
  punctuation: S1,
  reflink: qs,
  reflinkSearch: I1,
  tag: N1,
  text: _1,
  url: Sr
}, L1 = {
  ...Pa,
  link: Re(/^!?\[(label)\]\((.*?)\)/).replace("label", yn).getRegex(),
  reflink: Re(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", yn).getRegex()
}, Ba = {
  ...Pa,
  escape: Re(Ls).replace("])", "~|])").getRegex(),
  url: Re(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, O1 = {
  ...Ba,
  br: Re(Os).replace("{2,}", "*").getRegex(),
  text: Re(Ba.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, cn = {
  normal: qa,
  gfm: x1,
  pedantic: D1
}, Ar = {
  normal: Pa,
  gfm: Ba,
  breaks: O1,
  pedantic: L1
};
class Yt {
  constructor(a) {
    Ue(this, "tokens");
    Ue(this, "options");
    Ue(this, "state");
    Ue(this, "tokenizer");
    Ue(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = a || U0, this.options.tokenizer = this.options.tokenizer || new bn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const i = {
      block: cn.normal,
      inline: Ar.normal
    };
    this.options.pedantic ? (i.block = cn.pedantic, i.inline = Ar.pedantic) : this.options.gfm && (i.block = cn.gfm, this.options.breaks ? i.inline = Ar.breaks : i.inline = Ar.gfm), this.tokenizer.rules = i;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: cn,
      inline: Ar
    };
  }
  /**
   * Static Lex Method
   */
  static lex(a, i) {
    return new Yt(i).lex(a);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(a, i) {
    return new Yt(i).inlineTokens(a);
  }
  /**
   * Preprocessing
   */
  lex(a) {
    a = a.replace(/\r\n|\r/g, `
`), this.blockTokens(a, this.tokens);
    for (let i = 0; i < this.inlineQueue.length; i++) {
      const l = this.inlineQueue[i];
      this.inlineTokens(l.src, l.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(a, i = []) {
    this.options.pedantic ? a = a.replace(/\t/g, "    ").replace(/^ +$/gm, "") : a = a.replace(/^( *)(\t+)/gm, (v, y, D) => y + "    ".repeat(D.length));
    let l, m, c, p;
    for (; a; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((v) => (l = v.call({ lexer: this }, a, i)) ? (a = a.substring(l.raw.length), i.push(l), !0) : !1))) {
        if (l = this.tokenizer.space(a)) {
          a = a.substring(l.raw.length), l.raw.length === 1 && i.length > 0 ? i[i.length - 1].raw += `
` : i.push(l);
          continue;
        }
        if (l = this.tokenizer.code(a)) {
          a = a.substring(l.raw.length), m = i[i.length - 1], m && (m.type === "paragraph" || m.type === "text") ? (m.raw += `
` + l.raw, m.text += `
` + l.text, this.inlineQueue[this.inlineQueue.length - 1].src = m.text) : i.push(l);
          continue;
        }
        if (l = this.tokenizer.fences(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.heading(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.hr(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.blockquote(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.list(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.html(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.def(a)) {
          a = a.substring(l.raw.length), m = i[i.length - 1], m && (m.type === "paragraph" || m.type === "text") ? (m.raw += `
` + l.raw, m.text += `
` + l.raw, this.inlineQueue[this.inlineQueue.length - 1].src = m.text) : this.tokens.links[l.tag] || (this.tokens.links[l.tag] = {
            href: l.href,
            title: l.title
          });
          continue;
        }
        if (l = this.tokenizer.table(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.lheading(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (c = a, this.options.extensions && this.options.extensions.startBlock) {
          let v = 1 / 0;
          const y = a.slice(1);
          let D;
          this.options.extensions.startBlock.forEach((C) => {
            D = C.call({ lexer: this }, y), typeof D == "number" && D >= 0 && (v = Math.min(v, D));
          }), v < 1 / 0 && v >= 0 && (c = a.substring(0, v + 1));
        }
        if (this.state.top && (l = this.tokenizer.paragraph(c))) {
          m = i[i.length - 1], p && m.type === "paragraph" ? (m.raw += `
` + l.raw, m.text += `
` + l.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = m.text) : i.push(l), p = c.length !== a.length, a = a.substring(l.raw.length);
          continue;
        }
        if (l = this.tokenizer.text(a)) {
          a = a.substring(l.raw.length), m = i[i.length - 1], m && m.type === "text" ? (m.raw += `
` + l.raw, m.text += `
` + l.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = m.text) : i.push(l);
          continue;
        }
        if (a) {
          const v = "Infinite loop on byte: " + a.charCodeAt(0);
          if (this.options.silent) {
            console.error(v);
            break;
          } else
            throw new Error(v);
        }
      }
    return this.state.top = !0, i;
  }
  inline(a, i = []) {
    return this.inlineQueue.push({ src: a, tokens: i }), i;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(a, i = []) {
    let l, m, c, p = a, v, y, D;
    if (this.tokens.links) {
      const C = Object.keys(this.tokens.links);
      if (C.length > 0)
        for (; (v = this.tokenizer.rules.inline.reflinkSearch.exec(p)) != null; )
          C.includes(v[0].slice(v[0].lastIndexOf("[") + 1, -1)) && (p = p.slice(0, v.index) + "[" + "a".repeat(v[0].length - 2) + "]" + p.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (v = this.tokenizer.rules.inline.blockSkip.exec(p)) != null; )
      p = p.slice(0, v.index) + "[" + "a".repeat(v[0].length - 2) + "]" + p.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (v = this.tokenizer.rules.inline.anyPunctuation.exec(p)) != null; )
      p = p.slice(0, v.index) + "++" + p.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; a; )
      if (y || (D = ""), y = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((C) => (l = C.call({ lexer: this }, a, i)) ? (a = a.substring(l.raw.length), i.push(l), !0) : !1))) {
        if (l = this.tokenizer.escape(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.tag(a)) {
          a = a.substring(l.raw.length), m = i[i.length - 1], m && l.type === "text" && m.type === "text" ? (m.raw += l.raw, m.text += l.text) : i.push(l);
          continue;
        }
        if (l = this.tokenizer.link(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.reflink(a, this.tokens.links)) {
          a = a.substring(l.raw.length), m = i[i.length - 1], m && l.type === "text" && m.type === "text" ? (m.raw += l.raw, m.text += l.text) : i.push(l);
          continue;
        }
        if (l = this.tokenizer.emStrong(a, p, D)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.codespan(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.br(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.del(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (l = this.tokenizer.autolink(a)) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (!this.state.inLink && (l = this.tokenizer.url(a))) {
          a = a.substring(l.raw.length), i.push(l);
          continue;
        }
        if (c = a, this.options.extensions && this.options.extensions.startInline) {
          let C = 1 / 0;
          const P = a.slice(1);
          let H;
          this.options.extensions.startInline.forEach((W) => {
            H = W.call({ lexer: this }, P), typeof H == "number" && H >= 0 && (C = Math.min(C, H));
          }), C < 1 / 0 && C >= 0 && (c = a.substring(0, C + 1));
        }
        if (l = this.tokenizer.inlineText(c)) {
          a = a.substring(l.raw.length), l.raw.slice(-1) !== "_" && (D = l.raw.slice(-1)), y = !0, m = i[i.length - 1], m && m.type === "text" ? (m.raw += l.raw, m.text += l.text) : i.push(l);
          continue;
        }
        if (a) {
          const C = "Infinite loop on byte: " + a.charCodeAt(0);
          if (this.options.silent) {
            console.error(C);
            break;
          } else
            throw new Error(C);
        }
      }
    return i;
  }
}
class wn {
  constructor(a) {
    Ue(this, "options");
    this.options = a || U0;
  }
  code(a, i, l) {
    var c;
    const m = (c = (i || "").match(/^\S*/)) == null ? void 0 : c[0];
    return a = a.replace(/\n$/, "") + `
`, m ? '<pre><code class="language-' + bt(m) + '">' + (l ? a : bt(a, !0)) + `</code></pre>
` : "<pre><code>" + (l ? a : bt(a, !0)) + `</code></pre>
`;
  }
  blockquote(a) {
    return `<blockquote>
${a}</blockquote>
`;
  }
  html(a, i) {
    return a;
  }
  heading(a, i, l) {
    return `<h${i}>${a}</h${i}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(a, i, l) {
    const m = i ? "ol" : "ul", c = i && l !== 1 ? ' start="' + l + '"' : "";
    return "<" + m + c + `>
` + a + "</" + m + `>
`;
  }
  listitem(a, i, l) {
    return `<li>${a}</li>
`;
  }
  checkbox(a) {
    return "<input " + (a ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(a) {
    return `<p>${a}</p>
`;
  }
  table(a, i) {
    return i && (i = `<tbody>${i}</tbody>`), `<table>
<thead>
` + a + `</thead>
` + i + `</table>
`;
  }
  tablerow(a) {
    return `<tr>
${a}</tr>
`;
  }
  tablecell(a, i) {
    const l = i.header ? "th" : "td";
    return (i.align ? `<${l} align="${i.align}">` : `<${l}>`) + a + `</${l}>
`;
  }
  /**
   * span level renderer
   */
  strong(a) {
    return `<strong>${a}</strong>`;
  }
  em(a) {
    return `<em>${a}</em>`;
  }
  codespan(a) {
    return `<code>${a}</code>`;
  }
  br() {
    return "<br>";
  }
  del(a) {
    return `<del>${a}</del>`;
  }
  link(a, i, l) {
    const m = kl(a);
    if (m === null)
      return l;
    a = m;
    let c = '<a href="' + a + '"';
    return i && (c += ' title="' + i + '"'), c += ">" + l + "</a>", c;
  }
  image(a, i, l) {
    const m = kl(a);
    if (m === null)
      return l;
    a = m;
    let c = `<img src="${a}" alt="${l}"`;
    return i && (c += ` title="${i}"`), c += ">", c;
  }
  text(a) {
    return a;
  }
}
class Ha {
  // no need for block level renderers
  strong(a) {
    return a;
  }
  em(a) {
    return a;
  }
  codespan(a) {
    return a;
  }
  del(a) {
    return a;
  }
  html(a) {
    return a;
  }
  text(a) {
    return a;
  }
  link(a, i, l) {
    return "" + l;
  }
  image(a, i, l) {
    return "" + l;
  }
  br() {
    return "";
  }
}
class Xt {
  constructor(a) {
    Ue(this, "options");
    Ue(this, "renderer");
    Ue(this, "textRenderer");
    this.options = a || U0, this.options.renderer = this.options.renderer || new wn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Ha();
  }
  /**
   * Static Parse Method
   */
  static parse(a, i) {
    return new Xt(i).parse(a);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(a, i) {
    return new Xt(i).parseInline(a);
  }
  /**
   * Parse Loop
   */
  parse(a, i = !0) {
    let l = "";
    for (let m = 0; m < a.length; m++) {
      const c = a[m];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[c.type]) {
        const p = c, v = this.options.extensions.renderers[p.type].call({ parser: this }, p);
        if (v !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(p.type)) {
          l += v || "";
          continue;
        }
      }
      switch (c.type) {
        case "space":
          continue;
        case "hr": {
          l += this.renderer.hr();
          continue;
        }
        case "heading": {
          const p = c;
          l += this.renderer.heading(this.parseInline(p.tokens), p.depth, u1(this.parseInline(p.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const p = c;
          l += this.renderer.code(p.text, p.lang, !!p.escaped);
          continue;
        }
        case "table": {
          const p = c;
          let v = "", y = "";
          for (let C = 0; C < p.header.length; C++)
            y += this.renderer.tablecell(this.parseInline(p.header[C].tokens), { header: !0, align: p.align[C] });
          v += this.renderer.tablerow(y);
          let D = "";
          for (let C = 0; C < p.rows.length; C++) {
            const P = p.rows[C];
            y = "";
            for (let H = 0; H < P.length; H++)
              y += this.renderer.tablecell(this.parseInline(P[H].tokens), { header: !1, align: p.align[H] });
            D += this.renderer.tablerow(y);
          }
          l += this.renderer.table(v, D);
          continue;
        }
        case "blockquote": {
          const p = c, v = this.parse(p.tokens);
          l += this.renderer.blockquote(v);
          continue;
        }
        case "list": {
          const p = c, v = p.ordered, y = p.start, D = p.loose;
          let C = "";
          for (let P = 0; P < p.items.length; P++) {
            const H = p.items[P], W = H.checked, se = H.task;
            let oe = "";
            if (H.task) {
              const ae = this.renderer.checkbox(!!W);
              D ? H.tokens.length > 0 && H.tokens[0].type === "paragraph" ? (H.tokens[0].text = ae + " " + H.tokens[0].text, H.tokens[0].tokens && H.tokens[0].tokens.length > 0 && H.tokens[0].tokens[0].type === "text" && (H.tokens[0].tokens[0].text = ae + " " + H.tokens[0].tokens[0].text)) : H.tokens.unshift({
                type: "text",
                text: ae + " "
              }) : oe += ae + " ";
            }
            oe += this.parse(H.tokens, D), C += this.renderer.listitem(oe, se, !!W);
          }
          l += this.renderer.list(C, v, y);
          continue;
        }
        case "html": {
          const p = c;
          l += this.renderer.html(p.text, p.block);
          continue;
        }
        case "paragraph": {
          const p = c;
          l += this.renderer.paragraph(this.parseInline(p.tokens));
          continue;
        }
        case "text": {
          let p = c, v = p.tokens ? this.parseInline(p.tokens) : p.text;
          for (; m + 1 < a.length && a[m + 1].type === "text"; )
            p = a[++m], v += `
` + (p.tokens ? this.parseInline(p.tokens) : p.text);
          l += i ? this.renderer.paragraph(v) : v;
          continue;
        }
        default: {
          const p = 'Token with "' + c.type + '" type was not found.';
          if (this.options.silent)
            return console.error(p), "";
          throw new Error(p);
        }
      }
    }
    return l;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(a, i) {
    i = i || this.renderer;
    let l = "";
    for (let m = 0; m < a.length; m++) {
      const c = a[m];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[c.type]) {
        const p = this.options.extensions.renderers[c.type].call({ parser: this }, c);
        if (p !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(c.type)) {
          l += p || "";
          continue;
        }
      }
      switch (c.type) {
        case "escape": {
          const p = c;
          l += i.text(p.text);
          break;
        }
        case "html": {
          const p = c;
          l += i.html(p.text);
          break;
        }
        case "link": {
          const p = c;
          l += i.link(p.href, p.title, this.parseInline(p.tokens, i));
          break;
        }
        case "image": {
          const p = c;
          l += i.image(p.href, p.title, p.text);
          break;
        }
        case "strong": {
          const p = c;
          l += i.strong(this.parseInline(p.tokens, i));
          break;
        }
        case "em": {
          const p = c;
          l += i.em(this.parseInline(p.tokens, i));
          break;
        }
        case "codespan": {
          const p = c;
          l += i.codespan(p.text);
          break;
        }
        case "br": {
          l += i.br();
          break;
        }
        case "del": {
          const p = c;
          l += i.del(this.parseInline(p.tokens, i));
          break;
        }
        case "text": {
          const p = c;
          l += i.text(p.text);
          break;
        }
        default: {
          const p = 'Token with "' + c.type + '" type was not found.';
          if (this.options.silent)
            return console.error(p), "";
          throw new Error(p);
        }
      }
    }
    return l;
  }
}
class Fr {
  constructor(a) {
    Ue(this, "options");
    this.options = a || U0;
  }
  /**
   * Process markdown before marked
   */
  preprocess(a) {
    return a;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(a) {
    return a;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(a) {
    return a;
  }
}
Ue(Fr, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Er, Ma, An, Us;
class Hs {
  constructor(...a) {
    da(this, Er);
    da(this, An);
    Ue(this, "defaults", Ra());
    Ue(this, "options", this.setOptions);
    Ue(this, "parse", an(this, Er, Ma).call(this, Yt.lex, Xt.parse));
    Ue(this, "parseInline", an(this, Er, Ma).call(this, Yt.lexInline, Xt.parseInline));
    Ue(this, "Parser", Xt);
    Ue(this, "Renderer", wn);
    Ue(this, "TextRenderer", Ha);
    Ue(this, "Lexer", Yt);
    Ue(this, "Tokenizer", bn);
    Ue(this, "Hooks", Fr);
    this.use(...a);
  }
  /**
   * Run callback for every token
   */
  walkTokens(a, i) {
    var m, c;
    let l = [];
    for (const p of a)
      switch (l = l.concat(i.call(this, p)), p.type) {
        case "table": {
          const v = p;
          for (const y of v.header)
            l = l.concat(this.walkTokens(y.tokens, i));
          for (const y of v.rows)
            for (const D of y)
              l = l.concat(this.walkTokens(D.tokens, i));
          break;
        }
        case "list": {
          const v = p;
          l = l.concat(this.walkTokens(v.items, i));
          break;
        }
        default: {
          const v = p;
          (c = (m = this.defaults.extensions) == null ? void 0 : m.childTokens) != null && c[v.type] ? this.defaults.extensions.childTokens[v.type].forEach((y) => {
            l = l.concat(this.walkTokens(v[y], i));
          }) : v.tokens && (l = l.concat(this.walkTokens(v.tokens, i)));
        }
      }
    return l;
  }
  use(...a) {
    const i = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return a.forEach((l) => {
      const m = { ...l };
      if (m.async = this.defaults.async || m.async || !1, l.extensions && (l.extensions.forEach((c) => {
        if (!c.name)
          throw new Error("extension name required");
        if ("renderer" in c) {
          const p = i.renderers[c.name];
          p ? i.renderers[c.name] = function(...v) {
            let y = c.renderer.apply(this, v);
            return y === !1 && (y = p.apply(this, v)), y;
          } : i.renderers[c.name] = c.renderer;
        }
        if ("tokenizer" in c) {
          if (!c.level || c.level !== "block" && c.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const p = i[c.level];
          p ? p.unshift(c.tokenizer) : i[c.level] = [c.tokenizer], c.start && (c.level === "block" ? i.startBlock ? i.startBlock.push(c.start) : i.startBlock = [c.start] : c.level === "inline" && (i.startInline ? i.startInline.push(c.start) : i.startInline = [c.start]));
        }
        "childTokens" in c && c.childTokens && (i.childTokens[c.name] = c.childTokens);
      }), m.extensions = i), l.renderer) {
        const c = this.defaults.renderer || new wn(this.defaults);
        for (const p in l.renderer) {
          if (!(p in c))
            throw new Error(`renderer '${p}' does not exist`);
          if (p === "options")
            continue;
          const v = p, y = l.renderer[v], D = c[v];
          c[v] = (...C) => {
            let P = y.apply(c, C);
            return P === !1 && (P = D.apply(c, C)), P || "";
          };
        }
        m.renderer = c;
      }
      if (l.tokenizer) {
        const c = this.defaults.tokenizer || new bn(this.defaults);
        for (const p in l.tokenizer) {
          if (!(p in c))
            throw new Error(`tokenizer '${p}' does not exist`);
          if (["options", "rules", "lexer"].includes(p))
            continue;
          const v = p, y = l.tokenizer[v], D = c[v];
          c[v] = (...C) => {
            let P = y.apply(c, C);
            return P === !1 && (P = D.apply(c, C)), P;
          };
        }
        m.tokenizer = c;
      }
      if (l.hooks) {
        const c = this.defaults.hooks || new Fr();
        for (const p in l.hooks) {
          if (!(p in c))
            throw new Error(`hook '${p}' does not exist`);
          if (p === "options")
            continue;
          const v = p, y = l.hooks[v], D = c[v];
          Fr.passThroughHooks.has(p) ? c[v] = (C) => {
            if (this.defaults.async)
              return Promise.resolve(y.call(c, C)).then((H) => D.call(c, H));
            const P = y.call(c, C);
            return D.call(c, P);
          } : c[v] = (...C) => {
            let P = y.apply(c, C);
            return P === !1 && (P = D.apply(c, C)), P;
          };
        }
        m.hooks = c;
      }
      if (l.walkTokens) {
        const c = this.defaults.walkTokens, p = l.walkTokens;
        m.walkTokens = function(v) {
          let y = [];
          return y.push(p.call(this, v)), c && (y = y.concat(c.call(this, v))), y;
        };
      }
      this.defaults = { ...this.defaults, ...m };
    }), this;
  }
  setOptions(a) {
    return this.defaults = { ...this.defaults, ...a }, this;
  }
  lexer(a, i) {
    return Yt.lex(a, i ?? this.defaults);
  }
  parser(a, i) {
    return Xt.parse(a, i ?? this.defaults);
  }
}
Er = new WeakSet(), Ma = function(a, i) {
  return (l, m) => {
    const c = { ...m }, p = { ...this.defaults, ...c };
    this.defaults.async === !0 && c.async === !1 && (p.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), p.async = !0);
    const v = an(this, An, Us).call(this, !!p.silent, !!p.async);
    if (typeof l > "u" || l === null)
      return v(new Error("marked(): input parameter is undefined or null"));
    if (typeof l != "string")
      return v(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(l) + ", string expected"));
    if (p.hooks && (p.hooks.options = p), p.async)
      return Promise.resolve(p.hooks ? p.hooks.preprocess(l) : l).then((y) => a(y, p)).then((y) => p.hooks ? p.hooks.processAllTokens(y) : y).then((y) => p.walkTokens ? Promise.all(this.walkTokens(y, p.walkTokens)).then(() => y) : y).then((y) => i(y, p)).then((y) => p.hooks ? p.hooks.postprocess(y) : y).catch(v);
    try {
      p.hooks && (l = p.hooks.preprocess(l));
      let y = a(l, p);
      p.hooks && (y = p.hooks.processAllTokens(y)), p.walkTokens && this.walkTokens(y, p.walkTokens);
      let D = i(y, p);
      return p.hooks && (D = p.hooks.postprocess(D)), D;
    } catch (y) {
      return v(y);
    }
  };
}, An = new WeakSet(), Us = function(a, i) {
  return (l) => {
    if (l.message += `
Please report this to https://github.com/markedjs/marked.`, a) {
      const m = "<p>An error occurred:</p><pre>" + bt(l.message + "", !0) + "</pre>";
      return i ? Promise.resolve(m) : m;
    }
    if (i)
      return Promise.reject(l);
    throw l;
  };
};
const H0 = new Hs();
function Ne(u, a) {
  return H0.parse(u, a);
}
Ne.options = Ne.setOptions = function(u) {
  return H0.setOptions(u), Ne.defaults = H0.defaults, Bs(Ne.defaults), Ne;
};
Ne.getDefaults = Ra;
Ne.defaults = U0;
Ne.use = function(...u) {
  return H0.use(...u), Ne.defaults = H0.defaults, Bs(Ne.defaults), Ne;
};
Ne.walkTokens = function(u, a) {
  return H0.walkTokens(u, a);
};
Ne.parseInline = H0.parseInline;
Ne.Parser = Xt;
Ne.parser = Xt.parse;
Ne.Renderer = wn;
Ne.TextRenderer = Ha;
Ne.Lexer = Yt;
Ne.lexer = Yt.lex;
Ne.Tokenizer = bn;
Ne.Hooks = Fr;
Ne.parse = Ne;
Ne.options;
Ne.setOptions;
Ne.use;
Ne.walkTokens;
Ne.parseInline;
Xt.parse;
Yt.lex;
function q1(u) {
  if (typeof u == "function" && (u = {
    highlight: u
  }), !u || typeof u.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof u.langPrefix != "string" && (u.langPrefix = "language-"), {
    async: !!u.async,
    walkTokens(a) {
      if (a.type !== "code")
        return;
      const i = _l(a.lang);
      if (u.async)
        return Promise.resolve(u.highlight(a.text, i, a.lang || "")).then(Sl(a));
      const l = u.highlight(a.text, i, a.lang || "");
      if (l instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      Sl(a)(l);
    },
    renderer: {
      code(a, i, l) {
        const m = _l(i), c = m ? ` class="${u.langPrefix}${El(m)}"` : "";
        return a = a.replace(/\n$/, ""), `<pre><code${c}>${l ? a : El(a, !0)}
</code></pre>`;
      }
    }
  };
}
function _l(u) {
  return (u || "").match(/\S*/)[0];
}
function Sl(u) {
  return (a) => {
    typeof a == "string" && a !== u.text && (u.escaped = !0, u.text = a);
  };
}
const Gs = /[&<>"']/, P1 = new RegExp(Gs.source, "g"), Vs = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, H1 = new RegExp(Vs.source, "g"), U1 = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Fl = (u) => U1[u];
function El(u, a) {
  if (a) {
    if (Gs.test(u))
      return u.replace(P1, Fl);
  } else if (Vs.test(u))
    return u.replace(H1, Fl);
  return u;
}
const G1 = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, V1 = Object.hasOwnProperty;
class Ws {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(a, i) {
    const l = this;
    let m = W1(a, i === !0);
    const c = m;
    for (; V1.call(l.occurrences, m); )
      l.occurrences[c]++, m = c + "-" + l.occurrences[c];
    return l.occurrences[m] = 0, m;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function W1(u, a) {
  return typeof u != "string" ? "" : (a || (u = u.toLowerCase()), u.replace(G1, "").replace(/ /g, "-"));
}
let Cl, Tl = [];
function Y1({ prefix: u = "" } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(a) {
        return Tl = [], Cl = new Ws(), a;
      }
    },
    renderer: {
      heading(a, i, l) {
        l = l.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const m = `${u}${Cl.slug(l)}`, c = { level: i, text: a, id: m };
        return Tl.push(c), `<h${i} id="${m}">${a}</h${i}>
`;
      }
    }
  };
}
var Ys = { exports: {} };
(function(u) {
  var a = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var i = function(l) {
    var m = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, c = 0, p = {}, v = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: l.Prism && l.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: l.Prism && l.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function B(S) {
          return S instanceof y ? new y(S.type, B(S.content), S.alias) : Array.isArray(S) ? S.map(B) : S.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(B) {
          return Object.prototype.toString.call(B).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(B) {
          return B.__id || Object.defineProperty(B, "__id", { value: ++c }), B.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function B(S, R) {
          R = R || {};
          var I, M;
          switch (v.util.type(S)) {
            case "Object":
              if (M = v.util.objId(S), R[M])
                return R[M];
              I = /** @type {Record<string, any>} */
              {}, R[M] = I;
              for (var X in S)
                S.hasOwnProperty(X) && (I[X] = B(S[X], R));
              return (
                /** @type {any} */
                I
              );
            case "Array":
              return M = v.util.objId(S), R[M] ? R[M] : (I = [], R[M] = I, /** @type {Array} */
              /** @type {any} */
              S.forEach(function($, j) {
                I[j] = B($, R);
              }), /** @type {any} */
              I);
            default:
              return S;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(B) {
          for (; B; ) {
            var S = m.exec(B.className);
            if (S)
              return S[1].toLowerCase();
            B = B.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(B, S) {
          B.className = B.className.replace(RegExp(m, "gi"), ""), B.classList.add("language-" + S);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document && 1 < 2)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (I) {
            var B = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(I.stack) || [])[1];
            if (B) {
              var S = document.getElementsByTagName("script");
              for (var R in S)
                if (S[R].src == B)
                  return S[R];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(B, S, R) {
          for (var I = "no-" + S; B; ) {
            var M = B.classList;
            if (M.contains(S))
              return !0;
            if (M.contains(I))
              return !1;
            B = B.parentElement;
          }
          return !!R;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: p,
        plaintext: p,
        text: p,
        txt: p,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(B, S) {
          var R = v.util.clone(v.languages[B]);
          for (var I in S)
            R[I] = S[I];
          return R;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(B, S, R, I) {
          I = I || /** @type {any} */
          v.languages;
          var M = I[B], X = {};
          for (var $ in M)
            if (M.hasOwnProperty($)) {
              if ($ == S)
                for (var j in R)
                  R.hasOwnProperty(j) && (X[j] = R[j]);
              R.hasOwnProperty($) || (X[$] = M[$]);
            }
          var he = I[B];
          return I[B] = X, v.languages.DFS(v.languages, function(ie, de) {
            de === he && ie != B && (this[ie] = X);
          }), X;
        },
        // Traverse a language definition with Depth First Search
        DFS: function B(S, R, I, M) {
          M = M || {};
          var X = v.util.objId;
          for (var $ in S)
            if (S.hasOwnProperty($)) {
              R.call(S, $, S[$], I || $);
              var j = S[$], he = v.util.type(j);
              he === "Object" && !M[X(j)] ? (M[X(j)] = !0, B(j, R, null, M)) : he === "Array" && !M[X(j)] && (M[X(j)] = !0, B(j, R, $, M));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(B, S) {
        v.highlightAllUnder(document, B, S);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(B, S, R) {
        var I = {
          callback: R,
          container: B,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        v.hooks.run("before-highlightall", I), I.elements = Array.prototype.slice.apply(I.container.querySelectorAll(I.selector)), v.hooks.run("before-all-elements-highlight", I);
        for (var M = 0, X; X = I.elements[M++]; )
          v.highlightElement(X, S === !0, I.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(B, S, R) {
        var I = v.util.getLanguage(B), M = v.languages[I];
        v.util.setLanguage(B, I);
        var X = B.parentElement;
        X && X.nodeName.toLowerCase() === "pre" && v.util.setLanguage(X, I);
        var $ = B.textContent, j = {
          element: B,
          language: I,
          grammar: M,
          code: $
        };
        function he(de) {
          j.highlightedCode = de, v.hooks.run("before-insert", j), j.element.innerHTML = j.highlightedCode, v.hooks.run("after-highlight", j), v.hooks.run("complete", j), R && R.call(j.element);
        }
        if (v.hooks.run("before-sanity-check", j), X = j.element.parentElement, X && X.nodeName.toLowerCase() === "pre" && !X.hasAttribute("tabindex") && X.setAttribute("tabindex", "0"), !j.code) {
          v.hooks.run("complete", j), R && R.call(j.element);
          return;
        }
        if (v.hooks.run("before-highlight", j), !j.grammar) {
          he(v.util.encode(j.code));
          return;
        }
        if (S && l.Worker) {
          var ie = new Worker(v.filename);
          ie.onmessage = function(de) {
            he(de.data);
          }, ie.postMessage(JSON.stringify({
            language: j.language,
            code: j.code,
            immediateClose: !0
          }));
        } else
          he(v.highlight(j.code, j.grammar, j.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(B, S, R) {
        var I = {
          code: B,
          grammar: S,
          language: R
        };
        if (v.hooks.run("before-tokenize", I), !I.grammar)
          throw new Error('The language "' + I.language + '" has no grammar.');
        return I.tokens = v.tokenize(I.code, I.grammar), v.hooks.run("after-tokenize", I), y.stringify(v.util.encode(I.tokens), I.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(B, S) {
        var R = S.rest;
        if (R) {
          for (var I in R)
            S[I] = R[I];
          delete S.rest;
        }
        var M = new P();
        return H(M, M.head, B), C(B, M, S, M.head, 0), se(M);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(B, S) {
          var R = v.hooks.all;
          R[B] = R[B] || [], R[B].push(S);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(B, S) {
          var R = v.hooks.all[B];
          if (!(!R || !R.length))
            for (var I = 0, M; M = R[I++]; )
              M(S);
        }
      },
      Token: y
    };
    l.Prism = v;
    function y(B, S, R, I) {
      this.type = B, this.content = S, this.alias = R, this.length = (I || "").length | 0;
    }
    y.stringify = function B(S, R) {
      if (typeof S == "string")
        return S;
      if (Array.isArray(S)) {
        var I = "";
        return S.forEach(function(he) {
          I += B(he, R);
        }), I;
      }
      var M = {
        type: S.type,
        content: B(S.content, R),
        tag: "span",
        classes: ["token", S.type],
        attributes: {},
        language: R
      }, X = S.alias;
      X && (Array.isArray(X) ? Array.prototype.push.apply(M.classes, X) : M.classes.push(X)), v.hooks.run("wrap", M);
      var $ = "";
      for (var j in M.attributes)
        $ += " " + j + '="' + (M.attributes[j] || "").replace(/"/g, "&quot;") + '"';
      return "<" + M.tag + ' class="' + M.classes.join(" ") + '"' + $ + ">" + M.content + "</" + M.tag + ">";
    };
    function D(B, S, R, I) {
      B.lastIndex = S;
      var M = B.exec(R);
      if (M && I && M[1]) {
        var X = M[1].length;
        M.index += X, M[0] = M[0].slice(X);
      }
      return M;
    }
    function C(B, S, R, I, M, X) {
      for (var $ in R)
        if (!(!R.hasOwnProperty($) || !R[$])) {
          var j = R[$];
          j = Array.isArray(j) ? j : [j];
          for (var he = 0; he < j.length; ++he) {
            if (X && X.cause == $ + "," + he)
              return;
            var ie = j[he], de = ie.inside, be = !!ie.lookbehind, Te = !!ie.greedy, Xe = ie.alias;
            if (Te && !ie.pattern.global) {
              var ue = ie.pattern.toString().match(/[imsuy]*$/)[0];
              ie.pattern = RegExp(ie.pattern.source, ue + "g");
            }
            for (var Ke = ie.pattern || ie, _e = I.next, Ae = M; _e !== S.tail && !(X && Ae >= X.reach); Ae += _e.value.length, _e = _e.next) {
              var Z = _e.value;
              if (S.length > B.length)
                return;
              if (!(Z instanceof y)) {
                var K = 1, Qe;
                if (Te) {
                  if (Qe = D(Ke, Ae, B, be), !Qe || Qe.index >= B.length)
                    break;
                  var ut = Qe.index, re = Qe.index + Qe[0].length, Je = Ae;
                  for (Je += _e.value.length; ut >= Je; )
                    _e = _e.next, Je += _e.value.length;
                  if (Je -= _e.value.length, Ae = Je, _e.value instanceof y)
                    continue;
                  for (var wt = _e; wt !== S.tail && (Je < re || typeof wt.value == "string"); wt = wt.next)
                    K++, Je += wt.value.length;
                  K--, Z = B.slice(Ae, Je), Qe.index -= Ae;
                } else if (Qe = D(Ke, 0, Z, be), !Qe)
                  continue;
                var ut = Qe.index, Ot = Qe[0], a0 = Z.slice(0, ut), B0 = Z.slice(ut + Ot.length), kt = Ae + Z.length;
                X && kt > X.reach && (X.reach = kt);
                var ct = _e.prev;
                a0 && (ct = H(S, ct, a0), Ae += a0.length), W(S, ct, K);
                var M0 = new y($, de ? v.tokenize(Ot, de) : Ot, Xe, Ot);
                if (_e = H(S, ct, M0), B0 && H(S, _e, B0), K > 1) {
                  var Qt = {
                    cause: $ + "," + he,
                    reach: kt
                  };
                  C(B, S, R, _e.prev, Ae, Qt), X && Qt.reach > X.reach && (X.reach = Qt.reach);
                }
              }
            }
          }
        }
    }
    function P() {
      var B = { value: null, prev: null, next: null }, S = { value: null, prev: B, next: null };
      B.next = S, this.head = B, this.tail = S, this.length = 0;
    }
    function H(B, S, R) {
      var I = S.next, M = { value: R, prev: S, next: I };
      return S.next = M, I.prev = M, B.length++, M;
    }
    function W(B, S, R) {
      for (var I = S.next, M = 0; M < R && I !== B.tail; M++)
        I = I.next;
      S.next = I, I.prev = S, B.length -= M;
    }
    function se(B) {
      for (var S = [], R = B.head.next; R !== B.tail; )
        S.push(R.value), R = R.next;
      return S;
    }
    if (!l.document)
      return l.addEventListener && (v.disableWorkerMessageHandler || l.addEventListener("message", function(B) {
        var S = JSON.parse(B.data), R = S.language, I = S.code, M = S.immediateClose;
        l.postMessage(v.highlight(I, v.languages[R], R)), M && l.close();
      }, !1)), v;
    var oe = v.util.currentScript();
    oe && (v.filename = oe.src, oe.hasAttribute("data-manual") && (v.manual = !0));
    function ae() {
      v.manual || v.highlightAll();
    }
    if (!v.manual) {
      var L = document.readyState;
      L === "loading" || L === "interactive" && oe && oe.defer ? document.addEventListener("DOMContentLoaded", ae) : window.requestAnimationFrame ? window.requestAnimationFrame(ae) : window.setTimeout(ae, 16);
    }
    return v;
  }(a);
  u.exports && (u.exports = i), typeof vn < "u" && (vn.Prism = i), i.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, i.languages.markup.tag.inside["attr-value"].inside.entity = i.languages.markup.entity, i.languages.markup.doctype.inside["internal-subset"].inside = i.languages.markup, i.hooks.add("wrap", function(l) {
    l.type === "entity" && (l.attributes.title = l.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(i.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(m, c) {
      var p = {};
      p["language-" + c] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: i.languages[c]
      }, p.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var v = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: p
        }
      };
      v["language-" + c] = {
        pattern: /[\s\S]+/,
        inside: i.languages[c]
      };
      var y = {};
      y[m] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return m;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: v
      }, i.languages.insertBefore("markup", "cdata", y);
    }
  }), Object.defineProperty(i.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(l, m) {
      i.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + l + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [m, "language-" + m],
                inside: i.languages[m]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), i.languages.html = i.languages.markup, i.languages.mathml = i.languages.markup, i.languages.svg = i.languages.markup, i.languages.xml = i.languages.extend("markup", {}), i.languages.ssml = i.languages.xml, i.languages.atom = i.languages.xml, i.languages.rss = i.languages.xml, function(l) {
    var m = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    l.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + m.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + m.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + m.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + m.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: m,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, l.languages.css.atrule.inside.rest = l.languages.css;
    var c = l.languages.markup;
    c && (c.tag.addInlined("style", "css"), c.tag.addAttribute("style", "css"));
  }(i), i.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, i.languages.javascript = i.languages.extend("clike", {
    "class-name": [
      i.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), i.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, i.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: i.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: i.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: i.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: i.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: i.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), i.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: i.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), i.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), i.languages.markup && (i.languages.markup.tag.addInlined("script", "javascript"), i.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), i.languages.js = i.languages.javascript, function() {
    if (typeof i > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var l = "Loading…", m = function(oe, ae) {
      return "✖ Error " + oe + " while fetching file: " + ae;
    }, c = "✖ Error: File does not exist or is empty", p = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, v = "data-src-status", y = "loading", D = "loaded", C = "failed", P = "pre[data-src]:not([" + v + '="' + D + '"]):not([' + v + '="' + y + '"])';
    function H(oe, ae, L) {
      var B = new XMLHttpRequest();
      B.open("GET", oe, !0), B.onreadystatechange = function() {
        B.readyState == 4 && (B.status < 400 && B.responseText ? ae(B.responseText) : B.status >= 400 ? L(m(B.status, B.statusText)) : L(c));
      }, B.send(null);
    }
    function W(oe) {
      var ae = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(oe || "");
      if (ae) {
        var L = Number(ae[1]), B = ae[2], S = ae[3];
        return B ? S ? [L, Number(S)] : [L, void 0] : [L, L];
      }
    }
    i.hooks.add("before-highlightall", function(oe) {
      oe.selector += ", " + P;
    }), i.hooks.add("before-sanity-check", function(oe) {
      var ae = (
        /** @type {HTMLPreElement} */
        oe.element
      );
      if (ae.matches(P)) {
        oe.code = "", ae.setAttribute(v, y);
        var L = ae.appendChild(document.createElement("CODE"));
        L.textContent = l;
        var B = ae.getAttribute("data-src"), S = oe.language;
        if (S === "none") {
          var R = (/\.(\w+)$/.exec(B) || [, "none"])[1];
          S = p[R] || R;
        }
        i.util.setLanguage(L, S), i.util.setLanguage(ae, S);
        var I = i.plugins.autoloader;
        I && I.loadLanguages(S), H(
          B,
          function(M) {
            ae.setAttribute(v, D);
            var X = W(ae.getAttribute("data-range"));
            if (X) {
              var $ = M.split(/\r\n?|\n/g), j = X[0], he = X[1] == null ? $.length : X[1];
              j < 0 && (j += $.length), j = Math.max(0, Math.min(j - 1, $.length)), he < 0 && (he += $.length), he = Math.max(0, Math.min(he, $.length)), M = $.slice(j, he).join(`
`), ae.hasAttribute("data-start") || ae.setAttribute("data-start", String(j + 1));
            }
            L.textContent = M, i.highlightElement(L);
          },
          function(M) {
            ae.setAttribute(v, C), L.textContent = M;
          }
        );
      }
    }), i.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(ae) {
        for (var L = (ae || document).querySelectorAll(P), B = 0, S; S = L[B++]; )
          i.highlightElement(S);
      }
    };
    var se = !1;
    i.fileHighlight = function() {
      se || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), se = !0), i.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Ys);
var X1 = Ys.exports;
const ka = /* @__PURE__ */ Cs(X1);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(u) {
  var a = /\\(?:[^a-z()[\]]|[a-z*]+)/i, i = {
    "equation-command": {
      pattern: a,
      alias: "regex"
    }
  };
  u.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: i,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: i,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: a,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, u.languages.tex = u.languages.latex, u.languages.context = u.languages.latex;
})(Prism);
(function(u) {
  var a = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", i = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, l = {
    bash: i,
    environment: {
      pattern: RegExp("\\$" + a),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + a),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  u.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + a),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: l
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: i
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: l
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: l.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + a),
      alias: "constant"
    },
    variable: l.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, i.inside = u.languages.bash;
  for (var m = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], c = l.variable[1].inside, p = 0; p < m.length; p++)
    c[m[p]] = u.languages.bash[m[p]];
  u.languages.sh = u.languages.bash, u.languages.shell = u.languages.bash;
})(Prism);
function Bl(u, a) {
  return u ?? a();
}
function j1(u) {
  let a, i = u[0], l = 1;
  for (; l < u.length; ) {
    const m = u[l], c = u[l + 1];
    if (l += 2, (m === "optionalAccess" || m === "optionalCall") && i == null)
      return;
    m === "access" || m === "optionalAccess" ? (a = i, i = c(i)) : (m === "call" || m === "optionalCall") && (i = c((...p) => i.call(a, ...p)), a = void 0);
  }
  return i;
}
const Z1 = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', K1 = `<svg
xmlns="http://www.w3.org/2000/svg"
width="100%"
height="100%"
viewBox="0 0 32 32"
><path
  fill="currentColor"
  d="M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"
/><path fill="currentColor" d="M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z" /></svg>`, Q1 = `<svg
xmlns="http://www.w3.org/2000/svg"
width="100%"
height="100%"
viewBox="0 0 24 24"
fill="none"
stroke="currentColor"
stroke-width="3"
stroke-linecap="round"
stroke-linejoin="round"><polyline points="20 6 9 17 4 12" /></svg>`, Ml = `<button title="copy" class="copy_code_button">
<span class="copy-text">${K1}</span>
<span class="check">${Q1}</span>
</button>`, Xs = /[&<>"']/, J1 = new RegExp(Xs.source, "g"), js = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, $1 = new RegExp(js.source, "g"), e4 = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, zl = (u) => e4[u] || "";
function xa(u, a) {
  if (a) {
    if (Xs.test(u))
      return u.replace(J1, zl);
  } else if (js.test(u))
    return u.replace($1, zl);
  return u;
}
const t4 = {
  code(u, a, i) {
    const l = Bl(j1([Bl(a, () => ""), "access", (m) => m.match, "call", (m) => m(/\S*/), "optionalAccess", (m) => m[0]]), () => "");
    return u = u.replace(/\n$/, "") + `
`, l ? '<div class="code_wrap">' + Ml + '<pre><code class="language-' + xa(l) + '">' + (i ? u : xa(u, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + Ml + "<pre><code>" + (i ? u : xa(u, !0)) + `</code></pre></div>
`;
  }
}, r4 = new Ws();
function n4({
  header_links: u,
  line_breaks: a
}) {
  const i = new Hs();
  return i.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: a
    },
    q1({
      highlight: (l, m) => ka.languages[m] ? ka.highlight(l, ka.languages[m], m) : l
    }),
    { renderer: t4 }
  ), u && (i.use(Y1()), i.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(l) {
          const m = l.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), c = "h" + r4.slug(m), p = l.depth, v = this.parser.parseInline(l.tokens);
          return `<h${p} id="${c}"><a class="md-header-anchor" href="#${c}">${Z1}</a>${v}</h${p}>
`;
        }
      }
    ]
  })), i;
}
const {
  HtmlTag: a4,
  SvelteComponent: i4,
  attr: l4,
  binding_callbacks: s4,
  detach: Ua,
  element: o4,
  empty: u4,
  init: c4,
  insert: Ga,
  noop: Nl,
  safe_not_equal: h4,
  set_data: f4,
  text: m4,
  toggle_class: Rl
} = window.__gradio__svelte__internal, { afterUpdate: d4, createEventDispatcher: Rh } = window.__gradio__svelte__internal;
function p4(u) {
  let a;
  return {
    c() {
      a = m4(
        /*html*/
        u[3]
      );
    },
    m(i, l) {
      Ga(i, a, l);
    },
    p(i, l) {
      l & /*html*/
      8 && f4(
        a,
        /*html*/
        i[3]
      );
    },
    d(i) {
      i && Ua(a);
    }
  };
}
function g4(u) {
  let a, i;
  return {
    c() {
      a = new a4(!1), i = u4(), a.a = i;
    },
    m(l, m) {
      a.m(
        /*html*/
        u[3],
        l,
        m
      ), Ga(l, i, m);
    },
    p(l, m) {
      m & /*html*/
      8 && a.p(
        /*html*/
        l[3]
      );
    },
    d(l) {
      l && (Ua(i), a.d());
    }
  };
}
function v4(u) {
  let a;
  function i(c, p) {
    return (
      /*render_markdown*/
      c[1] ? g4 : p4
    );
  }
  let l = i(u), m = l(u);
  return {
    c() {
      a = o4("span"), m.c(), l4(a, "class", "md svelte-1h1pkb5"), Rl(
        a,
        "chatbot",
        /*chatbot*/
        u[0]
      );
    },
    m(c, p) {
      Ga(c, a, p), m.m(a, null), u[9](a);
    },
    p(c, [p]) {
      l === (l = i(c)) && m ? m.p(c, p) : (m.d(1), m = l(c), m && (m.c(), m.m(a, null))), p & /*chatbot*/
      1 && Rl(
        a,
        "chatbot",
        /*chatbot*/
        c[0]
      );
    },
    i: Nl,
    o: Nl,
    d(c) {
      c && Ua(a), m.d(), u[9](null);
    }
  };
}
function b4(u, a, i) {
  let { chatbot: l = !0 } = a, { message: m } = a, { sanitize_html: c = !0 } = a, { latex_delimiters: p = [] } = a, { render_markdown: v = !0 } = a, { line_breaks: y = !0 } = a, { header_links: D = !1 } = a, C, P;
  const H = n4({ header_links: D, line_breaks: y }), W = (L) => !!(L && new URL(L, location.href).origin !== location.origin);
  bl.addHook("afterSanitizeAttributes", function(L) {
    "target" in L && W(L.getAttribute("href")) && (L.setAttribute("target", "_blank"), L.setAttribute("rel", "noopener noreferrer"));
  });
  function se(L) {
    return v && (L = H.parse(L)), c && (L = bl.sanitize(L)), L;
  }
  async function oe(L) {
    p.length > 0 && L && a1(C, {
      delimiters: p,
      throwOnError: !1
    });
  }
  d4(() => oe(m));
  function ae(L) {
    s4[L ? "unshift" : "push"](() => {
      C = L, i(2, C);
    });
  }
  return u.$$set = (L) => {
    "chatbot" in L && i(0, l = L.chatbot), "message" in L && i(4, m = L.message), "sanitize_html" in L && i(5, c = L.sanitize_html), "latex_delimiters" in L && i(6, p = L.latex_delimiters), "render_markdown" in L && i(1, v = L.render_markdown), "line_breaks" in L && i(7, y = L.line_breaks), "header_links" in L && i(8, D = L.header_links);
  }, u.$$.update = () => {
    u.$$.dirty & /*message*/
    16 && (m && m.trim() ? i(3, P = se(m)) : i(3, P = ""));
  }, [
    l,
    v,
    C,
    P,
    m,
    c,
    p,
    y,
    D,
    ae
  ];
}
class y4 extends i4 {
  constructor(a) {
    super(), c4(this, a, b4, v4, h4, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8
    });
  }
}
function ar(u) {
  let a = ["", "k", "M", "G", "T", "P", "E", "Z"], i = 0;
  for (; u > 1e3 && i < a.length - 1; )
    u /= 1e3, i++;
  let l = a[i];
  return (Number.isInteger(u) ? u : u.toFixed(1)) + l;
}
function gn() {
}
function w4(u, a) {
  return u != u ? a == a : u !== a || u && typeof u == "object" || typeof u == "function";
}
const Zs = typeof window < "u";
let Il = Zs ? () => window.performance.now() : () => Date.now(), Ks = Zs ? (u) => requestAnimationFrame(u) : gn;
const ir = /* @__PURE__ */ new Set();
function Qs(u) {
  ir.forEach((a) => {
    a.c(u) || (ir.delete(a), a.f());
  }), ir.size !== 0 && Ks(Qs);
}
function k4(u) {
  let a;
  return ir.size === 0 && Ks(Qs), {
    promise: new Promise((i) => {
      ir.add(a = { c: u, f: i });
    }),
    abort() {
      ir.delete(a);
    }
  };
}
const rr = [];
function x4(u, a = gn) {
  let i;
  const l = /* @__PURE__ */ new Set();
  function m(v) {
    if (w4(u, v) && (u = v, i)) {
      const y = !rr.length;
      for (const D of l)
        D[1](), rr.push(D, u);
      if (y) {
        for (let D = 0; D < rr.length; D += 2)
          rr[D][0](rr[D + 1]);
        rr.length = 0;
      }
    }
  }
  function c(v) {
    m(v(u));
  }
  function p(v, y = gn) {
    const D = [v, y];
    return l.add(D), l.size === 1 && (i = a(m, c) || gn), v(u), () => {
      l.delete(D), l.size === 0 && i && (i(), i = null);
    };
  }
  return { set: m, update: c, subscribe: p };
}
function Ll(u) {
  return Object.prototype.toString.call(u) === "[object Date]";
}
function za(u, a, i, l) {
  if (typeof i == "number" || Ll(i)) {
    const m = l - i, c = (i - a) / (u.dt || 1 / 60), p = u.opts.stiffness * m, v = u.opts.damping * c, y = (p - v) * u.inv_mass, D = (c + y) * u.dt;
    return Math.abs(D) < u.opts.precision && Math.abs(m) < u.opts.precision ? l : (u.settled = !1, Ll(i) ? new Date(i.getTime() + D) : i + D);
  } else {
    if (Array.isArray(i))
      return i.map(
        (m, c) => za(u, a[c], i[c], l[c])
      );
    if (typeof i == "object") {
      const m = {};
      for (const c in i)
        m[c] = za(u, a[c], i[c], l[c]);
      return m;
    } else
      throw new Error(`Cannot spring ${typeof i} values`);
  }
}
function Ol(u, a = {}) {
  const i = x4(u), { stiffness: l = 0.15, damping: m = 0.8, precision: c = 0.01 } = a;
  let p, v, y, D = u, C = u, P = 1, H = 0, W = !1;
  function se(ae, L = {}) {
    C = ae;
    const B = y = {};
    return u == null || L.hard || oe.stiffness >= 1 && oe.damping >= 1 ? (W = !0, p = Il(), D = ae, i.set(u = C), Promise.resolve()) : (L.soft && (H = 1 / ((L.soft === !0 ? 0.5 : +L.soft) * 60), P = 0), v || (p = Il(), W = !1, v = k4((S) => {
      if (W)
        return W = !1, v = null, !1;
      P = Math.min(P + H, 1);
      const R = {
        inv_mass: P,
        opts: oe,
        settled: !0,
        dt: (S - p) * 60 / 1e3
      }, I = za(R, D, u, C);
      return p = S, D = u, i.set(u = I), R.settled && (v = null), !R.settled;
    })), new Promise((S) => {
      v.promise.then(() => {
        B === y && S();
      });
    }));
  }
  const oe = {
    set: se,
    update: (ae, L) => se(ae(C, u), L),
    subscribe: i.subscribe,
    stiffness: l,
    damping: m,
    precision: c
  };
  return oe;
}
const {
  SvelteComponent: D4,
  append: Rt,
  attr: Ee,
  component_subscribe: ql,
  detach: A4,
  element: _4,
  init: S4,
  insert: F4,
  noop: Pl,
  safe_not_equal: E4,
  set_style: hn,
  svg_element: It,
  toggle_class: Hl
} = window.__gradio__svelte__internal, { onMount: C4 } = window.__gradio__svelte__internal;
function T4(u) {
  let a, i, l, m, c, p, v, y, D, C, P, H;
  return {
    c() {
      a = _4("div"), i = It("svg"), l = It("g"), m = It("path"), c = It("path"), p = It("path"), v = It("path"), y = It("g"), D = It("path"), C = It("path"), P = It("path"), H = It("path"), Ee(m, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), Ee(m, "fill", "#FF7C00"), Ee(m, "fill-opacity", "0.4"), Ee(m, "class", "svelte-43sxxs"), Ee(c, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), Ee(c, "fill", "#FF7C00"), Ee(c, "class", "svelte-43sxxs"), Ee(p, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), Ee(p, "fill", "#FF7C00"), Ee(p, "fill-opacity", "0.4"), Ee(p, "class", "svelte-43sxxs"), Ee(v, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), Ee(v, "fill", "#FF7C00"), Ee(v, "class", "svelte-43sxxs"), hn(l, "transform", "translate(" + /*$top*/
      u[1][0] + "px, " + /*$top*/
      u[1][1] + "px)"), Ee(D, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), Ee(D, "fill", "#FF7C00"), Ee(D, "fill-opacity", "0.4"), Ee(D, "class", "svelte-43sxxs"), Ee(C, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), Ee(C, "fill", "#FF7C00"), Ee(C, "class", "svelte-43sxxs"), Ee(P, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), Ee(P, "fill", "#FF7C00"), Ee(P, "fill-opacity", "0.4"), Ee(P, "class", "svelte-43sxxs"), Ee(H, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), Ee(H, "fill", "#FF7C00"), Ee(H, "class", "svelte-43sxxs"), hn(y, "transform", "translate(" + /*$bottom*/
      u[2][0] + "px, " + /*$bottom*/
      u[2][1] + "px)"), Ee(i, "viewBox", "-1200 -1200 3000 3000"), Ee(i, "fill", "none"), Ee(i, "xmlns", "http://www.w3.org/2000/svg"), Ee(i, "class", "svelte-43sxxs"), Ee(a, "class", "svelte-43sxxs"), Hl(
        a,
        "margin",
        /*margin*/
        u[0]
      );
    },
    m(W, se) {
      F4(W, a, se), Rt(a, i), Rt(i, l), Rt(l, m), Rt(l, c), Rt(l, p), Rt(l, v), Rt(i, y), Rt(y, D), Rt(y, C), Rt(y, P), Rt(y, H);
    },
    p(W, [se]) {
      se & /*$top*/
      2 && hn(l, "transform", "translate(" + /*$top*/
      W[1][0] + "px, " + /*$top*/
      W[1][1] + "px)"), se & /*$bottom*/
      4 && hn(y, "transform", "translate(" + /*$bottom*/
      W[2][0] + "px, " + /*$bottom*/
      W[2][1] + "px)"), se & /*margin*/
      1 && Hl(
        a,
        "margin",
        /*margin*/
        W[0]
      );
    },
    i: Pl,
    o: Pl,
    d(W) {
      W && A4(a);
    }
  };
}
function B4(u, a, i) {
  let l, m, { margin: c = !0 } = a;
  const p = Ol([0, 0]);
  ql(u, p, (H) => i(1, l = H));
  const v = Ol([0, 0]);
  ql(u, v, (H) => i(2, m = H));
  let y;
  async function D() {
    await Promise.all([p.set([125, 140]), v.set([-125, -140])]), await Promise.all([p.set([-125, 140]), v.set([125, -140])]), await Promise.all([p.set([-125, 0]), v.set([125, -0])]), await Promise.all([p.set([125, 0]), v.set([-125, 0])]);
  }
  async function C() {
    await D(), y || C();
  }
  async function P() {
    await Promise.all([p.set([125, 0]), v.set([-125, 0])]), C();
  }
  return C4(() => (P(), () => y = !0)), u.$$set = (H) => {
    "margin" in H && i(0, c = H.margin);
  }, [c, l, m, p, v];
}
class M4 extends D4 {
  constructor(a) {
    super(), S4(this, a, B4, T4, E4, { margin: 0 });
  }
}
const {
  SvelteComponent: z4,
  append: P0,
  attr: jt,
  binding_callbacks: Ul,
  check_outros: Js,
  create_component: N4,
  create_slot: R4,
  destroy_component: I4,
  destroy_each: $s,
  detach: ke,
  element: n0,
  empty: or,
  ensure_array_like: kn,
  get_all_dirty_from_scope: L4,
  get_slot_changes: O4,
  group_outros: eo,
  init: q4,
  insert: xe,
  mount_component: P4,
  noop: Na,
  safe_not_equal: H4,
  set_data: Mt,
  set_style: _0,
  space: Zt,
  text: We,
  toggle_class: Ct,
  transition_in: lr,
  transition_out: sr,
  update_slot_base: U4
} = window.__gradio__svelte__internal, { tick: G4 } = window.__gradio__svelte__internal, { onDestroy: V4 } = window.__gradio__svelte__internal, W4 = (u) => ({}), Gl = (u) => ({});
function Vl(u, a, i) {
  const l = u.slice();
  return l[38] = a[i], l[40] = i, l;
}
function Wl(u, a, i) {
  const l = u.slice();
  return l[38] = a[i], l;
}
function Y4(u) {
  let a, i = (
    /*i18n*/
    u[1]("common.error") + ""
  ), l, m, c;
  const p = (
    /*#slots*/
    u[29].error
  ), v = R4(
    p,
    u,
    /*$$scope*/
    u[28],
    Gl
  );
  return {
    c() {
      a = n0("span"), l = We(i), m = Zt(), v && v.c(), jt(a, "class", "error svelte-1txqlrd");
    },
    m(y, D) {
      xe(y, a, D), P0(a, l), xe(y, m, D), v && v.m(y, D), c = !0;
    },
    p(y, D) {
      (!c || D[0] & /*i18n*/
      2) && i !== (i = /*i18n*/
      y[1]("common.error") + "") && Mt(l, i), v && v.p && (!c || D[0] & /*$$scope*/
      268435456) && U4(
        v,
        p,
        y,
        /*$$scope*/
        y[28],
        c ? O4(
          p,
          /*$$scope*/
          y[28],
          D,
          W4
        ) : L4(
          /*$$scope*/
          y[28]
        ),
        Gl
      );
    },
    i(y) {
      c || (lr(v, y), c = !0);
    },
    o(y) {
      sr(v, y), c = !1;
    },
    d(y) {
      y && (ke(a), ke(m)), v && v.d(y);
    }
  };
}
function X4(u) {
  let a, i, l, m, c, p, v, y, D, C = (
    /*variant*/
    u[8] === "default" && /*show_eta_bar*/
    u[18] && /*show_progress*/
    u[6] === "full" && Yl(u)
  );
  function P(S, R) {
    if (
      /*progress*/
      S[7]
    )
      return K4;
    if (
      /*queue_position*/
      S[2] !== null && /*queue_size*/
      S[3] !== void 0 && /*queue_position*/
      S[2] >= 0
    )
      return Z4;
    if (
      /*queue_position*/
      S[2] === 0
    )
      return j4;
  }
  let H = P(u), W = H && H(u), se = (
    /*timer*/
    u[5] && Zl(u)
  );
  const oe = [ec, $4], ae = [];
  function L(S, R) {
    return (
      /*last_progress_level*/
      S[15] != null ? 0 : (
        /*show_progress*/
        S[6] === "full" ? 1 : -1
      )
    );
  }
  ~(c = L(u)) && (p = ae[c] = oe[c](u));
  let B = !/*timer*/
  u[5] && rs(u);
  return {
    c() {
      C && C.c(), a = Zt(), i = n0("div"), W && W.c(), l = Zt(), se && se.c(), m = Zt(), p && p.c(), v = Zt(), B && B.c(), y = or(), jt(i, "class", "progress-text svelte-1txqlrd"), Ct(
        i,
        "meta-text-center",
        /*variant*/
        u[8] === "center"
      ), Ct(
        i,
        "meta-text",
        /*variant*/
        u[8] === "default"
      );
    },
    m(S, R) {
      C && C.m(S, R), xe(S, a, R), xe(S, i, R), W && W.m(i, null), P0(i, l), se && se.m(i, null), xe(S, m, R), ~c && ae[c].m(S, R), xe(S, v, R), B && B.m(S, R), xe(S, y, R), D = !0;
    },
    p(S, R) {
      /*variant*/
      S[8] === "default" && /*show_eta_bar*/
      S[18] && /*show_progress*/
      S[6] === "full" ? C ? C.p(S, R) : (C = Yl(S), C.c(), C.m(a.parentNode, a)) : C && (C.d(1), C = null), H === (H = P(S)) && W ? W.p(S, R) : (W && W.d(1), W = H && H(S), W && (W.c(), W.m(i, l))), /*timer*/
      S[5] ? se ? se.p(S, R) : (se = Zl(S), se.c(), se.m(i, null)) : se && (se.d(1), se = null), (!D || R[0] & /*variant*/
      256) && Ct(
        i,
        "meta-text-center",
        /*variant*/
        S[8] === "center"
      ), (!D || R[0] & /*variant*/
      256) && Ct(
        i,
        "meta-text",
        /*variant*/
        S[8] === "default"
      );
      let I = c;
      c = L(S), c === I ? ~c && ae[c].p(S, R) : (p && (eo(), sr(ae[I], 1, 1, () => {
        ae[I] = null;
      }), Js()), ~c ? (p = ae[c], p ? p.p(S, R) : (p = ae[c] = oe[c](S), p.c()), lr(p, 1), p.m(v.parentNode, v)) : p = null), /*timer*/
      S[5] ? B && (B.d(1), B = null) : B ? B.p(S, R) : (B = rs(S), B.c(), B.m(y.parentNode, y));
    },
    i(S) {
      D || (lr(p), D = !0);
    },
    o(S) {
      sr(p), D = !1;
    },
    d(S) {
      S && (ke(a), ke(i), ke(m), ke(v), ke(y)), C && C.d(S), W && W.d(), se && se.d(), ~c && ae[c].d(S), B && B.d(S);
    }
  };
}
function Yl(u) {
  let a, i = `translateX(${/*eta_level*/
  (u[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      a = n0("div"), jt(a, "class", "eta-bar svelte-1txqlrd"), _0(a, "transform", i);
    },
    m(l, m) {
      xe(l, a, m);
    },
    p(l, m) {
      m[0] & /*eta_level*/
      131072 && i !== (i = `translateX(${/*eta_level*/
      (l[17] || 0) * 100 - 100}%)`) && _0(a, "transform", i);
    },
    d(l) {
      l && ke(a);
    }
  };
}
function j4(u) {
  let a;
  return {
    c() {
      a = We("processing |");
    },
    m(i, l) {
      xe(i, a, l);
    },
    p: Na,
    d(i) {
      i && ke(a);
    }
  };
}
function Z4(u) {
  let a, i = (
    /*queue_position*/
    u[2] + 1 + ""
  ), l, m, c, p;
  return {
    c() {
      a = We("queue: "), l = We(i), m = We("/"), c = We(
        /*queue_size*/
        u[3]
      ), p = We(" |");
    },
    m(v, y) {
      xe(v, a, y), xe(v, l, y), xe(v, m, y), xe(v, c, y), xe(v, p, y);
    },
    p(v, y) {
      y[0] & /*queue_position*/
      4 && i !== (i = /*queue_position*/
      v[2] + 1 + "") && Mt(l, i), y[0] & /*queue_size*/
      8 && Mt(
        c,
        /*queue_size*/
        v[3]
      );
    },
    d(v) {
      v && (ke(a), ke(l), ke(m), ke(c), ke(p));
    }
  };
}
function K4(u) {
  let a, i = kn(
    /*progress*/
    u[7]
  ), l = [];
  for (let m = 0; m < i.length; m += 1)
    l[m] = jl(Wl(u, i, m));
  return {
    c() {
      for (let m = 0; m < l.length; m += 1)
        l[m].c();
      a = or();
    },
    m(m, c) {
      for (let p = 0; p < l.length; p += 1)
        l[p] && l[p].m(m, c);
      xe(m, a, c);
    },
    p(m, c) {
      if (c[0] & /*progress*/
      128) {
        i = kn(
          /*progress*/
          m[7]
        );
        let p;
        for (p = 0; p < i.length; p += 1) {
          const v = Wl(m, i, p);
          l[p] ? l[p].p(v, c) : (l[p] = jl(v), l[p].c(), l[p].m(a.parentNode, a));
        }
        for (; p < l.length; p += 1)
          l[p].d(1);
        l.length = i.length;
      }
    },
    d(m) {
      m && ke(a), $s(l, m);
    }
  };
}
function Xl(u) {
  let a, i = (
    /*p*/
    u[38].unit + ""
  ), l, m, c = " ", p;
  function v(C, P) {
    return (
      /*p*/
      C[38].length != null ? J4 : Q4
    );
  }
  let y = v(u), D = y(u);
  return {
    c() {
      D.c(), a = Zt(), l = We(i), m = We(" | "), p = We(c);
    },
    m(C, P) {
      D.m(C, P), xe(C, a, P), xe(C, l, P), xe(C, m, P), xe(C, p, P);
    },
    p(C, P) {
      y === (y = v(C)) && D ? D.p(C, P) : (D.d(1), D = y(C), D && (D.c(), D.m(a.parentNode, a))), P[0] & /*progress*/
      128 && i !== (i = /*p*/
      C[38].unit + "") && Mt(l, i);
    },
    d(C) {
      C && (ke(a), ke(l), ke(m), ke(p)), D.d(C);
    }
  };
}
function Q4(u) {
  let a = ar(
    /*p*/
    u[38].index || 0
  ) + "", i;
  return {
    c() {
      i = We(a);
    },
    m(l, m) {
      xe(l, i, m);
    },
    p(l, m) {
      m[0] & /*progress*/
      128 && a !== (a = ar(
        /*p*/
        l[38].index || 0
      ) + "") && Mt(i, a);
    },
    d(l) {
      l && ke(i);
    }
  };
}
function J4(u) {
  let a = ar(
    /*p*/
    u[38].index || 0
  ) + "", i, l, m = ar(
    /*p*/
    u[38].length
  ) + "", c;
  return {
    c() {
      i = We(a), l = We("/"), c = We(m);
    },
    m(p, v) {
      xe(p, i, v), xe(p, l, v), xe(p, c, v);
    },
    p(p, v) {
      v[0] & /*progress*/
      128 && a !== (a = ar(
        /*p*/
        p[38].index || 0
      ) + "") && Mt(i, a), v[0] & /*progress*/
      128 && m !== (m = ar(
        /*p*/
        p[38].length
      ) + "") && Mt(c, m);
    },
    d(p) {
      p && (ke(i), ke(l), ke(c));
    }
  };
}
function jl(u) {
  let a, i = (
    /*p*/
    u[38].index != null && Xl(u)
  );
  return {
    c() {
      i && i.c(), a = or();
    },
    m(l, m) {
      i && i.m(l, m), xe(l, a, m);
    },
    p(l, m) {
      /*p*/
      l[38].index != null ? i ? i.p(l, m) : (i = Xl(l), i.c(), i.m(a.parentNode, a)) : i && (i.d(1), i = null);
    },
    d(l) {
      l && ke(a), i && i.d(l);
    }
  };
}
function Zl(u) {
  let a, i = (
    /*eta*/
    u[0] ? `/${/*formatted_eta*/
    u[19]}` : ""
  ), l, m;
  return {
    c() {
      a = We(
        /*formatted_timer*/
        u[20]
      ), l = We(i), m = We("s");
    },
    m(c, p) {
      xe(c, a, p), xe(c, l, p), xe(c, m, p);
    },
    p(c, p) {
      p[0] & /*formatted_timer*/
      1048576 && Mt(
        a,
        /*formatted_timer*/
        c[20]
      ), p[0] & /*eta, formatted_eta*/
      524289 && i !== (i = /*eta*/
      c[0] ? `/${/*formatted_eta*/
      c[19]}` : "") && Mt(l, i);
    },
    d(c) {
      c && (ke(a), ke(l), ke(m));
    }
  };
}
function $4(u) {
  let a, i;
  return a = new M4({
    props: { margin: (
      /*variant*/
      u[8] === "default"
    ) }
  }), {
    c() {
      N4(a.$$.fragment);
    },
    m(l, m) {
      P4(a, l, m), i = !0;
    },
    p(l, m) {
      const c = {};
      m[0] & /*variant*/
      256 && (c.margin = /*variant*/
      l[8] === "default"), a.$set(c);
    },
    i(l) {
      i || (lr(a.$$.fragment, l), i = !0);
    },
    o(l) {
      sr(a.$$.fragment, l), i = !1;
    },
    d(l) {
      I4(a, l);
    }
  };
}
function ec(u) {
  let a, i, l, m, c, p = `${/*last_progress_level*/
  u[15] * 100}%`, v = (
    /*progress*/
    u[7] != null && Kl(u)
  );
  return {
    c() {
      a = n0("div"), i = n0("div"), v && v.c(), l = Zt(), m = n0("div"), c = n0("div"), jt(i, "class", "progress-level-inner svelte-1txqlrd"), jt(c, "class", "progress-bar svelte-1txqlrd"), _0(c, "width", p), jt(m, "class", "progress-bar-wrap svelte-1txqlrd"), jt(a, "class", "progress-level svelte-1txqlrd");
    },
    m(y, D) {
      xe(y, a, D), P0(a, i), v && v.m(i, null), P0(a, l), P0(a, m), P0(m, c), u[30](c);
    },
    p(y, D) {
      /*progress*/
      y[7] != null ? v ? v.p(y, D) : (v = Kl(y), v.c(), v.m(i, null)) : v && (v.d(1), v = null), D[0] & /*last_progress_level*/
      32768 && p !== (p = `${/*last_progress_level*/
      y[15] * 100}%`) && _0(c, "width", p);
    },
    i: Na,
    o: Na,
    d(y) {
      y && ke(a), v && v.d(), u[30](null);
    }
  };
}
function Kl(u) {
  let a, i = kn(
    /*progress*/
    u[7]
  ), l = [];
  for (let m = 0; m < i.length; m += 1)
    l[m] = ts(Vl(u, i, m));
  return {
    c() {
      for (let m = 0; m < l.length; m += 1)
        l[m].c();
      a = or();
    },
    m(m, c) {
      for (let p = 0; p < l.length; p += 1)
        l[p] && l[p].m(m, c);
      xe(m, a, c);
    },
    p(m, c) {
      if (c[0] & /*progress_level, progress*/
      16512) {
        i = kn(
          /*progress*/
          m[7]
        );
        let p;
        for (p = 0; p < i.length; p += 1) {
          const v = Vl(m, i, p);
          l[p] ? l[p].p(v, c) : (l[p] = ts(v), l[p].c(), l[p].m(a.parentNode, a));
        }
        for (; p < l.length; p += 1)
          l[p].d(1);
        l.length = i.length;
      }
    },
    d(m) {
      m && ke(a), $s(l, m);
    }
  };
}
function Ql(u) {
  let a, i, l, m, c = (
    /*i*/
    u[40] !== 0 && tc()
  ), p = (
    /*p*/
    u[38].desc != null && Jl(u)
  ), v = (
    /*p*/
    u[38].desc != null && /*progress_level*/
    u[14] && /*progress_level*/
    u[14][
      /*i*/
      u[40]
    ] != null && $l()
  ), y = (
    /*progress_level*/
    u[14] != null && es(u)
  );
  return {
    c() {
      c && c.c(), a = Zt(), p && p.c(), i = Zt(), v && v.c(), l = Zt(), y && y.c(), m = or();
    },
    m(D, C) {
      c && c.m(D, C), xe(D, a, C), p && p.m(D, C), xe(D, i, C), v && v.m(D, C), xe(D, l, C), y && y.m(D, C), xe(D, m, C);
    },
    p(D, C) {
      /*p*/
      D[38].desc != null ? p ? p.p(D, C) : (p = Jl(D), p.c(), p.m(i.parentNode, i)) : p && (p.d(1), p = null), /*p*/
      D[38].desc != null && /*progress_level*/
      D[14] && /*progress_level*/
      D[14][
        /*i*/
        D[40]
      ] != null ? v || (v = $l(), v.c(), v.m(l.parentNode, l)) : v && (v.d(1), v = null), /*progress_level*/
      D[14] != null ? y ? y.p(D, C) : (y = es(D), y.c(), y.m(m.parentNode, m)) : y && (y.d(1), y = null);
    },
    d(D) {
      D && (ke(a), ke(i), ke(l), ke(m)), c && c.d(D), p && p.d(D), v && v.d(D), y && y.d(D);
    }
  };
}
function tc(u) {
  let a;
  return {
    c() {
      a = We(" /");
    },
    m(i, l) {
      xe(i, a, l);
    },
    d(i) {
      i && ke(a);
    }
  };
}
function Jl(u) {
  let a = (
    /*p*/
    u[38].desc + ""
  ), i;
  return {
    c() {
      i = We(a);
    },
    m(l, m) {
      xe(l, i, m);
    },
    p(l, m) {
      m[0] & /*progress*/
      128 && a !== (a = /*p*/
      l[38].desc + "") && Mt(i, a);
    },
    d(l) {
      l && ke(i);
    }
  };
}
function $l(u) {
  let a;
  return {
    c() {
      a = We("-");
    },
    m(i, l) {
      xe(i, a, l);
    },
    d(i) {
      i && ke(a);
    }
  };
}
function es(u) {
  let a = (100 * /*progress_level*/
  (u[14][
    /*i*/
    u[40]
  ] || 0)).toFixed(1) + "", i, l;
  return {
    c() {
      i = We(a), l = We("%");
    },
    m(m, c) {
      xe(m, i, c), xe(m, l, c);
    },
    p(m, c) {
      c[0] & /*progress_level*/
      16384 && a !== (a = (100 * /*progress_level*/
      (m[14][
        /*i*/
        m[40]
      ] || 0)).toFixed(1) + "") && Mt(i, a);
    },
    d(m) {
      m && (ke(i), ke(l));
    }
  };
}
function ts(u) {
  let a, i = (
    /*p*/
    (u[38].desc != null || /*progress_level*/
    u[14] && /*progress_level*/
    u[14][
      /*i*/
      u[40]
    ] != null) && Ql(u)
  );
  return {
    c() {
      i && i.c(), a = or();
    },
    m(l, m) {
      i && i.m(l, m), xe(l, a, m);
    },
    p(l, m) {
      /*p*/
      l[38].desc != null || /*progress_level*/
      l[14] && /*progress_level*/
      l[14][
        /*i*/
        l[40]
      ] != null ? i ? i.p(l, m) : (i = Ql(l), i.c(), i.m(a.parentNode, a)) : i && (i.d(1), i = null);
    },
    d(l) {
      l && ke(a), i && i.d(l);
    }
  };
}
function rs(u) {
  let a, i;
  return {
    c() {
      a = n0("p"), i = We(
        /*loading_text*/
        u[9]
      ), jt(a, "class", "loading svelte-1txqlrd");
    },
    m(l, m) {
      xe(l, a, m), P0(a, i);
    },
    p(l, m) {
      m[0] & /*loading_text*/
      512 && Mt(
        i,
        /*loading_text*/
        l[9]
      );
    },
    d(l) {
      l && ke(a);
    }
  };
}
function rc(u) {
  let a, i, l, m, c;
  const p = [X4, Y4], v = [];
  function y(D, C) {
    return (
      /*status*/
      D[4] === "pending" ? 0 : (
        /*status*/
        D[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(i = y(u)) && (l = v[i] = p[i](u)), {
    c() {
      a = n0("div"), l && l.c(), jt(a, "class", m = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-1txqlrd"), Ct(a, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden"), Ct(
        a,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), Ct(
        a,
        "generating",
        /*status*/
        u[4] === "generating"
      ), Ct(
        a,
        "border",
        /*border*/
        u[12]
      ), _0(
        a,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), _0(
        a,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(D, C) {
      xe(D, a, C), ~i && v[i].m(a, null), u[31](a), c = !0;
    },
    p(D, C) {
      let P = i;
      i = y(D), i === P ? ~i && v[i].p(D, C) : (l && (eo(), sr(v[P], 1, 1, () => {
        v[P] = null;
      }), Js()), ~i ? (l = v[i], l ? l.p(D, C) : (l = v[i] = p[i](D), l.c()), lr(l, 1), l.m(a, null)) : l = null), (!c || C[0] & /*variant, show_progress*/
      320 && m !== (m = "wrap " + /*variant*/
      D[8] + " " + /*show_progress*/
      D[6] + " svelte-1txqlrd")) && jt(a, "class", m), (!c || C[0] & /*variant, show_progress, status, show_progress*/
      336) && Ct(a, "hide", !/*status*/
      D[4] || /*status*/
      D[4] === "complete" || /*show_progress*/
      D[6] === "hidden"), (!c || C[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Ct(
        a,
        "translucent",
        /*variant*/
        D[8] === "center" && /*status*/
        (D[4] === "pending" || /*status*/
        D[4] === "error") || /*translucent*/
        D[11] || /*show_progress*/
        D[6] === "minimal"
      ), (!c || C[0] & /*variant, show_progress, status*/
      336) && Ct(
        a,
        "generating",
        /*status*/
        D[4] === "generating"
      ), (!c || C[0] & /*variant, show_progress, border*/
      4416) && Ct(
        a,
        "border",
        /*border*/
        D[12]
      ), C[0] & /*absolute*/
      1024 && _0(
        a,
        "position",
        /*absolute*/
        D[10] ? "absolute" : "static"
      ), C[0] & /*absolute*/
      1024 && _0(
        a,
        "padding",
        /*absolute*/
        D[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(D) {
      c || (lr(l), c = !0);
    },
    o(D) {
      sr(l), c = !1;
    },
    d(D) {
      D && ke(a), ~i && v[i].d(), u[31](null);
    }
  };
}
let fn = [], Da = !1;
async function nc(u, a = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && a !== !0)) {
    if (fn.push(u), !Da)
      Da = !0;
    else
      return;
    await G4(), requestAnimationFrame(() => {
      let i = [0, 0];
      for (let l = 0; l < fn.length; l++) {
        const c = fn[l].getBoundingClientRect();
        (l === 0 || c.top + window.scrollY <= i[0]) && (i[0] = c.top + window.scrollY, i[1] = l);
      }
      window.scrollTo({ top: i[0] - 20, behavior: "smooth" }), Da = !1, fn = [];
    });
  }
}
function ac(u, a, i) {
  let l, { $$slots: m = {}, $$scope: c } = a, { i18n: p } = a, { eta: v = null } = a, { queue_position: y } = a, { queue_size: D } = a, { status: C } = a, { scroll_to_output: P = !1 } = a, { timer: H = !0 } = a, { show_progress: W = "full" } = a, { message: se = null } = a, { progress: oe = null } = a, { variant: ae = "default" } = a, { loading_text: L = "Loading..." } = a, { absolute: B = !0 } = a, { translucent: S = !1 } = a, { border: R = !1 } = a, { autoscroll: I } = a, M, X = !1, $ = 0, j = 0, he = null, ie = null, de = 0, be = null, Te, Xe = null, ue = !0;
  const Ke = () => {
    i(0, v = i(26, he = i(19, Z = null))), i(24, $ = performance.now()), i(25, j = 0), X = !0, _e();
  };
  function _e() {
    requestAnimationFrame(() => {
      i(25, j = (performance.now() - $) / 1e3), X && _e();
    });
  }
  function Ae() {
    i(25, j = 0), i(0, v = i(26, he = i(19, Z = null))), X && (X = !1);
  }
  V4(() => {
    X && Ae();
  });
  let Z = null;
  function K(re) {
    Ul[re ? "unshift" : "push"](() => {
      Xe = re, i(16, Xe), i(7, oe), i(14, be), i(15, Te);
    });
  }
  function Qe(re) {
    Ul[re ? "unshift" : "push"](() => {
      M = re, i(13, M);
    });
  }
  return u.$$set = (re) => {
    "i18n" in re && i(1, p = re.i18n), "eta" in re && i(0, v = re.eta), "queue_position" in re && i(2, y = re.queue_position), "queue_size" in re && i(3, D = re.queue_size), "status" in re && i(4, C = re.status), "scroll_to_output" in re && i(21, P = re.scroll_to_output), "timer" in re && i(5, H = re.timer), "show_progress" in re && i(6, W = re.show_progress), "message" in re && i(22, se = re.message), "progress" in re && i(7, oe = re.progress), "variant" in re && i(8, ae = re.variant), "loading_text" in re && i(9, L = re.loading_text), "absolute" in re && i(10, B = re.absolute), "translucent" in re && i(11, S = re.translucent), "border" in re && i(12, R = re.border), "autoscroll" in re && i(23, I = re.autoscroll), "$$scope" in re && i(28, c = re.$$scope);
  }, u.$$.update = () => {
    u.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    218103809 && (v === null && i(0, v = he), v != null && he !== v && (i(27, ie = (performance.now() - $) / 1e3 + v), i(19, Z = ie.toFixed(1)), i(26, he = v))), u.$$.dirty[0] & /*eta_from_start, timer_diff*/
    167772160 && i(17, de = ie === null || ie <= 0 || !j ? null : Math.min(j / ie, 1)), u.$$.dirty[0] & /*progress*/
    128 && oe != null && i(18, ue = !1), u.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (oe != null ? i(14, be = oe.map((re) => {
      if (re.index != null && re.length != null)
        return re.index / re.length;
      if (re.progress != null)
        return re.progress;
    })) : i(14, be = null), be ? (i(15, Te = be[be.length - 1]), Xe && (Te === 0 ? i(16, Xe.style.transition = "0", Xe) : i(16, Xe.style.transition = "150ms", Xe))) : i(15, Te = void 0)), u.$$.dirty[0] & /*status*/
    16 && (C === "pending" ? Ke() : Ae()), u.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    10493968 && M && P && (C === "pending" || C === "complete") && nc(M, I), u.$$.dirty[0] & /*status, message*/
    4194320, u.$$.dirty[0] & /*timer_diff*/
    33554432 && i(20, l = j.toFixed(1));
  }, [
    v,
    p,
    y,
    D,
    C,
    H,
    W,
    oe,
    ae,
    L,
    B,
    S,
    R,
    M,
    be,
    Te,
    Xe,
    de,
    ue,
    Z,
    l,
    P,
    se,
    I,
    $,
    j,
    he,
    ie,
    c,
    m,
    K,
    Qe
  ];
}
class ic extends z4 {
  constructor(a) {
    super(), q4(
      this,
      a,
      ac,
      rc,
      H4,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 21,
        timer: 5,
        show_progress: 6,
        message: 22,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 23
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: lc,
  append: ns,
  attr: gt,
  detach: sc,
  init: oc,
  insert: uc,
  noop: Aa,
  safe_not_equal: cc,
  svg_element: _a
} = window.__gradio__svelte__internal;
function hc(u) {
  let a, i, l;
  return {
    c() {
      a = _a("svg"), i = _a("path"), l = _a("path"), gt(i, "fill", "currentColor"), gt(i, "d", "M17.74 30L16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84Z"), gt(l, "fill", "currentColor"), gt(l, "d", "M8 10h16v2H8zm0 6h10v2H8z"), gt(a, "xmlns", "http://www.w3.org/2000/svg"), gt(a, "xmlns:xlink", "http://www.w3.org/1999/xlink"), gt(a, "aria-hidden", "true"), gt(a, "role", "img"), gt(a, "class", "iconify iconify--carbon"), gt(a, "width", "100%"), gt(a, "height", "100%"), gt(a, "preserveAspectRatio", "xMidYMid meet"), gt(a, "viewBox", "0 0 32 32");
    },
    m(m, c) {
      uc(m, a, c), ns(a, i), ns(a, l);
    },
    p: Aa,
    i: Aa,
    o: Aa,
    d(m) {
      m && sc(a);
    }
  };
}
class fc extends lc {
  constructor(a) {
    super(), oc(this, a, null, hc, cc, {});
  }
}
const {
  SvelteComponent: mc,
  assign: dc,
  create_slot: pc,
  detach: gc,
  element: vc,
  get_all_dirty_from_scope: bc,
  get_slot_changes: yc,
  get_spread_update: wc,
  init: kc,
  insert: xc,
  safe_not_equal: Dc,
  set_dynamic_element_data: as,
  set_style: vt,
  toggle_class: k0,
  transition_in: to,
  transition_out: ro,
  update_slot_base: Ac
} = window.__gradio__svelte__internal;
function _c(u) {
  let a, i, l;
  const m = (
    /*#slots*/
    u[18].default
  ), c = pc(
    m,
    u,
    /*$$scope*/
    u[17],
    null
  );
  let p = [
    { "data-testid": (
      /*test_id*/
      u[7]
    ) },
    { id: (
      /*elem_id*/
      u[2]
    ) },
    {
      class: i = "block " + /*elem_classes*/
      u[3].join(" ") + " svelte-1t38q2d"
    }
  ], v = {};
  for (let y = 0; y < p.length; y += 1)
    v = dc(v, p[y]);
  return {
    c() {
      a = vc(
        /*tag*/
        u[14]
      ), c && c.c(), as(
        /*tag*/
        u[14]
      )(a, v), k0(
        a,
        "hidden",
        /*visible*/
        u[10] === !1
      ), k0(
        a,
        "padded",
        /*padding*/
        u[6]
      ), k0(
        a,
        "border_focus",
        /*border_mode*/
        u[5] === "focus"
      ), k0(a, "hide-container", !/*explicit_call*/
      u[8] && !/*container*/
      u[9]), vt(
        a,
        "height",
        /*get_dimension*/
        u[15](
          /*height*/
          u[0]
        )
      ), vt(a, "width", typeof /*width*/
      u[1] == "number" ? `calc(min(${/*width*/
      u[1]}px, 100%))` : (
        /*get_dimension*/
        u[15](
          /*width*/
          u[1]
        )
      )), vt(
        a,
        "border-style",
        /*variant*/
        u[4]
      ), vt(
        a,
        "overflow",
        /*allow_overflow*/
        u[11] ? "visible" : "hidden"
      ), vt(
        a,
        "flex-grow",
        /*scale*/
        u[12]
      ), vt(a, "min-width", `calc(min(${/*min_width*/
      u[13]}px, 100%))`), vt(a, "border-width", "var(--block-border-width)");
    },
    m(y, D) {
      xc(y, a, D), c && c.m(a, null), l = !0;
    },
    p(y, D) {
      c && c.p && (!l || D & /*$$scope*/
      131072) && Ac(
        c,
        m,
        y,
        /*$$scope*/
        y[17],
        l ? yc(
          m,
          /*$$scope*/
          y[17],
          D,
          null
        ) : bc(
          /*$$scope*/
          y[17]
        ),
        null
      ), as(
        /*tag*/
        y[14]
      )(a, v = wc(p, [
        (!l || D & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          y[7]
        ) },
        (!l || D & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          y[2]
        ) },
        (!l || D & /*elem_classes*/
        8 && i !== (i = "block " + /*elem_classes*/
        y[3].join(" ") + " svelte-1t38q2d")) && { class: i }
      ])), k0(
        a,
        "hidden",
        /*visible*/
        y[10] === !1
      ), k0(
        a,
        "padded",
        /*padding*/
        y[6]
      ), k0(
        a,
        "border_focus",
        /*border_mode*/
        y[5] === "focus"
      ), k0(a, "hide-container", !/*explicit_call*/
      y[8] && !/*container*/
      y[9]), D & /*height*/
      1 && vt(
        a,
        "height",
        /*get_dimension*/
        y[15](
          /*height*/
          y[0]
        )
      ), D & /*width*/
      2 && vt(a, "width", typeof /*width*/
      y[1] == "number" ? `calc(min(${/*width*/
      y[1]}px, 100%))` : (
        /*get_dimension*/
        y[15](
          /*width*/
          y[1]
        )
      )), D & /*variant*/
      16 && vt(
        a,
        "border-style",
        /*variant*/
        y[4]
      ), D & /*allow_overflow*/
      2048 && vt(
        a,
        "overflow",
        /*allow_overflow*/
        y[11] ? "visible" : "hidden"
      ), D & /*scale*/
      4096 && vt(
        a,
        "flex-grow",
        /*scale*/
        y[12]
      ), D & /*min_width*/
      8192 && vt(a, "min-width", `calc(min(${/*min_width*/
      y[13]}px, 100%))`);
    },
    i(y) {
      l || (to(c, y), l = !0);
    },
    o(y) {
      ro(c, y), l = !1;
    },
    d(y) {
      y && gc(a), c && c.d(y);
    }
  };
}
function Sc(u) {
  let a, i = (
    /*tag*/
    u[14] && _c(u)
  );
  return {
    c() {
      i && i.c();
    },
    m(l, m) {
      i && i.m(l, m), a = !0;
    },
    p(l, [m]) {
      /*tag*/
      l[14] && i.p(l, m);
    },
    i(l) {
      a || (to(i, l), a = !0);
    },
    o(l) {
      ro(i, l), a = !1;
    },
    d(l) {
      i && i.d(l);
    }
  };
}
function Fc(u, a, i) {
  let { $$slots: l = {}, $$scope: m } = a, { height: c = void 0 } = a, { width: p = void 0 } = a, { elem_id: v = "" } = a, { elem_classes: y = [] } = a, { variant: D = "solid" } = a, { border_mode: C = "base" } = a, { padding: P = !0 } = a, { type: H = "normal" } = a, { test_id: W = void 0 } = a, { explicit_call: se = !1 } = a, { container: oe = !0 } = a, { visible: ae = !0 } = a, { allow_overflow: L = !0 } = a, { scale: B = null } = a, { min_width: S = 0 } = a, R = H === "fieldset" ? "fieldset" : "div";
  const I = (M) => {
    if (M !== void 0) {
      if (typeof M == "number")
        return M + "px";
      if (typeof M == "string")
        return M;
    }
  };
  return u.$$set = (M) => {
    "height" in M && i(0, c = M.height), "width" in M && i(1, p = M.width), "elem_id" in M && i(2, v = M.elem_id), "elem_classes" in M && i(3, y = M.elem_classes), "variant" in M && i(4, D = M.variant), "border_mode" in M && i(5, C = M.border_mode), "padding" in M && i(6, P = M.padding), "type" in M && i(16, H = M.type), "test_id" in M && i(7, W = M.test_id), "explicit_call" in M && i(8, se = M.explicit_call), "container" in M && i(9, oe = M.container), "visible" in M && i(10, ae = M.visible), "allow_overflow" in M && i(11, L = M.allow_overflow), "scale" in M && i(12, B = M.scale), "min_width" in M && i(13, S = M.min_width), "$$scope" in M && i(17, m = M.$$scope);
  }, [
    c,
    p,
    v,
    y,
    D,
    C,
    P,
    W,
    se,
    oe,
    ae,
    L,
    B,
    S,
    R,
    I,
    H,
    m,
    l
  ];
}
class Ec extends mc {
  constructor(a) {
    super(), kc(this, a, Fc, Sc, Dc, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: Cc,
  append: Sa,
  attr: mn,
  create_component: Tc,
  destroy_component: Bc,
  detach: Mc,
  element: is,
  init: zc,
  insert: Nc,
  mount_component: Rc,
  safe_not_equal: Ic,
  set_data: Lc,
  space: Oc,
  text: qc,
  toggle_class: x0,
  transition_in: Pc,
  transition_out: Hc
} = window.__gradio__svelte__internal;
function Uc(u) {
  let a, i, l, m, c, p;
  return l = new /*Icon*/
  u[1]({}), {
    c() {
      a = is("label"), i = is("span"), Tc(l.$$.fragment), m = Oc(), c = qc(
        /*label*/
        u[0]
      ), mn(i, "class", "svelte-9gxdi0"), mn(a, "for", ""), mn(a, "data-testid", "block-label"), mn(a, "class", "svelte-9gxdi0"), x0(a, "hide", !/*show_label*/
      u[2]), x0(a, "sr-only", !/*show_label*/
      u[2]), x0(
        a,
        "float",
        /*float*/
        u[4]
      ), x0(
        a,
        "hide-label",
        /*disable*/
        u[3]
      );
    },
    m(v, y) {
      Nc(v, a, y), Sa(a, i), Rc(l, i, null), Sa(a, m), Sa(a, c), p = !0;
    },
    p(v, [y]) {
      (!p || y & /*label*/
      1) && Lc(
        c,
        /*label*/
        v[0]
      ), (!p || y & /*show_label*/
      4) && x0(a, "hide", !/*show_label*/
      v[2]), (!p || y & /*show_label*/
      4) && x0(a, "sr-only", !/*show_label*/
      v[2]), (!p || y & /*float*/
      16) && x0(
        a,
        "float",
        /*float*/
        v[4]
      ), (!p || y & /*disable*/
      8) && x0(
        a,
        "hide-label",
        /*disable*/
        v[3]
      );
    },
    i(v) {
      p || (Pc(l.$$.fragment, v), p = !0);
    },
    o(v) {
      Hc(l.$$.fragment, v), p = !1;
    },
    d(v) {
      v && Mc(a), Bc(l);
    }
  };
}
function Gc(u, a, i) {
  let { label: l = null } = a, { Icon: m } = a, { show_label: c = !0 } = a, { disable: p = !1 } = a, { float: v = !0 } = a;
  return u.$$set = (y) => {
    "label" in y && i(0, l = y.label), "Icon" in y && i(1, m = y.Icon), "show_label" in y && i(2, c = y.show_label), "disable" in y && i(3, p = y.disable), "float" in y && i(4, v = y.float);
  }, [l, m, c, p, v];
}
class Vc extends Cc {
  constructor(a) {
    super(), zc(this, a, Gc, Uc, Ic, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
new Intl.Collator(0, { numeric: 1 }).compare;
function no(u, a, i) {
  if (u == null)
    return null;
  if (Array.isArray(u)) {
    const l = [];
    for (const m of u)
      m == null ? l.push(null) : l.push(no(m, a, i));
    return l;
  }
  return u.is_stream ? i == null ? new Fa({
    ...u,
    url: a + "/stream/" + u.path
  }) : new Fa({
    ...u,
    url: "/proxy=" + i + "stream/" + u.path
  }) : new Fa({
    ...u,
    url: Yc(u.path, a, i)
  });
}
function Wc(u) {
  try {
    const a = new URL(u);
    return a.protocol === "http:" || a.protocol === "https:";
  } catch {
    return !1;
  }
}
function Yc(u, a, i) {
  return u == null ? i ? `/proxy=${i}file=` : `${a}/file=` : Wc(u) ? u : i ? `/proxy=${i}file=${u}` : `${a}/file=${u}`;
}
class Fa {
  constructor({
    path: a,
    url: i,
    orig_name: l,
    size: m,
    blob: c,
    is_stream: p,
    mime_type: v,
    alt_text: y
  }) {
    this.path = a, this.url = i, this.orig_name = l, this.size = m, this.blob = i ? void 0 : c, this.is_stream = p, this.mime_type = v, this.alt_text = y;
  }
}
const {
  SvelteComponent: Xc,
  attr: dn,
  detach: jc,
  element: Zc,
  init: Kc,
  insert: Qc,
  noop: ls,
  safe_not_equal: Jc,
  set_style: ss
} = window.__gradio__svelte__internal;
function $c(u) {
  let a;
  return {
    c() {
      a = Zc("div"), a.innerHTML = `<span class="sr-only">Loading content</span> <div class="dot-flashing svelte-1pwlswb"></div>
	 
	<div class="dot-flashing svelte-1pwlswb"></div>
	 
	<div class="dot-flashing svelte-1pwlswb"></div>`, dn(a, "class", "message pending svelte-1pwlswb"), dn(a, "role", "status"), dn(a, "aria-label", "Loading response"), dn(a, "aria-live", "polite"), ss(
        a,
        "border-radius",
        /*layout*/
        u[0] === "bubble" ? "var(--radius-xxl)" : "none"
      );
    },
    m(i, l) {
      Qc(i, a, l);
    },
    p(i, [l]) {
      l & /*layout*/
      1 && ss(
        a,
        "border-radius",
        /*layout*/
        i[0] === "bubble" ? "var(--radius-xxl)" : "none"
      );
    },
    i: ls,
    o: ls,
    d(i) {
      i && jc(a);
    }
  };
}
function eh(u, a, i) {
  let { layout: l = "bubble" } = a;
  return u.$$set = (m) => {
    "layout" in m && i(0, l = m.layout);
  }, [l];
}
class th extends Xc {
  constructor(a) {
    super(), Kc(this, a, eh, $c, Jc, { layout: 0 });
  }
}
const {
  SvelteComponent: rh,
  action_destroyer: nh,
  append: D0,
  attr: ge,
  binding_callbacks: ah,
  bubble: nr,
  check_outros: xn,
  create_component: ao,
  destroy_component: io,
  destroy_each: ih,
  detach: F0,
  element: Tt,
  empty: lh,
  ensure_array_like: os,
  group_outros: Dn,
  init: sh,
  insert: E0,
  listen: S0,
  mount_component: lo,
  noop: C0,
  null_to_empty: us,
  run_all: Va,
  safe_not_equal: oh,
  set_data: uh,
  set_style: _r,
  space: so,
  src_url_equal: T0,
  text: ch,
  toggle_class: at,
  transition_in: yt,
  transition_out: Kt
} = window.__gradio__svelte__internal, { beforeUpdate: hh, afterUpdate: fh, createEventDispatcher: mh } = window.__gradio__svelte__internal;
function cs(u, a, i) {
  const l = u.slice();
  return l[30] = a[i][0], l[31] = a[i][1], l[33] = i, l;
}
function hs(u) {
  let a, i, l, m = os(
    /*value*/
    u[0]
  ), c = [];
  for (let y = 0; y < m.length; y += 1)
    c[y] = fs(cs(u, m, y));
  const p = (y) => Kt(c[y], 1, 1, () => {
    c[y] = null;
  });
  let v = (
    /*pending_message*/
    u[2] && ms(u)
  );
  return {
    c() {
      for (let y = 0; y < c.length; y += 1)
        c[y].c();
      a = so(), v && v.c(), i = lh();
    },
    m(y, D) {
      for (let C = 0; C < c.length; C += 1)
        c[C] && c[C].m(y, D);
      E0(y, a, D), v && v.m(y, D), E0(y, i, D), l = !0;
    },
    p(y, D) {
      if (D[0] & /*layout, value, bubble_full_width, render_markdown, rtl, selectable, handle_select, latex_delimiters, sanitize_html, line_breaks, scroll*/
      7163) {
        m = os(
          /*value*/
          y[0]
        );
        let C;
        for (C = 0; C < m.length; C += 1) {
          const P = cs(y, m, C);
          c[C] ? (c[C].p(P, D), yt(c[C], 1)) : (c[C] = fs(P), c[C].c(), yt(c[C], 1), c[C].m(a.parentNode, a));
        }
        for (Dn(), C = m.length; C < c.length; C += 1)
          p(C);
        xn();
      }
      /*pending_message*/
      y[2] ? v ? (v.p(y, D), D[0] & /*pending_message*/
      4 && yt(v, 1)) : (v = ms(y), v.c(), yt(v, 1), v.m(i.parentNode, i)) : v && (Dn(), Kt(v, 1, 1, () => {
        v = null;
      }), xn());
    },
    i(y) {
      if (!l) {
        for (let D = 0; D < m.length; D += 1)
          yt(c[D]);
        yt(v), l = !0;
      }
    },
    o(y) {
      c = c.filter(Boolean);
      for (let D = 0; D < c.length; D += 1)
        Kt(c[D]);
      Kt(v), l = !1;
    },
    d(y) {
      y && (F0(a), F0(i)), ih(c, y), v && v.d(y);
    }
  };
}
function dh(u) {
  var p, v;
  let a, i = (
    /*message*/
    (((p = u[31].file) == null ? void 0 : p.orig_name) || /*message*/
    ((v = u[31].file) == null ? void 0 : v.path)) + ""
  ), l, m, c;
  return {
    c() {
      var y, D, C;
      a = Tt("a"), l = ch(i), ge(a, "data-testid", "chatbot-file"), ge(a, "href", m = /*message*/
      (y = u[31].file) == null ? void 0 : y.url), ge(a, "target", "_blank"), ge(a, "download", c = window.__is_colab__ ? null : (
        /*message*/
        ((D = u[31].file) == null ? void 0 : D.orig_name) || /*message*/
        ((C = u[31].file) == null ? void 0 : C.path)
      )), ge(a, "class", "svelte-1eod0mv");
    },
    m(y, D) {
      E0(y, a, D), D0(a, l);
    },
    p(y, D) {
      var C, P, H, W, se;
      D[0] & /*value*/
      1 && i !== (i = /*message*/
      (((C = y[31].file) == null ? void 0 : C.orig_name) || /*message*/
      ((P = y[31].file) == null ? void 0 : P.path)) + "") && uh(l, i), D[0] & /*value*/
      1 && m !== (m = /*message*/
      (H = y[31].file) == null ? void 0 : H.url) && ge(a, "href", m), D[0] & /*value*/
      1 && c !== (c = window.__is_colab__ ? null : (
        /*message*/
        ((W = y[31].file) == null ? void 0 : W.orig_name) || /*message*/
        ((se = y[31].file) == null ? void 0 : se.path)
      )) && ge(a, "download", c);
    },
    i: C0,
    o: C0,
    d(y) {
      y && F0(a);
    }
  };
}
function ph(u) {
  let a, i, l;
  return {
    c() {
      var m;
      a = Tt("img"), ge(a, "data-testid", "chatbot-image"), T0(a.src, i = /*message*/
      (m = u[31].file) == null ? void 0 : m.url) || ge(a, "src", i), ge(a, "alt", l = /*message*/
      u[31].alt_text), ge(a, "class", "svelte-1eod0mv");
    },
    m(m, c) {
      E0(m, a, c);
    },
    p(m, c) {
      var p;
      c[0] & /*value*/
      1 && !T0(a.src, i = /*message*/
      (p = m[31].file) == null ? void 0 : p.url) && ge(a, "src", i), c[0] & /*value*/
      1 && l !== (l = /*message*/
      m[31].alt_text) && ge(a, "alt", l);
    },
    i: C0,
    o: C0,
    d(m) {
      m && F0(a);
    }
  };
}
function gh(u) {
  let a, i, l, m, c, p;
  return {
    c() {
      var v;
      a = Tt("video"), i = Tt("track"), ge(i, "kind", "captions"), ge(i, "class", "svelte-1eod0mv"), ge(a, "data-testid", "chatbot-video"), a.controls = !0, T0(a.src, l = /*message*/
      (v = u[31].file) == null ? void 0 : v.url) || ge(a, "src", l), ge(a, "title", m = /*message*/
      u[31].alt_text), ge(a, "preload", "auto"), ge(a, "class", "svelte-1eod0mv");
    },
    m(v, y) {
      E0(v, a, y), D0(a, i), c || (p = [
        S0(
          a,
          "play",
          /*play_handler_1*/
          u[21]
        ),
        S0(
          a,
          "pause",
          /*pause_handler_1*/
          u[22]
        ),
        S0(
          a,
          "ended",
          /*ended_handler_1*/
          u[23]
        )
      ], c = !0);
    },
    p(v, y) {
      var D;
      y[0] & /*value*/
      1 && !T0(a.src, l = /*message*/
      (D = v[31].file) == null ? void 0 : D.url) && ge(a, "src", l), y[0] & /*value*/
      1 && m !== (m = /*message*/
      v[31].alt_text) && ge(a, "title", m);
    },
    i: C0,
    o: C0,
    d(v) {
      v && F0(a), c = !1, Va(p);
    }
  };
}
function vh(u) {
  let a, i, l, m, c;
  return {
    c() {
      var p;
      a = Tt("audio"), ge(a, "data-testid", "chatbot-audio"), a.controls = !0, ge(a, "preload", "metadata"), T0(a.src, i = /*message*/
      (p = u[31].file) == null ? void 0 : p.url) || ge(a, "src", i), ge(a, "title", l = /*message*/
      u[31].alt_text), ge(a, "class", "svelte-1eod0mv");
    },
    m(p, v) {
      E0(p, a, v), m || (c = [
        S0(
          a,
          "play",
          /*play_handler*/
          u[18]
        ),
        S0(
          a,
          "pause",
          /*pause_handler*/
          u[19]
        ),
        S0(
          a,
          "ended",
          /*ended_handler*/
          u[20]
        )
      ], m = !0);
    },
    p(p, v) {
      var y;
      v[0] & /*value*/
      1 && !T0(a.src, i = /*message*/
      (y = p[31].file) == null ? void 0 : y.url) && ge(a, "src", i), v[0] & /*value*/
      1 && l !== (l = /*message*/
      p[31].alt_text) && ge(a, "title", l);
    },
    i: C0,
    o: C0,
    d(p) {
      p && F0(a), m = !1, Va(c);
    }
  };
}
function bh(u) {
  let a, i;
  return a = new y4({
    props: {
      message: (
        /*message*/
        u[31]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        u[1]
      ),
      sanitize_html: (
        /*sanitize_html*/
        u[5]
      ),
      render_markdown: (
        /*render_markdown*/
        u[7]
      ),
      line_breaks: (
        /*line_breaks*/
        u[8]
      )
    }
  }), a.$on(
    "load",
    /*scroll*/
    u[11]
  ), {
    c() {
      ao(a.$$.fragment);
    },
    m(l, m) {
      lo(a, l, m), i = !0;
    },
    p(l, m) {
      const c = {};
      m[0] & /*value*/
      1 && (c.message = /*message*/
      l[31]), m[0] & /*latex_delimiters*/
      2 && (c.latex_delimiters = /*latex_delimiters*/
      l[1]), m[0] & /*sanitize_html*/
      32 && (c.sanitize_html = /*sanitize_html*/
      l[5]), m[0] & /*render_markdown*/
      128 && (c.render_markdown = /*render_markdown*/
      l[7]), m[0] & /*line_breaks*/
      256 && (c.line_breaks = /*line_breaks*/
      l[8]), a.$set(c);
    },
    i(l) {
      i || (yt(a.$$.fragment, l), i = !0);
    },
    o(l) {
      Kt(a.$$.fragment, l), i = !1;
    },
    d(l) {
      io(a, l);
    }
  };
}
function fs(u) {
  let a, i, l, m, c, p, v, y, D, C, P, H, W, se, oe, ae, L, B, S, R, I;
  const M = [
    bh,
    vh,
    gh,
    ph,
    dh
  ], X = [];
  function $(ie, de) {
    var be, Te, Xe, ue, Ke, _e, Ae;
    return de[0] & /*value*/
    1 && (D = null), de[0] & /*value*/
    1 && (C = null), de[0] & /*value*/
    1 && (P = null), typeof /*message*/
    ie[31] == "string" ? 0 : (D == null && (D = !!/*message*/
    (ie[31] !== null && /*message*/
    ((Te = (be = ie[31].file) == null ? void 0 : be.mime_type) != null && Te.includes("audio")))), D ? 1 : (C == null && (C = !!/*message*/
    (ie[31] !== null && /*message*/
    ((ue = (Xe = ie[31].file) == null ? void 0 : Xe.mime_type) != null && ue.includes("video")))), C ? 2 : (P == null && (P = !!/*message*/
    (ie[31] !== null && /*message*/
    ((_e = (Ke = ie[31].file) == null ? void 0 : Ke.mime_type) != null && _e.includes("image")))), P ? 3 : (
      /*message*/
      ie[31] !== null && /*message*/
      ((Ae = ie[31].file) == null ? void 0 : Ae.url) !== null ? 4 : -1
    ))));
  }
  ~(H = $(u, [-1, -1])) && (W = X[H] = M[H](u));
  function j() {
    return (
      /*click_handler*/
      u[24](
        /*i*/
        u[33],
        /*message*/
        u[31]
      )
    );
  }
  function he(...ie) {
    return (
      /*keydown_handler*/
      u[25](
        /*i*/
        u[33],
        /*message*/
        u[31],
        ...ie
      )
    );
  }
  return {
    c() {
      a = Tt("div"), i = Tt("div"), l = Tt("img"), p = so(), v = Tt("div"), y = Tt("button"), W && W.c(), ge(l, "class", "avatar-image svelte-1eod0mv"), T0(l.src, m = ds(
        /*name*/
        u[30]
      )) || ge(l, "src", m), ge(l, "alt", c = /*name*/
      (u[30] === "User" ? "user" : "bot") + `
                            avatar`), ge(i, "class", "avatar-container svelte-1eod0mv"), ge(y, "data-testid", se = /*name*/
      u[30] === "User" ? "user" : "bot"), ge(y, "dir", oe = /*rtl*/
      u[4] ? "rtl" : "ltr"), ge(y, "aria-label", ae = /*name*/
      (u[30] === "User" ? "user" : "bot") + "'s message:' " + /*message*/
      u[31]), ge(y, "class", "svelte-1eod0mv"), at(
        y,
        "latest",
        /*i*/
        u[33] === /*value*/
        u[0].length - 1
      ), at(y, "message-markdown-disabled", !/*render_markdown*/
      u[7]), at(
        y,
        "selectable",
        /*selectable*/
        u[3]
      ), _r(y, "user-select", "text"), _r(
        y,
        "text-align",
        /*rtl*/
        u[4] ? "right" : "left"
      ), ge(v, "class", L = "message " + /*name*/
      (u[30] === "User" ? "user" : "bot") + " svelte-1eod0mv"), at(
        v,
        "message-fit",
        /*layout*/
        u[9] === "bubble" && !/*bubble_full_width*/
        u[6]
      ), at(
        v,
        "panel-full-width",
        /*layout*/
        u[9] === "panel"
      ), at(
        v,
        "message-bubble-border",
        /*layout*/
        u[9] === "bubble"
      ), at(v, "message-markdown-disabled", !/*render_markdown*/
      u[7]), _r(
        v,
        "text-align",
        /*rtl*/
        u[4] && /*name*/
        u[30] === "User" ? "left" : "right"
      ), ge(a, "class", B = "message-row " + /*layout*/
      u[9] + " " + /*name*/
      (u[30] === "User" ? "user-row" : "bot-row") + " svelte-1eod0mv");
    },
    m(ie, de) {
      E0(ie, a, de), D0(a, i), D0(i, l), D0(a, p), D0(a, v), D0(v, y), ~H && X[H].m(y, null), S = !0, R || (I = [
        S0(y, "click", j),
        S0(y, "keydown", he)
      ], R = !0);
    },
    p(ie, de) {
      u = ie, (!S || de[0] & /*value*/
      1 && !T0(l.src, m = ds(
        /*name*/
        u[30]
      ))) && ge(l, "src", m), (!S || de[0] & /*value*/
      1 && c !== (c = /*name*/
      (u[30] === "User" ? "user" : "bot") + `
                            avatar`)) && ge(l, "alt", c);
      let be = H;
      H = $(u, de), H === be ? ~H && X[H].p(u, de) : (W && (Dn(), Kt(X[be], 1, 1, () => {
        X[be] = null;
      }), xn()), ~H ? (W = X[H], W ? W.p(u, de) : (W = X[H] = M[H](u), W.c()), yt(W, 1), W.m(y, null)) : W = null), (!S || de[0] & /*value*/
      1 && se !== (se = /*name*/
      u[30] === "User" ? "user" : "bot")) && ge(y, "data-testid", se), (!S || de[0] & /*rtl*/
      16 && oe !== (oe = /*rtl*/
      u[4] ? "rtl" : "ltr")) && ge(y, "dir", oe), (!S || de[0] & /*value*/
      1 && ae !== (ae = /*name*/
      (u[30] === "User" ? "user" : "bot") + "'s message:' " + /*message*/
      u[31])) && ge(y, "aria-label", ae), (!S || de[0] & /*value*/
      1) && at(
        y,
        "latest",
        /*i*/
        u[33] === /*value*/
        u[0].length - 1
      ), (!S || de[0] & /*render_markdown*/
      128) && at(y, "message-markdown-disabled", !/*render_markdown*/
      u[7]), (!S || de[0] & /*selectable*/
      8) && at(
        y,
        "selectable",
        /*selectable*/
        u[3]
      ), de[0] & /*rtl*/
      16 && _r(
        y,
        "text-align",
        /*rtl*/
        u[4] ? "right" : "left"
      ), (!S || de[0] & /*value*/
      1 && L !== (L = "message " + /*name*/
      (u[30] === "User" ? "user" : "bot") + " svelte-1eod0mv")) && ge(v, "class", L), (!S || de[0] & /*value, layout, bubble_full_width*/
      577) && at(
        v,
        "message-fit",
        /*layout*/
        u[9] === "bubble" && !/*bubble_full_width*/
        u[6]
      ), (!S || de[0] & /*value, layout*/
      513) && at(
        v,
        "panel-full-width",
        /*layout*/
        u[9] === "panel"
      ), (!S || de[0] & /*value, layout*/
      513) && at(
        v,
        "message-bubble-border",
        /*layout*/
        u[9] === "bubble"
      ), (!S || de[0] & /*value, render_markdown*/
      129) && at(v, "message-markdown-disabled", !/*render_markdown*/
      u[7]), de[0] & /*rtl, value*/
      17 && _r(
        v,
        "text-align",
        /*rtl*/
        u[4] && /*name*/
        u[30] === "User" ? "left" : "right"
      ), (!S || de[0] & /*layout, value*/
      513 && B !== (B = "message-row " + /*layout*/
      u[9] + " " + /*name*/
      (u[30] === "User" ? "user-row" : "bot-row") + " svelte-1eod0mv")) && ge(a, "class", B);
    },
    i(ie) {
      S || (yt(W), S = !0);
    },
    o(ie) {
      Kt(W), S = !1;
    },
    d(ie) {
      ie && F0(a), ~H && X[H].d(), R = !1, Va(I);
    }
  };
}
function ms(u) {
  let a, i;
  return a = new th({ props: { layout: (
    /*layout*/
    u[9]
  ) } }), {
    c() {
      ao(a.$$.fragment);
    },
    m(l, m) {
      lo(a, l, m), i = !0;
    },
    p(l, m) {
      const c = {};
      m[0] & /*layout*/
      512 && (c.layout = /*layout*/
      l[9]), a.$set(c);
    },
    i(l) {
      i || (yt(a.$$.fragment, l), i = !0);
    },
    o(l) {
      Kt(a.$$.fragment, l), i = !1;
    },
    d(l) {
      io(a, l);
    }
  };
}
function yh(u) {
  let a, i, l, m, c, p, v = (
    /*value*/
    u[0] !== null && hs(u)
  );
  return {
    c() {
      a = Tt("div"), i = Tt("div"), v && v.c(), ge(i, "class", "message-wrap svelte-1eod0mv"), at(
        i,
        "bubble-gap",
        /*layout*/
        u[9] === "bubble"
      ), ge(a, "class", l = us(
        /*layout*/
        u[9] === "bubble" ? "bubble-wrap" : "panel-wrap"
      ) + " svelte-1eod0mv"), ge(a, "role", "log"), ge(a, "aria-label", "chatbot conversation"), ge(a, "aria-live", "polite");
    },
    m(y, D) {
      E0(y, a, D), D0(a, i), v && v.m(i, null), u[26](a), m = !0, c || (p = nh(Lu.call(null, i)), c = !0);
    },
    p(y, D) {
      /*value*/
      y[0] !== null ? v ? (v.p(y, D), D[0] & /*value*/
      1 && yt(v, 1)) : (v = hs(y), v.c(), yt(v, 1), v.m(i, null)) : v && (Dn(), Kt(v, 1, 1, () => {
        v = null;
      }), xn()), (!m || D[0] & /*layout*/
      512) && at(
        i,
        "bubble-gap",
        /*layout*/
        y[9] === "bubble"
      ), (!m || D[0] & /*layout*/
      512 && l !== (l = us(
        /*layout*/
        y[9] === "bubble" ? "bubble-wrap" : "panel-wrap"
      ) + " svelte-1eod0mv")) && ge(a, "class", l);
    },
    i(y) {
      m || (yt(v), m = !0);
    },
    o(y) {
      Kt(v), m = !1;
    },
    d(y) {
      y && F0(a), v && v.d(), u[26](null), c = !1, p();
    }
  };
}
function ds(u, a = "#3498db") {
  const i = document.createElement("canvas"), l = i.getContext("2d");
  i.width = 100, i.height = 100, l.fillStyle = a, l.fillRect(0, 0, i.width, i.height), l.fillStyle = "white", l.font = "bold 25px Arial", l.textAlign = "center", l.textBaseline = "middle";
  const m = i.width / 2, c = i.height / 2;
  return l.fillText(u, m, c), i.toDataURL();
}
function wh(u, a, i) {
  let { value: l } = a, m = null, { latex_delimiters: c } = a, { pending_message: p = !1 } = a, { selectable: v = !1 } = a, { rtl: y = !1 } = a, { avatar_images: D = [null, null] } = a, { sanitize_html: C = !0 } = a, { bubble_full_width: P = !0 } = a, { render_markdown: H = !0 } = a, { line_breaks: W = !0 } = a, { root: se } = a, { proxy_url: oe } = a, { i18n: ae } = a, { layout: L = "bubble" } = a, B, S;
  const R = mh();
  hh(() => {
    S = B && B.offsetHeight + B.scrollTop > B.scrollHeight - 100;
  });
  const I = () => {
    S && B.scrollTo(0, B.scrollHeight);
  };
  fh(() => {
    S && (I(), B.querySelectorAll("img").forEach((ue) => {
      ue.addEventListener("load", () => {
        I();
      });
    }));
  });
  function M(ue, Ke, _e) {
    R("select", { index: [ue, Ke], value: _e });
  }
  function X(ue) {
    nr.call(this, u, ue);
  }
  function $(ue) {
    nr.call(this, u, ue);
  }
  function j(ue) {
    nr.call(this, u, ue);
  }
  function he(ue) {
    nr.call(this, u, ue);
  }
  function ie(ue) {
    nr.call(this, u, ue);
  }
  function de(ue) {
    nr.call(this, u, ue);
  }
  const be = (ue, Ke) => M(ue, ue, Ke), Te = (ue, Ke, _e) => {
    _e.key === "Enter" && M(ue, ue, Ke);
  };
  function Xe(ue) {
    ah[ue ? "unshift" : "push"](() => {
      B = ue, i(10, B);
    });
  }
  return u.$$set = (ue) => {
    "value" in ue && i(0, l = ue.value), "latex_delimiters" in ue && i(1, c = ue.latex_delimiters), "pending_message" in ue && i(2, p = ue.pending_message), "selectable" in ue && i(3, v = ue.selectable), "rtl" in ue && i(4, y = ue.rtl), "avatar_images" in ue && i(13, D = ue.avatar_images), "sanitize_html" in ue && i(5, C = ue.sanitize_html), "bubble_full_width" in ue && i(6, P = ue.bubble_full_width), "render_markdown" in ue && i(7, H = ue.render_markdown), "line_breaks" in ue && i(8, W = ue.line_breaks), "root" in ue && i(14, se = ue.root), "proxy_url" in ue && i(15, oe = ue.proxy_url), "i18n" in ue && i(16, ae = ue.i18n), "layout" in ue && i(9, L = ue.layout);
  }, u.$$.update = () => {
    u.$$.dirty[0] & /*value, old_value*/
    131073 && (Ea(l, m) || (i(17, m = l), R("change")));
  }, [
    l,
    c,
    p,
    v,
    y,
    C,
    P,
    H,
    W,
    L,
    B,
    I,
    M,
    D,
    se,
    oe,
    ae,
    m,
    X,
    $,
    j,
    he,
    ie,
    de,
    be,
    Te,
    Xe
  ];
}
class kh extends rh {
  constructor(a) {
    super(), sh(
      this,
      a,
      wh,
      yh,
      oh,
      {
        value: 0,
        latex_delimiters: 1,
        pending_message: 2,
        selectable: 3,
        rtl: 4,
        avatar_images: 13,
        sanitize_html: 5,
        bubble_full_width: 6,
        render_markdown: 7,
        line_breaks: 8,
        root: 14,
        proxy_url: 15,
        i18n: 16,
        layout: 9
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: xh,
  append: Dh,
  assign: Ah,
  attr: _h,
  check_outros: ps,
  create_component: Sn,
  destroy_component: Fn,
  detach: gs,
  element: Sh,
  get_spread_object: Fh,
  get_spread_update: Eh,
  group_outros: vs,
  init: Ch,
  insert: bs,
  mount_component: En,
  safe_not_equal: Th,
  space: ys,
  transition_in: Wt,
  transition_out: A0
} = window.__gradio__svelte__internal;
function ws(u) {
  let a, i;
  const l = [
    {
      autoscroll: (
        /*gradio*/
        u[21].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      u[21].i18n
    ) },
    /*loading_status*/
    u[23],
    {
      show_progress: (
        /*loading_status*/
        u[23].show_progress === "hidden" ? "hidden" : "minimal"
      )
    }
  ];
  let m = {};
  for (let c = 0; c < l.length; c += 1)
    m = Ah(m, l[c]);
  return a = new ic({ props: m }), {
    c() {
      Sn(a.$$.fragment);
    },
    m(c, p) {
      En(a, c, p), i = !0;
    },
    p(c, p) {
      const v = p[0] & /*gradio, loading_status*/
      10485760 ? Eh(l, [
        p[0] & /*gradio*/
        2097152 && {
          autoscroll: (
            /*gradio*/
            c[21].autoscroll
          )
        },
        p[0] & /*gradio*/
        2097152 && { i18n: (
          /*gradio*/
          c[21].i18n
        ) },
        p[0] & /*loading_status*/
        8388608 && Fh(
          /*loading_status*/
          c[23]
        ),
        p[0] & /*loading_status*/
        8388608 && {
          show_progress: (
            /*loading_status*/
            c[23].show_progress === "hidden" ? "hidden" : "minimal"
          )
        }
      ]) : {};
      a.$set(v);
    },
    i(c) {
      i || (Wt(a.$$.fragment, c), i = !0);
    },
    o(c) {
      A0(a.$$.fragment, c), i = !1;
    },
    d(c) {
      Fn(a, c);
    }
  };
}
function ks(u) {
  let a, i;
  return a = new Vc({
    props: {
      show_label: (
        /*show_label*/
        u[7]
      ),
      Icon: fc,
      float: !1,
      label: (
        /*label*/
        u[6] || "Chatbot"
      )
    }
  }), {
    c() {
      Sn(a.$$.fragment);
    },
    m(l, m) {
      En(a, l, m), i = !0;
    },
    p(l, m) {
      const c = {};
      m[0] & /*show_label*/
      128 && (c.show_label = /*show_label*/
      l[7]), m[0] & /*label*/
      64 && (c.label = /*label*/
      l[6] || "Chatbot"), a.$set(c);
    },
    i(l) {
      i || (Wt(a.$$.fragment, l), i = !0);
    },
    o(l) {
      A0(a.$$.fragment, l), i = !1;
    },
    d(l) {
      Fn(a, l);
    }
  };
}
function Bh(u) {
  var y;
  let a, i, l, m, c, p = (
    /*loading_status*/
    u[23] && ws(u)
  ), v = (
    /*show_label*/
    u[7] && ks(u)
  );
  return m = new kh({
    props: {
      i18n: (
        /*gradio*/
        u[21].i18n
      ),
      selectable: (
        /*_selectable*/
        u[10]
      ),
      likeable: (
        /*likeable*/
        u[11]
      ),
      show_share_button: (
        /*show_share_button*/
        u[12]
      ),
      value: (
        /*_value*/
        u[25]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        u[20]
      ),
      render_markdown: (
        /*render_markdown*/
        u[18]
      ),
      pending_message: (
        /*loading_status*/
        ((y = u[23]) == null ? void 0 : y.status) === "pending"
      ),
      rtl: (
        /*rtl*/
        u[13]
      ),
      show_copy_button: (
        /*show_copy_button*/
        u[14]
      ),
      avatar_images: (
        /*avatar_images*/
        u[22]
      ),
      sanitize_html: (
        /*sanitize_html*/
        u[15]
      ),
      bubble_full_width: (
        /*bubble_full_width*/
        u[16]
      ),
      line_breaks: (
        /*line_breaks*/
        u[19]
      ),
      layout: (
        /*layout*/
        u[17]
      ),
      proxy_url: (
        /*proxy_url*/
        u[9]
      ),
      root: (
        /*root*/
        u[8]
      )
    }
  }), m.$on(
    "change",
    /*change_handler*/
    u[26]
  ), m.$on(
    "select",
    /*select_handler*/
    u[27]
  ), m.$on(
    "like",
    /*like_handler*/
    u[28]
  ), m.$on(
    "share",
    /*share_handler*/
    u[29]
  ), m.$on(
    "error",
    /*error_handler*/
    u[30]
  ), {
    c() {
      p && p.c(), a = ys(), i = Sh("div"), v && v.c(), l = ys(), Sn(m.$$.fragment), _h(i, "class", "wrapper svelte-r8zcdo");
    },
    m(D, C) {
      p && p.m(D, C), bs(D, a, C), bs(D, i, C), v && v.m(i, null), Dh(i, l), En(m, i, null), c = !0;
    },
    p(D, C) {
      var H;
      /*loading_status*/
      D[23] ? p ? (p.p(D, C), C[0] & /*loading_status*/
      8388608 && Wt(p, 1)) : (p = ws(D), p.c(), Wt(p, 1), p.m(a.parentNode, a)) : p && (vs(), A0(p, 1, 1, () => {
        p = null;
      }), ps()), /*show_label*/
      D[7] ? v ? (v.p(D, C), C[0] & /*show_label*/
      128 && Wt(v, 1)) : (v = ks(D), v.c(), Wt(v, 1), v.m(i, l)) : v && (vs(), A0(v, 1, 1, () => {
        v = null;
      }), ps());
      const P = {};
      C[0] & /*gradio*/
      2097152 && (P.i18n = /*gradio*/
      D[21].i18n), C[0] & /*_selectable*/
      1024 && (P.selectable = /*_selectable*/
      D[10]), C[0] & /*likeable*/
      2048 && (P.likeable = /*likeable*/
      D[11]), C[0] & /*show_share_button*/
      4096 && (P.show_share_button = /*show_share_button*/
      D[12]), C[0] & /*_value*/
      33554432 && (P.value = /*_value*/
      D[25]), C[0] & /*latex_delimiters*/
      1048576 && (P.latex_delimiters = /*latex_delimiters*/
      D[20]), C[0] & /*render_markdown*/
      262144 && (P.render_markdown = /*render_markdown*/
      D[18]), C[0] & /*loading_status*/
      8388608 && (P.pending_message = /*loading_status*/
      ((H = D[23]) == null ? void 0 : H.status) === "pending"), C[0] & /*rtl*/
      8192 && (P.rtl = /*rtl*/
      D[13]), C[0] & /*show_copy_button*/
      16384 && (P.show_copy_button = /*show_copy_button*/
      D[14]), C[0] & /*avatar_images*/
      4194304 && (P.avatar_images = /*avatar_images*/
      D[22]), C[0] & /*sanitize_html*/
      32768 && (P.sanitize_html = /*sanitize_html*/
      D[15]), C[0] & /*bubble_full_width*/
      65536 && (P.bubble_full_width = /*bubble_full_width*/
      D[16]), C[0] & /*line_breaks*/
      524288 && (P.line_breaks = /*line_breaks*/
      D[19]), C[0] & /*layout*/
      131072 && (P.layout = /*layout*/
      D[17]), C[0] & /*proxy_url*/
      512 && (P.proxy_url = /*proxy_url*/
      D[9]), C[0] & /*root*/
      256 && (P.root = /*root*/
      D[8]), m.$set(P);
    },
    i(D) {
      c || (Wt(p), Wt(v), Wt(m.$$.fragment, D), c = !0);
    },
    o(D) {
      A0(p), A0(v), A0(m.$$.fragment, D), c = !1;
    },
    d(D) {
      D && (gs(a), gs(i)), p && p.d(D), v && v.d(), Fn(m);
    }
  };
}
function Mh(u) {
  let a, i;
  return a = new Ec({
    props: {
      elem_id: (
        /*elem_id*/
        u[0]
      ),
      elem_classes: (
        /*elem_classes*/
        u[1]
      ),
      visible: (
        /*visible*/
        u[2]
      ),
      padding: !1,
      scale: (
        /*scale*/
        u[4]
      ),
      min_width: (
        /*min_width*/
        u[5]
      ),
      height: (
        /*height*/
        u[24]
      ),
      allow_overflow: !1,
      $$slots: { default: [Bh] },
      $$scope: { ctx: u }
    }
  }), {
    c() {
      Sn(a.$$.fragment);
    },
    m(l, m) {
      En(a, l, m), i = !0;
    },
    p(l, m) {
      const c = {};
      m[0] & /*elem_id*/
      1 && (c.elem_id = /*elem_id*/
      l[0]), m[0] & /*elem_classes*/
      2 && (c.elem_classes = /*elem_classes*/
      l[1]), m[0] & /*visible*/
      4 && (c.visible = /*visible*/
      l[2]), m[0] & /*scale*/
      16 && (c.scale = /*scale*/
      l[4]), m[0] & /*min_width*/
      32 && (c.min_width = /*min_width*/
      l[5]), m[0] & /*height*/
      16777216 && (c.height = /*height*/
      l[24]), m[0] & /*gradio, _selectable, likeable, show_share_button, _value, latex_delimiters, render_markdown, loading_status, rtl, show_copy_button, avatar_images, sanitize_html, bubble_full_width, line_breaks, layout, proxy_url, root, value, show_label, label*/
      50331592 | m[1] & /*$$scope*/
      4 && (c.$$scope = { dirty: m, ctx: l }), a.$set(c);
    },
    i(l) {
      i || (Wt(a.$$.fragment, l), i = !0);
    },
    o(l) {
      A0(a.$$.fragment, l), i = !1;
    },
    d(l) {
      Fn(a, l);
    }
  };
}
function xs(u) {
  let a, i = u[0], l = 1;
  for (; l < u.length; ) {
    const m = u[l], c = u[l + 1];
    if (l += 2, (m === "optionalAccess" || m === "optionalCall") && i == null)
      return;
    m === "access" || m === "optionalAccess" ? (a = i, i = c(i)) : (m === "call" || m === "optionalCall") && (i = c((...p) => i.call(a, ...p)), a = void 0);
  }
  return i;
}
function zh(u, a, i) {
  let { elem_id: l = "" } = a, { elem_classes: m = [] } = a, { visible: c = !0 } = a, { value: p = [] } = a, { scale: v = null } = a, { min_width: y = void 0 } = a, { label: D } = a, { show_label: C = !0 } = a, { root: P } = a, { proxy_url: H } = a, { _selectable: W = !1 } = a, { likeable: se = !1 } = a, { show_share_button: oe = !1 } = a, { rtl: ae = !1 } = a, { show_copy_button: L = !1 } = a, { sanitize_html: B = !0 } = a, { bubble_full_width: S = !0 } = a, { layout: R = "bubble" } = a, { render_markdown: I = !0 } = a, { line_breaks: M = !0 } = a, { latex_delimiters: X } = a, { gradio: $ } = a, { avatar_images: j = [null, null] } = a, he;
  const ie = (Z) => Z.replace('src="/file', `src="${P}file`);
  function de(Z) {
    return Z === null ? Z : {
      file: no(xs([Z, "optionalAccess", (K) => K.file]), P, H),
      alt_text: xs([Z, "optionalAccess", (K) => K.alt_text])
    };
  }
  let { loading_status: be = void 0 } = a, { height: Te = 400 } = a;
  const Xe = () => $.dispatch("change", p), ue = (Z) => $.dispatch("select", Z.detail), Ke = (Z) => $.dispatch("like", Z.detail), _e = (Z) => $.dispatch("share", Z.detail), Ae = (Z) => $.dispatch("error", Z.detail);
  return u.$$set = (Z) => {
    "elem_id" in Z && i(0, l = Z.elem_id), "elem_classes" in Z && i(1, m = Z.elem_classes), "visible" in Z && i(2, c = Z.visible), "value" in Z && i(3, p = Z.value), "scale" in Z && i(4, v = Z.scale), "min_width" in Z && i(5, y = Z.min_width), "label" in Z && i(6, D = Z.label), "show_label" in Z && i(7, C = Z.show_label), "root" in Z && i(8, P = Z.root), "proxy_url" in Z && i(9, H = Z.proxy_url), "_selectable" in Z && i(10, W = Z._selectable), "likeable" in Z && i(11, se = Z.likeable), "show_share_button" in Z && i(12, oe = Z.show_share_button), "rtl" in Z && i(13, ae = Z.rtl), "show_copy_button" in Z && i(14, L = Z.show_copy_button), "sanitize_html" in Z && i(15, B = Z.sanitize_html), "bubble_full_width" in Z && i(16, S = Z.bubble_full_width), "layout" in Z && i(17, R = Z.layout), "render_markdown" in Z && i(18, I = Z.render_markdown), "line_breaks" in Z && i(19, M = Z.line_breaks), "latex_delimiters" in Z && i(20, X = Z.latex_delimiters), "gradio" in Z && i(21, $ = Z.gradio), "avatar_images" in Z && i(22, j = Z.avatar_images), "loading_status" in Z && i(23, be = Z.loading_status), "height" in Z && i(24, Te = Z.height);
  }, u.$$.update = () => {
    u.$$.dirty[0] & /*value*/
    8 && i(25, he = p ? p.map(([Z, K]) => [
      typeof Z == "string" ? ie(Z) : de(Z),
      typeof K == "string" ? ie(K) : de(K)
    ]) : []);
  }, [
    l,
    m,
    c,
    p,
    v,
    y,
    D,
    C,
    P,
    H,
    W,
    se,
    oe,
    ae,
    L,
    B,
    S,
    R,
    I,
    M,
    X,
    $,
    j,
    be,
    Te,
    he,
    Xe,
    ue,
    Ke,
    _e,
    Ae
  ];
}
class Ih extends xh {
  constructor(a) {
    super(), Ch(
      this,
      a,
      zh,
      Mh,
      Th,
      {
        elem_id: 0,
        elem_classes: 1,
        visible: 2,
        value: 3,
        scale: 4,
        min_width: 5,
        label: 6,
        show_label: 7,
        root: 8,
        proxy_url: 9,
        _selectable: 10,
        likeable: 11,
        show_share_button: 12,
        rtl: 13,
        show_copy_button: 14,
        sanitize_html: 15,
        bubble_full_width: 16,
        layout: 17,
        render_markdown: 18,
        line_breaks: 19,
        latex_delimiters: 20,
        gradio: 21,
        avatar_images: 22,
        loading_status: 23,
        height: 24
      },
      null,
      [-1, -1]
    );
  }
}
export {
  kh as BaseChatBot,
  Ih as default
};
